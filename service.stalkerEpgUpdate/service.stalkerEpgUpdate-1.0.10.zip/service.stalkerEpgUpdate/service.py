import xbmcplugin,xbmcaddon
import time
import datetime
import xbmc
import os
import urllib2,json
import zipfile
import resources.lib.utils as utils
from resources.lib.croniter import croniter
from collections import namedtuple
from shutil import copyfile

__addon__ = xbmcaddon.Addon()
__author__ = __addon__.getAddonInfo('author')
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__ = __addon__.getAddonInfo('path')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString
debug = __addon__.getSetting("debug")
offset1hr = __addon__.getSetting("offset1hr")

xbmc.executebuiltin('StopPVRManager()')
 
class epgUpdater:

    def __init__(self):
        self.monitor = UpdateMonitor(update_method = self.settingsChanged)
        self.enabled = utils.getSetting("enable_scheduler")
        self.next_run = 0


        try:
          #self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimplepro')
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None
          

        try:
          self.videostalker = xbmcaddon.Addon('plugin.video.stalker')
        except:
          utils.log("Failed to find plugin.video.stalker addon")
          self.pvriptvsimple_addon = None

        self.updateEpg()
        self.setup()     

    def setup(self):
        #scheduler was turned on, find next run time
        utils.log("StalkerSettings::scheduler enabled, finding next run time")
        if self.pvriptvsimple_addon != None: # and self.videostalker != None:
            self.pvriptvsimple_addon.setSetting("epgCache", "true") # For WEB URL Only
            self.pvriptvsimple_addon.setSetting("epgPathType", "1") # Set URL WEB
            self.pvriptvsimple_addon.setSetting("epgPath", 'http://tinyurl.com/EPG4Stalker3') # 0 Local
            self.pvriptvsimple_addon.setSetting("epgUrl", "https://github.com/psyc0n/epgninja/raw/master/guide.xml.gz")# 1 WEB
            # M3U SETTINGS
            self.pvriptvsimple_addon.setSetting("m3uCache", "true") # For WEB URL Only
            self.pvriptvsimple_addon.setSetting("m3uPathType", "1") # Set URL WEB
            self.pvriptvsimple_addon.setSetting("m3uPath", "http://localhost:8899/channels-1.m3u")# 0
            self.pvriptvsimple_addon.setSetting("m3uUrl", "https://github.com/LongHongVan/MyKodi/raw/master/iptv_new_logo.m3u") # 1
			#self.pvriptvsimple_addon.setSetting("m3uUrl", "http://tinyurl.com/gottvnow") # 1
            #self.pvriptvsimple_addon.setSetting("m3uUrl", "https://googledrive.com/host/0B3wDfMBF1O42Vm9wcnJkSGthaFE/iptvpro_new_logo.m3u") # 1 - iptvpro
            #self.pvriptvsimple_addon.setSetting("m3uUrl", "https://googledrive.com/host/0B3wDfMBF1O42Vm9wcnJkSGthaFE/iptv_simplepro_iptvsubs_localhost8898.m3u") # 1
            #self.pvriptvsimple_addon.setSetting("m3uUrl", "https://googledrive.com/host/0B3wDfMBF1O42Vm9wcnJkSGthaFE/iptv_new_logo.m3u") # 1
            #self.pvriptvsimple_addon.setSetting("m3uUrl", "http://tinyurl.com/IPTV4Stalker03") # 1

            # LOGO
            #self.pvriptvsimple_addon.setSetting("logoBaseUrl", "http://")
            #self.pvriptvsimple_addon.setSetting("logoFromEpg", "1")
            #self.pvriptvsimple_addon.setSetting("logoPath", "") # Local Drive Path
            #self.pvriptvsimple_addon.setSetting("logoPathType", "1") # 0=local; 1=Url WEB
            
            #self.pvriptvsimple_addon.setSetting("m3uPath", "http://localhost:8899/channels-1.m3u")# Stalker # 1
            self.pvriptvsimple_addon.setSetting("epgTSOverride", "true")# Apply Time Shift To All Channels
            # VIDEO STALKER
            '''
            self.videostalker.setSetting("send_serial_1", "true")
            self.videostalker.setSetting("send_serial_2", "true")
            self.videostalker.setSetting("send_serial_3", "true")
            self.videostalker.setSetting("server_enable", "true")
            self.videostalker.setSetting("server_port", "8899")
            '''
            
            
            
        else:
            utils.log('Addon not found')
            

        self.findNextRun(time.time())
        while(not xbmc.abortRequested):
            # Sleep/wait for abort for 10 seconds
            now = time.time()
            if(self.next_run <= now):
                if self.enabled:
                    self.updateEpg()
                    self.findNextRun(now)

            else:
                self.findNextRun(now)



            xbmc.sleep(500)
        # del self.monitor
        
    def installKeyboardFile(self):
      keyboard_file_path = os.path.join(xbmc.translatePath('special://home'), 'addons/service.stalkerEpgUpdate/keyboard.xml')
      if os.path.isfile(keyboard_file_path):
        utils.log("Keyboard file found.  Copying...")
        copyfile(keyboard_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'keymaps/keyboard.xml'))


    def settingsChanged(self):
        utils.log("Settings changed - update")
        current_enabled = utils.getSetting("enable_scheduler")

        if(current_enabled == "true" and self.enabled == "false"):
            #scheduler was just turned on

            self.enabled = current_enabled
            self.setup()
        elif (current_enabled == "false" and self.enabled == "true"):
            #schedule was turn off
            self.enabled = current_enabled

        if(self.enabled == "true"):
            #always recheck the next run time after an update
            utils.log('recalculate start time , after settings update')
            self.findNextRun(time.time())


    def parseSchedule(self):
        schedule_type = int(utils.getSetting("schedule_interval"))
        cron_exp = utils.getSetting("cron_schedule")
        #For my_schedule
        my_schedule_enable = utils.getSetting("my_schedule_enable")
        
        if my_schedule_enable == "true":
            hour_of_day = utils.getSetting("my_schedule_time")
        else:
            hour_of_day = utils.getSetting("schedule_time")
        hour_of_day = int(hour_of_day[0:2])
        if(schedule_type == 0 or schedule_type == 1):
            #every day
            cron_exp = "0 " + str(hour_of_day) + " * * *"
        elif(schedule_type == 2):
            #once a week
            day_of_week = utils.getSetting("day_of_week")
            cron_exp = "0 " + str(hour_of_day) + " * * " + day_of_week
        elif(schedule_type == 3):
            #first day of month
            cron_exp = "0 " + str(hour_of_day) + " 1 * *"

        return cron_exp


    def findNextRun(self,now):
        #find the cron expression and get the next run time
        cron_exp = self.parseSchedule()
        cron_ob = croniter(cron_exp,datetime.datetime.fromtimestamp(now))
        new_run_time = cron_ob.get_next(float)
        # utils.log('new run time' +  str(new_run_time))
        # utils.log('next run time' + str(self.next_run))
        if(new_run_time != self.next_run):
            self.next_run = new_run_time
            utils.showNotification('EPG Updater IPTV Pro', 'Next Update: ' + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))
            #utils.showNotification('EPG Updater', 'Next Update: ' + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))
            utils.log("scheduler will run again on " + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))
            xbmc.executebuiltin('StartPVRManager()')




    def updateEpg(self):
        utils.log('StalkerSettings:: updateEpg')
        if offset1hr == 'true':
            epgFileName = 'guide2.zip'
        else:
            epgFileName = 'guide.zip'

        epgFile = None


        ## check to see if folder is there
        downloadNfps = True
        downloadStalker = True
        userdataPath = xbmc.translatePath('special://userdata')
        tempPath =  xbmc.translatePath('special://temp')
        epgDownloadPath = os.path.join(tempPath, epgFileName)
        addonFolderNfps =  os.path.join(userdataPath,'addon_data/pvr.stalker.nfps')
        addonFolderStalker = os.path.join(userdataPath,'addon_data/pvr.stalker')

        if not os.path.exists(addonFolderNfps):
            downloadNfps = False
        if not os.path.exists(addonFolderStalker):
            downloadStalker = False

        if downloadNfps != False or  downloadStalker != False:
            try:

                response = urllib2.urlopen('https://github.com/psyc0n/epgninja/raw/master/'+epgFileName)
                epgFile = response.read()
            except:
                utils.log('StalkerSettings: Some issue with epg file')
                pass


            if epgFile:
                utils.log('StalkerSettings:: ' + epgDownloadPath)
                epgFH = open(epgDownloadPath, "w+b")
                epgFH.write(epgFile)
                epgFH.close()

                zfobj = zipfile.ZipFile(epgDownloadPath)
                if downloadNfps == True:
                    for name in zfobj.namelist():
                        outputFileName = addonFolderNfps+'/epg_xmltv.xml'
                        uncompressed = zfobj.read(name)
                        utils.log("StalkerSettings::Saving extracted file to " + str(outputFileName))
                        output = open(outputFileName,'wb')
                        output.write(uncompressed)
                        output.close()
                        

                if downloadStalker == True:
                    for name in zfobj.namelist():
                        outputFileName = addonFolderStalker+'/epg_xmltv.xml'
                        uncompressed = zfobj.read(name)
                        utils.log("StalkerSettings::Saving extracted file to " + str(outputFileName))

                        #outputFileName = addonFolderStalker+'/epg_xmltv.xml'
                        output = open(outputFileName,'wb')
                        output.write(uncompressed)
                        output.close()
                        try: # EPG updating for IPTV Simple Clients
							myepgfilename = 'C:/Users/Long/MediaFire/TV-Guide/xmltv_new.xml'#
							#myepgfilename = 'C:\\Users\long\\MediaFire\\TV-Guide\\xmltv_new.xml'
							outputb = open(myepgfilename,'wb')
							outputb.write(uncompressed)
							outputb.close()
                        except: pass


class UpdateMonitor(xbmc.Monitor):
    update_method = None

    def __init__(self,*args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.update_method = kwargs['update_method']

    def onSettingsChanged(self):
        self.update_method()
