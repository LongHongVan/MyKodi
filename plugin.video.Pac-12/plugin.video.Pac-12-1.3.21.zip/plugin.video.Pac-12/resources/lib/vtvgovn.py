# -*- coding: utf-8 -*-

import urllib,urllib2, re, os, json, xbmc
from common import Paths
mycacheDir = Paths.cacheDir
import requests
import urlfetch


def pacrw(fn,s='',a='w'):
	if len(fn) < 20:fn=os.path.join(mycacheDir,fn)
	try:
		if s and a=='w':s=s.replace('\r\n','\n');f=open(fn,a);f.write(s)
		elif s:f=open(fn,a);f.write(s)
		else:f=open(fn);s=f.read().replace('\r\n','\n')
		f.close()
	except:s=''
	return s

hdr = {
'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11', 
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 
'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 
'Accept-Encoding': 'none', 
'Accept-Language': 'en-US,en;q=0.8', 
'Connection': 'keep-alive'}


class vtvgovn:
	def __init__(self):
		self.hd={'User-Agent':'Mozilla/5.0','Cookie':pacrw('vtvgo.cookie')}
		self.urlhome='http://vtvgo.vn/'

	def live(self,id):
		url = 'http://vtvgo.vn/?xem-truc-tuyen-kenh-%s.html'%id
		try: 
			req = requests.get(url, headers = hdr)
			link = re.search("addPlayer\('(.+?.m3u8)", req.text ).group(1) + "|Referer=http%3A%2F%2Fvtvgo.vn%2F"
		except:link=''
		#print link
		return link

	def getStream(self,url):
		stream = ""
		url = url . replace ( "get-program-channel?" , "get-program-channel-v2-detail?" )
		header =  { "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36" , "Accept-Encoding" : "gzip, deflate" ,"Referer" : "http://vtvgo.vn/" }
		referer = "|Referer=http%3A%2F%2Fvtvgo.vn%2F"
		req = requests . get ( url , headers = header )
		stream = re . search ( "addPlayer\('(.+?.m3u8)" , req . text ) . group ( 1 ) + referer
		return stream
		
	def getStreamTvnet(self,id):
		from cookielib import CookieJar
		stream = ""
		cj = CookieJar()
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		#ShowMessage("getStreamTvnet", str(id))
		host_tvnet = "http://au.tvnet.gov.vn/kenh-truyen-hinh/"
		chid = ["1011/vtv1","1010/vtv2","1013/vtv3","1009/vtv4","1007/vtc1","1006/netviet","1018/vtc16","1012/htv9","1019/ttxvn","1008/hn"]
		url = host_tvnet + id
		stringA = opener.open(url).read().decode('utf-8')
		#deleteContent(my_test)
		#writeappend_file(my_test,str(stringA))
		stringB = 'data-file="'
		stringC = '"'
		nurl = re.search(stringB+"(.*?)"+re.escape(stringC),stringA).group(1)
		stringA = opener.open(nurl).read().decode('utf-8')
		stringB = '"url": "'
		stringC = '"'
		full_url_BC = re.search(stringB+"(.*?)"+re.escape(stringC),stringA).group(1)
		stream = full_url_BC
		print stream
		return stream


		