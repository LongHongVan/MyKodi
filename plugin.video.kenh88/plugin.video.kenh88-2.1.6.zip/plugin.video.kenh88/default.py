#!/usr/bin/python
# -*- coding: utf-8 -*-
import httplib
import urllib,urllib2,re#,sys
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui
import base64
import xbmc
try: import simplejson as json
except ImportError: import json
import requests
from bs4 import BeautifulSoup
import cgi
import datetime
from resources.lib.common import *
import api#, urlparse
from urlparse import urlparse, parse_qs
cache_path = xbmc.translatePath('special://temp')

addon_id = 'plugin.video.kenh88'
my_addon = xbmcaddon.Addon(addon_id)
download_path = str(my_addon.getSetting(id='download_path'))

addonPath = my_addon.getAddonInfo('path')
version = my_addon.getAddonInfo('version')
icon = os.path.join(addonPath,'icon.png')

ADDON = xbmcaddon.Addon(id='plugin.video.kenh88')
homeLink="http://www.kenh88.com"

myDebugPath = Paths.pluginDataDir
FolderNEW(myDebugPath)

def ksearch(pattern,string,group=1,flags=0,result=''):
	try:s=re.search(pattern,string,flags).group(group)
	except:s=result
	return s

def kcheck(item,hd={'User-Agent':'Mozilla/5.0'},data=None,timeout=30):
	def check(url):
		req = urllib2.Request(url,data,hd)
		try:
			b = urllib2.urlopen(req,timeout=timeout)
			link = b.geturl()
			b.close()
		except:
			link = ''
		return link
	
	link = ''
	if type(item) in (str,unicode):
		link = check(item)
	
	elif type(item)==list:
		try:
			for href,title in item:
				link = check(href)
				if link:
					break
		except:
			mess('Link checked fail !','xshare')
	return link

def kread(url,headers={'User-Agent':'Mozilla/5.0'},data=None,timeout=30):
	req=urllib2.Request(url,data,headers)
	try:
		res=urllib2.urlopen(req, timeout=timeout)
		hd=dict(res.headers.items())
		cookie=hd.get('set-cookie','')
		encoding=hd.get('content-encoding','')
		if encoding=='gzip':
			import StringIO,gzip
			buf=StringIO.StringIO(res.read())
			f=gzip.GzipFile(fileobj=buf)
			b=f.read()
		else:b=res.read()
		res.close()
	except:b=''
	return b

def __init__(self):
    playlist=sys.modules["__main__"].playlist
def HOME():
        addDir('Search',homeLink,4,'http://www.kenh88.com/image/logo4.jpg')
        link = GetContent(homeLink)       
        try:
            link =link.encode("UTF-8")
        except: pass        
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        mainnav=soup.findAll('div', {"class" : "menu"})
        for item in mainnav[0].findAll('li'):
			link = homeLink+item.a['href'].encode('utf-8', 'ignore')
			if(item.ul==None):
				if(item.a.i==None):
					vname="--"+str(item.a.contents[0]).strip()
				else:
					vname="Not Found"
			else:
				vname=str(item.a.contents[0]).strip()
			if(vname.strip() != "home") and (vname != "Not Found"):
				if(link.find("javascript:")==-1):
					addDir(vname.strip(),link,2,'')
				else:
					addLink(vname.strip(),"",2,'','')
THUMB_EN = False
def INDEX(url):
        link = GetContent(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        mainnav=soup.findAll('div', {"id" : "list-1"})
        vimg=vname=MyCacheImg=vidname=""
        idx = n = d = -1
        idx_dat = [1, 7, 16] #[1, 7, 13, 16]
        #idx_dat = [1, 6, 12, 23, 34]
        durations = []
        infos = []
        duration = ""
        info = ""
        for dat, da in zip(mainnav[0].findAll('div'), mainnav[0].findAll('div')):
			idx += 1
			try: 
				if idx not in idx_dat:
					d += 1
					dura = dat.find('span', {'class': 'process_r'})
					duration = str(dura.text).encode('utf-8', 'ignore')#.replace("Tập", "Tap")
					durations.append(duration)
			except: pass
				#duration = ""
				#durations.append(duration)
			try:
				if idx not in idx_dat:
					status = da.find('span', {'class': 'status'})
					info = str(status.text).encode('utf-8', 'ignore')
					infos.append(info)
			except: pass
				#info = ""
				#infos.append(info)
        for item in mainnav[0].findAll('a'):
			try:
					n += 1
					id = n // 2
					vlink=homeLink+item["href"]
					vimg=homeLink+item.img["src"].strip().replace(" ","%20")# process_r
					vname=item.img["alt"].encode('utf-8', 'ignore')
					vidname = str(vname) + ' ' + str(Colored(infos[id], 'teal')) + ' ' + str(durations[id])
					#vidname = str(vname) + ' ' + str(Colored(info, 'teal')) + ' ' + str(duration)
					addDir(str(id) + " " + vidname,vlink,7,vimg)
			except: pass
        pagenav= mainnav[0].findAll('ul', {"class" : "pagination"})
        for item in pagenav[0].findAll('a'):
			vlink=homeLink+item["href"]
			vname=item.contents[0].encode('utf-8', 'ignore')
			addDir("Page "+vname.strip(),vlink,2,'')

	
def SEARCH():
    try:
        keyb = xbmc.Keyboard('', 'Enter search text')
        keyb.doModal()
        if (keyb.isConfirmed()):
            searchText = urllib.urlencode({'keyword': urllib.quote_plus(keyb.getText())})
        url = 'http://www.kenh88.com/film/search?'+searchText+'&btnSort=Search'
        INDEX(url)
    except: pass

def getVidPage(url,name):
  contentlink = GetContent(url)
  contentlink = ''.join(contentlink.splitlines()).replace('\'','"')
  try:
	contentlink =contentlink.encode("UTF-8")
  except: pass
  soup = BeautifulSoup(contentlink)
  spantag=soup.findAll('span', {"class" : "h1-span"})
  mlink=homeLink+spantag[0].findAll('a')[0]["href"]
  return mlink
  
def getServer(vidid,name):
        url=vidid
        url=getVidPage(url,name)
        link = GetContent(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        epicontent=soup.findAll('div', {"class" : "serverlist"})
        serverlist=epicontent[0].findAll('div', {"class" : "server"})
        for epserver in serverlist:
			if(len(serverlist)==1):
				for item in epserver.findAll('a'):
					vlink=homeLink+item["href"]
					vname=item.contents[0]
					addLink(vname,vlink,3,"","")
			else:
				serveritem=epserver.findAll('div', {"class" : "label"})[0]
				servername=serveritem.contents[1]
				if servername: #if not "VIP2" in servername
					addDir(servername,url,5,"")
        
def Episodes(url,name):
        link = GetContent(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        soup = BeautifulSoup(newlink)
        epicontent=soup.findAll('div', {"class" : "serverlist"})
        serverlist=epicontent[0].findAll('div', {"class" : "server"})
        for epserver in serverlist:
			serveritem=epserver.findAll('div', {"class" : "label"})[0]
			servername=serveritem.contents[1]
			if(servername==name):
				for item in epserver.findAll('a'):
					vlink=homeLink+item["href"]
					vname=item.contents[0]
					addLink("Episode " + vname,vlink,3,"","")
 
def GetContent(url):
    try:
       net = Net()
       second_response = net.http_GET(url)
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')

def playStream(url, name, icon):
	li = xbmcgui.ListItem(label=name, iconImage=icon, thumbnailImage=icon, path="")
	xbmc.Player().play(item=url, listitem=li)
	exit()

def playVideo(videoType,videoId):
    url = ""
    if (videoType == "youtube"):
        try:
                url = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' + videoId.replace('?','')
                xbmc.executebuiltin("xbmc.PlayMedia("+url+")")
        except:
                url = getYoutube(videoId)
                xbmcPlayer = xbmc.Player()
                xbmcPlayer.play(url)
    elif (videoType == "vimeo"):
        url = 'plugin://plugin.video.vimeo/?action=play_video&videoID=' + videoId
    elif (videoType == "tudou"):
        url = 'plugin://plugin.video.tudou/?mode=3&url=' + videoId
    else: #'direct'
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(videoId)

SHOWLINKS = False
CAPLINKS = False
def loadVideos(url,name):
        #try:
           link=GetContent(url)
           UnMatched = []
           try:
				link =link.encode("UTF-8")
           except: pass
           newlink = ''.join(link.splitlines()).replace('\t','')
           match=re.compile('link:\s*"(.+?)"}').findall(newlink)
           if match == UnMatched:
				try:
					newlink=BeautifulSoup(link).find('embed', {"type" : "application/x-shockwave-flash"})
					if newlink <> None:
						query = parse_qs(urlparse(newlink['src']).query)
						docid = query['docid'][0]
						requ = 'https://docs.google.com/get_video_info?' + urllib.urlencode({'docid': docid, 'eurl': url, 'authuser': ''})
						resp = api.HTTPKit(cache_path=cache_path).Request(requ).content
						vidlink = parse_qs(resp)['fmt_stream_map'][0].split('|')[1]
						playVideo("direct",vidlink)
						return
				except: pass
           try:
				newlink=match[0].decode('base-64')
           except: 
				if re.search('\{"file":".+?"\}', link): # get link for server MIRROR
					href = ksearch('(\{"file":".+?"\})', link)
					if SHOWLINKS: ShowMessage("getlink88", str(href))
					if CAPLINKS: write_file(addondir + "getlink88_b.txt", str(link))
					try:
						vidlink = json.loads(href).get('link', '')
						if not vidlink:
							vidlink = json.loads(href).get('file', '')
					except:
						vidlink = ''
					infoDialog(str(vidlink), "Get Mirrorlink", time=3000)
					playVideo("direct",vidlink)
					return
           if (newlink.find("dailymotion") > -1):
                match=re.compile('http://www.dailymotion.com/embed/video/(.+?)\?').findall(newlink)
                if(len(match) == 0):
                        match=re.compile('http://www.dailymotion.com/video/(.+?)&dk;').findall(newlink+"&dk;")
                if(len(match) == 0):
                        match=re.compile('http://www.dailymotion.com/swf/(.+?)\?').findall(newlink)
                link = 'http://www.dailymotion.com/video/'+str(match[0])
                print match[0]
                vidlink=getDailyMotionUrl(match[0])
                playVideo('dailymontion',vidlink)  
           elif (newlink.find("docs.google.com") > -1 or newlink.find("drive.google.com") > -1):
                if (newlink.find("drive.google.com") > -1):
					href = base64.b64encode(str(newlink))
					if len(href)>20:
						data=urllib.urlencode({'link':href});label=0#;mess('link')
						jp=kread('http://www.kenh88.com/gkphp/plugins/gkpluginsphp.php',data=data)
						try:
							j=json.loads(jp).get('link')
							if isinstance(j,unicode):items=[(j,'')]
							else:items=ls([(i.get('link',''),rsl(i.get('label',''))) for i in j])
							for href,r in items:
								link=kcheck(href.replace('amp;',''))
								vidlink = link
								if vidlink:break
						except:j={}
					infoDialog(str(vidlink), "Get Glink", time=3000)
                else:
					docid = newlink.split('/')[5]
					requ = 'https://docs.google.com/get_video_info?' + urllib.urlencode({'docid': docid, 'eurl': url, 'authuser': ''})
					resp = api.HTTPKit(cache_path=cache_path).Request(requ).content
					vidlink = parse_qs(resp)['fmt_stream_map'][0].split('|')[1]
                playStream(vidlink, name, icon)#playVideo("direct",vidlink)# #
           elif(newlink.find("picasaweb.google") > 0):
                import urlresolver
                vidlink = urlresolver.HostedMediaFile(newlink).resolve()
                playVideo("direct",vidlink)
           elif (newlink.find("video.google.com") > -1):  
                match=re.compile('http://video.google.com/videoplay.+?docid=(.+?)&.+?').findall(newlink)
                glink=""
                if(len(match) > 0):
                        glink = GetContent("http://www.flashvideodownloader.org/download.php?u=http://video.google.com/videoplay?docid="+match[0])
                else:
                        match=re.compile('http://video.google.com/googleplayer.swf.+?docId=(.+?)&dk').findall(newlink)
                        if(len(match) > 0):
                                glink = GetContent("http://www.flashvideodownloader.org/download.php?u=http://video.google.com/videoplay?docid="+match[0])
                gcontent=re.compile('<div class="mod_download"><a href="(.+?)" title="Click to Download">').findall(glink)
                if(len(gcontent) > 0):
                        playVideo('google',gcontent[0])
           elif (newlink.find("4shared") > -1):
                d = xbmcgui.Dialog()
                d.ok('Not Implemented','Sorry 4Shared links',' not implemented yet')
           elif (newlink.find("photos.google.com") > -1):
				href = base64.b64encode(str(newlink))
				vidlink = ""
				if len(href)>20:
					data=urllib.urlencode({'link':href})#;label=0
					jp=kread('http://www.kenh88.com/gkphp/plugins/gkpluginsphp.php',data=data)
					jp = str(jp.replace("\/\/", "//").replace("\/", "/"))
					try:
						vidlink = json.loads(jp).get('link')
					except:j={}
				infoDialog(str(vidlink), "Get Glink", time=3000)
				playVideo("direct",vidlink)
           else:
                if (newlink.find("linksend.net") > -1):
                     d = xbmcgui.Dialog()
                     d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')
                newlink1 = urllib2.unquote(newlink).decode('utf-8', 'ignore')+'&dk;'
                match=re.compile('(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)').findall(newlink1)
                if(len(match) == 0):
                    match=re.compile('http://www.youtube.com/watch\?v=(.+?)&dk;').findall(newlink1)
                if(len(match) > 0):
                    lastmatch = match[0][len(match[0])-1].replace('v/','')
                    playVideo('youtube',lastmatch)
                else:
                    playVideo('yeuphim.net',urllib2.unquote(newlink).decode('utf-8', 'ignore'))

def getDailyMotionUrl(id):
    maxVideoQuality="720p"
    content = GetContent("http://www.dailymotion.com/embed/video/"+id)
    if content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        xbmc.executebuiltin('XBMC.Notification(Info:,(DailyMotion)!,5000)')
        return ""
    else:
        matchFullHD = re.compile('"stream_h264_hd1080_url":"(.+?)"', re.DOTALL).findall(content)
        matchHD = re.compile('"stream_h264_hd_url":"(.+?)"', re.DOTALL).findall(content)
        matchHQ = re.compile('"stream_h264_hq_url":"(.+?)"', re.DOTALL).findall(content)
        matchSD = re.compile('"stream_h264_url":"(.+?)"', re.DOTALL).findall(content)
        matchLD = re.compile('"stream_h264_ld_url":"(.+?)"', re.DOTALL).findall(content)
        url = ""
        if matchFullHD and maxVideoQuality == "1080p":
            url = urllib.unquote_plus(matchFullHD[0]).replace("\\", "")
        elif matchHD and (maxVideoQuality == "720p" or maxVideoQuality == "1080p"):
            url = urllib.unquote_plus(matchHD[0]).replace("\\", "")
        elif matchHQ:
            url = urllib.unquote_plus(matchHQ[0]).replace("\\", "")
        elif matchSD:
            url = urllib.unquote_plus(matchSD[0]).replace("\\", "")
        elif matchLD:
            url = urllib.unquote_plus(matchLD[0]).replace("\\", "")
        return url

def extractFlashVars(data):
    for line in data.split("\n"):
            index = line.find("ytplayer.config =")
            if index != -1:
                found = True
                p1 = line.find("=", (index-3))
                p2 = line.rfind(";")
                if p1 <= 0 or p2 <= 0:
                        continue
                data = line[p1 + 1:p2]
                break
    if found:
            data=data.split(";(function()",1)[0]
            data=data.split(";ytplayer.load",1)[0]
            data = json.loads(data)
            flashvars = data["args"]
    return flashvars   
		
def selectVideoQuality(links):
        link = links.get
        video_url = ""
        fmt_value = {
                5: "240p h263 flv container",
                18: "360p h264 mp4 container | 270 for rtmpe?",
                22: "720p h264 mp4 container",
                26: "???",
                33: "???",
                34: "360p h264 flv container",
                35: "480p h264 flv container",
                37: "1080p h264 mp4 container",
                38: "720p vp8 webm container",
                43: "360p h264 flv container",
                44: "480p vp8 webm container",
                45: "720p vp8 webm container",
                46: "520p vp8 webm stereo",
                59: "480 for rtmpe",
                78: "seems to be around 400 for rtmpe",
                82: "360p h264 stereo",
                83: "240p h264 stereo",
                84: "720p h264 stereo",
                85: "520p h264 stereo",
                100: "360p vp8 webm stereo",
                101: "480p vp8 webm stereo",
                102: "720p vp8 webm stereo",
                120: "hd720",
                121: "hd1080"
        }
        hd_quality = 1

        # SD videos are default, but we go for the highest res
        #print video_url
        if (link(35)):
            video_url = link(35)
        elif (link(59)):
            video_url = link(59)
        elif link(44):
            video_url = link(44)
        elif (link(78)):
            video_url = link(78)
        elif (link(34)):
            video_url = link(34)
        elif (link(43)):
            video_url = link(43)
        elif (link(26)):
            video_url = link(26)
        elif (link(18)):
            video_url = link(18)
        elif (link(33)):
            video_url = link(33)
        elif (link(5)):
            video_url = link(5)

        if hd_quality > 1:  # <-- 720p
            if (link(22)):
                video_url = link(22)
            elif (link(45)):
                video_url = link(45)
            elif link(120):
                video_url = link(120)
        if hd_quality > 2:
            if (link(37)):
                video_url = link(37)
            elif link(121):
                video_url = link(121)

        if link(38) and False:
            video_url = link(38)
        for fmt_key in links.iterkeys():

            if link(int(fmt_key)):
                    text = repr(fmt_key) + " - "
                    if fmt_key in fmt_value:
                        text += fmt_value[fmt_key]
                    else:
                        text += "Unknown"

                    if (link(int(fmt_key)) == video_url):
                        text += "*"
            else:
                    print "- Missing fmt_value: " + repr(fmt_key)

        video_url += " | " + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'


        return video_url

def getYoutube(videoid):

                code = videoid
                linkImage = 'http://i.ytimg.com/vi/'+code+'/default.jpg'
                req = urllib2.Request('http://www.youtube.com/watch?v='+code+'&fmt=18')
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                
                if len(re.compile('shortlink" href="http://youtu.be/(.+?)"').findall(link)) == 0:
                        if len(re.compile('\'VIDEO_ID\': "(.+?)"').findall(link)) == 0:
                                req = urllib2.Request('http://www.youtube.com/get_video_info?video_id='+code+'&asv=3&el=detailpage&hl=en_US')
                                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                                response = urllib2.urlopen(req)
                                link=response.read()
                                response.close()
                
                flashvars = extractFlashVars(link)

                links = {}

                for url_desc in flashvars[u"url_encoded_fmt_stream_map"].split(u","):
                        url_desc_map = cgi.parse_qs(url_desc)
                        if not (url_desc_map.has_key(u"url") or url_desc_map.has_key(u"stream")):
                                continue

                        key = int(url_desc_map[u"itag"][0])
                        url = u""
                        if url_desc_map.has_key(u"url"):
                                url = urllib.unquote(url_desc_map[u"url"][0])
                        elif url_desc_map.has_key(u"stream"):
                                url = urllib.unquote(url_desc_map[u"stream"][0])

                        if url_desc_map.has_key(u"sig"):
                                url = url + u"&signature=" + url_desc_map[u"sig"][0]
                        links[key] = url
                highResoVid=selectVideoQuality(links)+"|Referer=https://www.youtube.com|Host=www.youtube.com"
                return highResoVid    


def addLink(name,url,mode,iconimage,mirrorname):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&mirrorname="+urllib.quote_plus(mirrorname)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        contextMenuItems = []
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def addNext(formvar,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&formvar="+str(formvar)+"&name="+urllib.quote_plus('Next >')
        ok=True
        liz=xbmcgui.ListItem('Next >', iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": 'Next >' } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param



params=get_params()
url=None
name=None
mode=None
formvar=None
mirrorname=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        mirrorname=urllib.unquote_plus(params["mirrorname"])
except:
        pass

sysarg=str(sys.argv[1])
print "mode is |" + str(mode)
if mode==None or url==None or len(url)<1:
        HOME()
elif mode==2:
        INDEX(url)
elif mode==3:
        loadVideos(url,mirrorname)
elif mode==4:
        SEARCH()
elif mode==5:
       Episodes(url,name)
elif mode==6:
       SearchResults(url)
elif mode==7:
       getServer(url,name)

xbmcplugin.endOfDirectory(int(sysarg))
