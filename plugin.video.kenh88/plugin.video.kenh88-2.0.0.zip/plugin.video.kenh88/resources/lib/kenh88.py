# -*- coding: utf-8 -*-
import urllib,urllib2,urlfetch, re, os, json
from utils import *
from common import *

class kenh88:
	def __init__(self,c):
		self.hd={'User-Agent':'Mozilla/5.0'}
		self.urlhome='http://www.kenh88.com/'
		
	def getDetail(self,s):
		tap=xsearch('class="process_r">([^<]+?)</span>',s)
		res=xsearch('class="status">([^<]+?)</span>',s)
		href='%sxem-phim-online/%s'%(self.urlhome,os.path.basename(xsearch('href="/([^"]+?)"',s)))
		title=xsearch('href="[^"]+?">[^<]+?</a>([^<]+?)</h2>',s)
		title=xsearch('href="[^"]+?">([^<].+?)</a>',s)+'-'+title
		title=' '.join(title.split())
		if res:title+='[COLOR blue]-%s[/COLOR]'%res
		if tap:title+='[COLOR gold]-%s[/COLOR]'%tap
		img=self.urlhome+urllib2.quote(xsearch('src="/([^"]+?)"',s))
		return tap,href,title,img
	
	def episode(self,url):
		b=xread(url.replace('/phim/','/xem-phim-online/'));d={};count=0
		items=refa('(class="server".+?</ul>)',b,re.S)
		if items:
			for s in items:
				count+=1
				i=xsearch('</i>(.+?)</div>',s).replace(':','')
				i='No name' if not i else '%d-%s'%(count,i)
				d[i]=[(self.urlhome+j[0],'Tập '+j[1]) for j in refa('<a href="/(.+?)"\s.+?>([^<]+?)</a>',s)]
		else:
			d['No name']=[]
			for s in refa("(<div class=''.+?<h2>.+?</div>)",b,re.S):
				tap,href,title,img=self.getDetail(s)
				d['No name'].append((tap,href))
		
		href=xsearch('class="next" href="/(.+?)\?',b)
		if href:
			pages=xsearch('>(\d{,4})</a></li><li><span>',b)
			#title=namecolor(name,c)+color['trangtiep']+' Trang tiep theo...trang %d/%s[/COLOR]'%(page+1,pages)
			#addir_info(title,urlhome+href,ico,'',mode,page+1,query,True)
		return d
	
	def getPage(self,url):
		b = xread(url)
		s = refa("<div class='(.+?)</div>\s", b, re.S)
		items=[self.getDetail(i.replace('\n','')) for i in s]

		pn=xsearch('class="next" href="/(.+?)\?',b)
		if pn:
			pages=xsearch('>(\d{,4})</a></li><li><span>',b)
			items.append((pages,self.urlhome+pn.replace('/page/','?page='),'pageNext',''))
		return items

		
	def openload(self,url):
		def getCaptcha(captcha_url):
			if captcha_url:
				solver=InputWindow(captcha=captcha_url)
				captcha=solver.get()
			else:captcha=''
			return captcha

		f=url.rsplit('/',2)[1];link=''
		l='https://api.openload.co/1/file/dlticket?file=%s&login=7f2b51527710f733&key=tegQWpjF'%f
		b=xread(l)
		try:j=json.loads(b)
		except:j={}
		result=j.get('result')
		if result:
			ticket=result.get('ticket','')
			captcha=getCaptcha(result.get('captcha_url'))
		else:
			try:import YDStreamExtractor;vid=True
			except:vid=False;mess(u'Cài đặt module youtube.dl để get link phim này')
			if vid:
				vid=YDStreamExtractor.getVideoInfo(url)
				if vid:link=vid.streamURL()
			ticket=captcha=''#;mess(xsearch('([^\.]+)',j.get('msg')))
		if ticket:
			l='https://api.openload.co/1/file/dl?file=%s&ticket=%s&captcha_response=%s'
			b=xread(l%(f,ticket,captcha))
			try:
				res=xget(json.loads(b).get('result').get('url'))
				if res:link=res.geturl();res.close()
			except:mess('Get link from openload.co Failed')
		return link
		
	def getLink(self,url):
		def getlink(b):
			link=''
			href=xsearch('\{link:.*"(.+?)"\}',b)
			ShowMessage("getlink88", "href: " + str(href))
			#write_file(addondir + "getlink_b.txt", str(b))
			if len(href)>20:
				data=urllib.urlencode({'link':href});label=0#;mess('link')
				jp=xread('http://www.kenh88.com/gkphp/plugins/gkpluginsphp.php',data=data)
				ShowMessage("getlink88 len(href)>20", "jp: " + str(jp))
				write_file(addondir + "getlink_b.txt", str(b) + "\n href: "+ str(href)  + "\n jp: " + str(jp))
				try:
					j=json.loads(jp).get('link')
					if isinstance(j,unicode):items=[(j,'')]
					else:items=ls([(i.get('link',''),rsl(i.get('label',''))) for i in j])
					for href,r in items:
						link=xcheck(href.replace('amp;',''))
						ShowMessage("getlink88 len(href)>20", "link: " + str(link))
						write_file(addondir + "getlink.txt", str(link))
						if link:break
				except:j={}
				
			
			elif xsearch('src="(.+?docid=.+?)"',b):
				#http://www.kenh88.com/xem-phim-online/nhat-ky-saimdang
				docid=xsearch('docid=(.+?)&',b).replace('amp;','')
				ShowMessage("getlink88", "docid: " + str(docid))
				if docid:
					link='https://docs.google.com/get_video_info?authuser=&eurl=%s&docid=%s'
					link=link%(urllib.quote_plus(url),docid)
					b=xget(link)#;xbmc.log(link+' '+b.cookiestring)
					cookie=b.headers.get('Set-Cookie')
					res={'36': 240, '38': 3072, '17': 144, '22': 720, '46': 1080, '18': 360, '44': 480, '45': 720, '37': 1080, '43': 360, '35': 480, '34': 360, '5': 240, '6': 270}
					try:
						s=dict(urllib2.urlparse.parse_qsl(b.read())).get('fmt_stream_map')
						items=[(i.split('|')[1],i.split('|')[0]) for i in s.split(',')]
						items=[(i[0],res.get(i[1],0)) for i in items]
						reverse=True if get_setting('resolut')=='Max' else False
						items=sorted(items, key=lambda k: int(k[1]) if k[1] else 0,reverse=reverse)
					except:items=[]
					hd_={'User-Agent':'Mozilla/5.0','Cookie':cookie}
					for href,label in items:
						resp=xget(href,hd_)#;xbmc.log(str(label)+' '+href)
						if resp:link=href;break
					if link:link+='|User-Agent=Mozilla/5.0&Cookie='+urllib.quote(cookie)
					write_file(addondir + "getlink88.txt", str(link))
					ShowMessage("getlink88", str(link))
			
			elif xsearch('iframe src="(.+?)"',b):
				href = xsearch('iframe src="(.+?)"',b).replace('amp;','')
				ShowMessage("getlink88 iframe src", "href: " + str(href) + "\n b: " + str(b))
				if href in hrefs:
					return ''
				hrefs.append(href)
				if 'openload.co' in href:
					#link=self.openload(href)#;mess('openload')
					from resources.lib.opl import openload
					link = openload(href)
					ShowMessage("getlink88 iframe src", "link: " + str(link))
					if not link:
						link = getOpenloadLink(xsearch('([\w|_|-]{10,})', href))
						ShowMessage("getlink88 iframe src", "getOpenloadLink: " + str(link))

				elif 'drive.google.com' in href:
					b=xread(href);mess('drive.google')
					try:s=eval(xsearch('(\["url_encoded_fmt.+?\])',b))[1]
					except:s=''
					if s:
						try:
							qsl=urllib2.urlparse.parse_qsl
							l=[dict(qsl(i.decode('unicode_escape'))) for i in s.split(',')]
						except:pass
						link=googleItems(l,'url','quality')
					#xbmc.log(str(l));xbmc.log(link)
				
				elif 'xtubeid.com' in href:
					#http://www.kenh88.com/xem-phim-online/anh-hung-chinh-nghia?link=737242
					def x(c):
						i='' if c<a else x(c/a)
						c=c%a
						j=chr(c+29) if c>35 else toBase36(c)
						return i+j
					
					self.hd['Referer']=url
					b=xread(href,self.hd)
					try:
						p,a,c,k,e,d=eval(xsearch('\}(\(.+?\))\)',b))
						while c:c-=1;d[x(c)] = k[c] or x(c)
						a=''
						for c,k in re.findall('(\W*(\w+)\W*)',p):
							a+=c.replace(k,d[k])
						d=json.loads('{"sources":'+xsearch('sources:(.+?)\],',a)).get('sources')
					except:d=[]
					link=googleItems(d,'file','label')
					#xbmc.log(str(d));xbmc.log('aaa '+link)
					return link

				elif 'dailymotion.com' in href:
					b = xread(href)
					b = xsearch('"stream_chromecast_url":"(.+?)"',b).replace('\\','')
					b = re.findall('(http.+)', xread(b))
					if b:
						link = b[len(b)-1]
				else:
					b=xread(href)
					l=re.findall('file: "([^"]+?)"[^"]+label: "([^"]+?)"',b,re.S)
					for href,r in ls([(i[0],rsl(i[1])) for i in l]):
						link=xcheck(href.replace('amp;',''))
						if link:break
			return link
		
		response=xsearch('(<div class="play".+?class="button">)',xread(url),1,re.S)
		hrefs=[]
		link=getlink(response)
		if not link:
			try:response=re.sub('<!--.+?-->','',response,flags=re.S)
			except:pass
			link=getlink(response)
		return link