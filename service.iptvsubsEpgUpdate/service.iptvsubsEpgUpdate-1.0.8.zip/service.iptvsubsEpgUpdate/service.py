import xbmcplugin,xbmcaddon
import time
import datetime
import xbmc
import os
import urllib2,json
import zipfile
import resources.lib.utils as utils
from resources.lib.croniter import croniter
from collections import namedtuple
from shutil import copyfile

__addon__ = xbmcaddon.Addon()
__author__ = __addon__.getAddonInfo('author')
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__cwd__ = __addon__.getAddonInfo('path')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString
debug = __addon__.getSetting("debug")
offset1hr = __addon__.getSetting("offset1hr")

class epgUpdater:
    def __init__(self):
        self.monitor = UpdateMonitor(update_method = self.settingsChanged)
        self.enabled = utils.getSetting("enable_scheduler")
        self.next_run = 0

        try:
          self.iptvsubs_addon = xbmcaddon.Addon('plugin.video.iptvsubs')
        except:
          utils.log("Failed to find iptvsubs addon")
          self.iptvsubs_addon = None
        try:
          self.pvriptvsimple_addon = xbmcaddon.Addon('pvr.iptvsimple')
        except:
          utils.log("Failed to find pvr.iptvsimple addon")
          self.pvriptvsimple_addon = None

    def run(self):
        utils.log("StalkerSettings::scheduler enabled, finding next run time")
        
        # Update when starting
        xbmc.executebuiltin('StopPVRManager()')
        self.updateM3u()
        self.updateEpg()
        xbmc.executebuiltin('StartPVRManager()')

        self.findNextRun(time.time())
        while(not xbmc.abortRequested):
            # Sleep/wait for abort for 10 seconds
            now = time.time()
            if(self.next_run <= now):
                if self.enabled:
                    self.updateEpg()
                    self.findNextRun(now)
            else:
                self.findNextRun(now)
            xbmc.sleep(500)
        # del self.monitor

    def installKeyboardFile(self):
      keyboard_file_path = os.path.join(xbmc.translatePath('special://home'), 'addons/service.iptvsubsEpgUpdate/keyboard.xml')
      if os.path.isfile(keyboard_file_path):
        utils.log("Keyboard file found.  Copying...")
        copyfile(keyboard_file_path, os.path.join(xbmc.translatePath('special://userdata'), 'keymaps/keyboard.xml'))

    def settingsChanged(self):
        utils.log("Settings changed - update")
        utils.refreshAddon()
        current_enabled = utils.getSetting("enable_scheduler")
        install_keyboard_file = utils.getSetting("install_keyboard_file")
        if install_keyboard_file == 'true':
          self.installKeyboardFile()
          utils.setSetting('install_keyboard_file', 'false')
          # Return since this is going to be run immediately again
          return

        if(self.enabled == "true"):
            #always recheck the next run time after an update
            utils.log('recalculate start time , after settings update')
            self.findNextRun(time.time())

    def parseSchedule(self):
        schedule_type = int(utils.getSetting("schedule_interval"))
        cron_exp = utils.getSetting("cron_schedule")

        hour_of_day = utils.getSetting("schedule_time")
        hour_of_day = int(hour_of_day[0:2])
        if(schedule_type == 0 or schedule_type == 1):
            #every day
            cron_exp = "0 " + str(hour_of_day) + " * * *"
        elif(schedule_type == 2):
            #once a week
            day_of_week = utils.getSetting("day_of_week")
            cron_exp = "0 " + str(hour_of_day) + " * * " + day_of_week
        elif(schedule_type == 3):
            #first day of month
            cron_exp = "0 " + str(hour_of_day) + " 1 * *"

        return cron_exp


    def findNextRun(self,now):
        #find the cron expression and get the next run time
        cron_exp = self.parseSchedule()
        cron_ob = croniter(cron_exp,datetime.datetime.fromtimestamp(now))
        new_run_time = cron_ob.get_next(float)
        # utils.log('new run time' +  str(new_run_time))
        # utils.log('next run time' + str(self.next_run))
        if(new_run_time != self.next_run):
            self.next_run = new_run_time
            utils.showNotification('EPG Updater', 'Next Update: ' + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))
            utils.log("scheduler will run again on " + datetime.datetime.fromtimestamp(self.next_run).strftime('%m-%d-%Y %H:%M'))


    def updateM3u(self):
        if self.iptvsubs_addon is None:
            utils.log("iptvsubs addon missing")
            return
        if self.pvriptvsimple_addon is None:
            utils.log("pvriptvsimple addon missing")
            return

        utils.log("Updating m3u file")
        username = self.iptvsubs_addon.getSetting('kasutajanimi')
        password = self.iptvsubs_addon.getSetting('salasona')
        updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.iptvsubs')

        cm_path = os.path.join(xbmc.translatePath('special://home'), 'addons/service.iptvsubsEpgUpdate/channel_guide_map.txt')

        channel_map = {}
        if os.path.isfile(cm_path):
          utils.log('Adding mapped guide ids')
          with open(cm_path) as f:
            for line in f:
              channel_name,guide_id = line.rstrip().split("\t")
              channel_map[channel_name] = guide_id

        panel_url = "http://2.welcm.tv:8000/panel_api.php?username={0}&password={1}".format(username, password)
        u = urllib2.urlopen(panel_url)
        j = json.loads(u.read())

        Channel = namedtuple('Channel', ['tvg_id', 'tvg_name', 'tvg_logo', 'group_title', 'channel_url'])
        channels = []

        wanted_groups = ['ENGLISH','SPORTS','FOR ADULTS', 'VIETNAMESE', 'CHINESE', 'SPANISH']
        group_idx = {}
        for idx,group in enumerate(wanted_groups):
          group_idx[group] = idx

        for ts_id, info in j["available_channels"].iteritems():
            channel_url = "http://2.welcm.tv:8000/live/{0}/{1}/{2}.ts".format(username, password, ts_id)
            tvg_id = "" 
            tvg_name = info['name']
            if tvg_name.endswith(' - NEW'):
              tvg_name = tvg_name[:-6]
            #if info['epg_channel_id'] and info['epg_channel_id'].endswith(".com"):
            #    tvg_id = info['epg_channel_id']
            if tvg_name in channel_map:
                tvg_id = 'tvg-id="{0}"'.format(channel_map[tvg_name])
            else:
                tvg_id = ""
            tvg_logo = ""
            #if info['stream_icon']:
            #  tvg_logo = info['stream_icon']
            group_title = info['category_name']
            if group_title == None:
                group_title = 'None'
            channels.append(Channel(tvg_id, tvg_name, tvg_logo, group_title, channel_url))

        wanted_channels = [c for c in channels if c.group_title in wanted_groups]
        wanted_channels.sort(key=lambda c: "{0}-{1}".format(group_idx[c.group_title], c.tvg_name))

        with open("{0}/iptvsubs.m3u".format(updater_path), "w") as m3u_f:
            m3u_f.write("#EXTM3U\n")
            for c in wanted_channels:
                m3u_f.write('#EXTINF:-1 tvg-name="{0}" {1} tvg-logo="{2}" group-title="{3}",{0}\n{4}\n'.format(c.tvg_name, c.tvg_id, c.tvg_logo, c.group_title, c.channel_url))

        self.pvriptvsimple_addon.setSetting("epgCache", "false")
        self.pvriptvsimple_addon.setSetting("epgPathType", "0")
        self.pvriptvsimple_addon.setSetting("epgPath", updater_path + '/iptvsubs_xmltv.xml.gz')
        self.pvriptvsimple_addon.setSetting("m3uPathType", "0")
        self.pvriptvsimple_addon.setSetting("m3uPath", "{0}/iptvsubs.m3u".format(updater_path))

    def updateEpg(self):
        epgFileName = 'merged.xml.gz'
        epgFile = None
        updater_path = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data/plugin.video.iptvsubs')

        if self.iptvsubs_addon != None:
            try:
                response = urllib2.urlopen('https://github.com/psyc0n/epgninja/raw/master/'+epgFileName)
                epgFile = response.read()
            except:
                utils.log('StalkerSettings: Some issue with epg file')
                pass

            if epgFile:
                epgFH = open(updater_path + '/iptvsubs_xmltv.xml.gz', "wb")
                epgFH.write(epgFile)
                epgFH.close()

class UpdateMonitor(xbmc.Monitor):
    update_method = None

    def __init__(self,*args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.update_method = kwargs['update_method']

    def onSettingsChanged(self):
        self.update_method()

if __name__ == "__main__":
  epg_updater = epgUpdater()
  epg_updater.run()
