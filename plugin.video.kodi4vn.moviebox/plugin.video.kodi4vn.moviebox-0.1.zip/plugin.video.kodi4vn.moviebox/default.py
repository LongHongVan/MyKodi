#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , urllib2 , re , zlib , ast , os , uuid , json
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
oo000 = Plugin ( )
ii = "plugin://plugin.video.kodi4vn.moviebox"
oOOo = 32
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
@ oo000 . route ( '/' )
def IIi1IiiiI1Ii ( ) :
 I11i11Ii ( "None" , "None" )
 oO00oOo = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 oO00oOo = xbmc . translatePath ( os . path . join ( oO00oOo , "temp.jpg" ) )
 urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/moviebox.jpg' , oO00oOo )
 OOOo0 = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , oO00oOo )
 Oooo000o = xbmcgui . WindowDialog ( )
 Oooo000o . addControl ( OOOo0 )
 #Oooo000o . doModal ( )
 if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
 IiII = [
 { 'label' : 'Phim mới' , 'path' : '%s/latest/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilm' ) ) } ,
 { 'label' : 'Phóng Sự & Tài Liệu' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '33' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/13333734-Phim-Tai-Lieu.jpg' } ,
 { 'label' : 'Ca Nhạc' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '34' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/99844308-Ca-nhac.jpg' } ,
 { 'label' : 'Hài Kịch' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '35' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/519820-Hai-Kich.jpg' } ,
 { 'label' : 'Phim Lẻ' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '36' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/6855131-MOD.jpg' } ,
 { 'label' : 'Phim Bộ' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '37' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/46252803-Phim-Bo.jpg' } ,
 { 'label' : 'Truyền Hình' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '38' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/14266234-Live-TV.jpg' } ,
 { 'label' : 'Nghe Truyện Đọc' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '40' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/3488938-Sach-Noi.jpg' } ,
 { 'label' : 'Dạy Nấu Ăn' , 'path' : '%s/genres/%s/%s' % ( ii , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetListFilmByCate' ) , '41' ) , 'thumbnail' : 'http://ictvnow.nl/vod/images/category/14376243-Am-Nhac.jpg' }
 ]
 return oo000 . finish ( IiII )
 if 28 - 28: Ii11111i * iiI1i1
@ oo000 . route ( '/latest/<murl>' )
def i1I1ii1II1iII ( murl ) :
 I11i11Ii ( "Browse" , '/latest/%s' % murl )
 IiII = oooO0oo0oOOOO ( murl , '' )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( IiII , view_mode = 52 )
 else :
  return oo000 . finish ( IiII )
  if 53 - 53: o0oo0o / Oo + OOo00O0Oo0oO / iIi * ooO00oOoo - O0OOo
@ oo000 . route ( '/genres/<murl>/<mid>' )
def II1Iiii1111i ( murl , mid ) :
 I11i11Ii ( "Browse" , '/genres/%s/%s' % ( murl , mid ) )
 IiII = oooO0oo0oOOOO ( murl , mid )
 if xbmc . getSkinDir ( ) == 'skin.xeebo' and oo000 . get_setting ( 'thumbview' , bool ) :
  return oo000 . finish ( IiII , view_mode = 52 )
 else :
  return oo000 . finish ( IiII )
  if 25 - 25: OOo000
@ oo000 . route ( '/mirrors/<murl>/<mid>' )
def O0 ( murl , mid ) :
 I11i11Ii ( "Browse" , '/mirrors/%s/%s' % ( murl , mid ) )
 IiII = [ ]
 for I11i1i11i1I in Iiii ( murl , mid ) :
  OOO0O = { }
  OOO0O [ "label" ] = I11i1i11i1I [ "name" ] . strip ( )
  oo0ooO0oOOOOo = str ( uuid . uuid1 ( ) )
  oO000OoOoo00o = oo000 . get_storage ( oo0ooO0oOOOOo )
  oO000OoOoo00o [ "list" ] = I11i1i11i1I [ "eps" ]
  OOO0O [ "path" ] = '%s/eps/%s' % ( ii , urllib . quote_plus ( oo0ooO0oOOOOo ) )
  IiII . append ( OOO0O )
 return oo000 . finish ( IiII )
 if 31 - 31: i1 + I11i . O0OOo
@ oo000 . route ( '/eps/<eps_list>' )
def OoOooOOOO ( eps_list ) :
 I11i11Ii ( "Browse" , '/eps' )
 IiII = [ ]
 for i11iiII in oo000 . get_storage ( eps_list ) [ "list" ] :
  OOO0O = { }
  OOO0O [ "label" ] = i11iiII [ "name" ] . strip ( )
  OOO0O [ "is_playable" ] = True
  OOO0O [ "path" ] = '%s/play/%s' % ( ii , urllib . quote_plus ( i11iiII [ "url" ] ) )
  IiII . append ( OOO0O )
 return oo000 . finish ( IiII )
 if 34 - 34: o0oo0o % iII111iiiii11 / I1IiiI . iIi + OO0OO0O0O0
@ oo000 . route ( '/play/<mid>' )
def I1Ii ( mid ) :
 I11i11Ii ( "Play" , '/play/%s' % ( mid ) )
 o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
 o0oOo0Ooo0O . create ( 'MovieBox' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( OO00O0O0O00Oo ( mid ) )
 o0oOo0Ooo0O . close ( )
 del o0oOo0Ooo0O
 if 25 - 25: IiiIII111iI % i1 - i1 . i1
def OO00O0O0O00Oo ( mid ) :
 Ii1 = oOOoO0 ( "http://ictvnow.nl/vod/Api/GetLinkByEpiId" , mid )
 O0OoO000O0OO = json . loads ( Ii1 ) [ "link" ] [ 0 ] [ "url" ]
 iiI1IiI = ""
 if "youtube" in O0OoO000O0OO :
  II = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( O0OoO000O0OO )
  ooOoOoo0O = II [ 0 ] [ len ( II [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
  return 'plugin://plugin.video.youtube/play/?video_id=%s' % ooOoOoo0O
 if "picasa" in O0OoO000O0OO :
  OooO0 = re . compile ( 'authkey=(.+?)#' ) . findall ( O0OoO000O0OO )
  II11iiii1Ii = re . compile ( 'https://picasaweb.google.com/(\d+)/' ) . findall ( O0OoO000O0OO )
  OO0o = re . compile ( '#(\d+)' ) . findall ( O0OoO000O0OO )
  Ooo = 480
  if oo000 . get_setting ( 'HQ' , bool ) :
   Ooo = 720
  if ( II11iiii1Ii and OO0o ) :
   O0o0Oo = "https://picasaweb.google.com/data/feed/api/user/%s/photoid/%s?alt=json%s" % ( II11iiii1Ii [ 0 ] , OO0o [ 0 ] , "" if not OooO0 else "&authkey=" + OooO0 [ 0 ] )
   Ii1 = urllib2 . urlopen ( O0o0Oo ) . read ( )
   Oo00OOOOO = json . loads ( Ii1 ) [ "feed" ] [ "media$group" ] [ "media$content" ]
   for O0O in Oo00OOOOO :
    if ( O0O [ "type" ] == "video/mpeg4" ) and ( int ( O0O [ "height" ] ) <= Ooo ) :
     iiI1IiI = O0O [ "url" ]
  else :
   Ii1 = urllib2 . urlopen ( O0OoO000O0OO ) . read ( )
   O0o0Oo = re . compile ( '(https://picasaweb.google.com/data/feed/tiny/user/\d+/photoid/\d+\?alt=jsonm&gupi=.+?)"' ) . findall ( Ii1 ) [ 0 ]
   Ii1 = urllib2 . urlopen ( O0o0Oo ) . read ( )
   Oo00OOOOO = json . loads ( Ii1 ) [ "feed" ] [ "media" ] [ "content" ]
   for O0O in Oo00OOOOO :
    if ( O0O [ "type" ] == "video/mpeg4" ) and ( int ( O0O [ "height" ] ) <= Ooo ) :
     iiI1IiI = O0O [ "url" ]
  return iiI1IiI
  if 83 - 83: Oo + i1 * IiiIII111iI % I11i + Oo
def oooO0oo0oOOOO ( url , mid ) :
 Ii1 = oOOoO0 ( url , mid )
 IiII = [ ]
 for Ii1iIIIi1ii in json . loads ( Ii1 ) [ "film" ] :
  OOO0O = { }
  OOO0O [ "label" ] = Ii1iIIIi1ii [ "title_en" ]
  OOO0O [ "thumbnail" ] = Ii1iIIIi1ii [ "cover_image" ] if ( "://" in Ii1iIIIi1ii [ "cover_image" ] ) else "http://ictvnow.nl" + urllib . quote ( Ii1iIIIi1ii [ "cover_image" ] . encode ( "utf8" ) )
  OOO0O [ "path" ] = '%s/%s/%s/%s' % ( ii , "mirrors" , urllib . quote_plus ( 'http://ictvnow.nl/vod/Api/GetEpiByFilmId' ) , Ii1iIIIi1ii [ "ID" ] . strip ( ) )
  IiII . append ( OOO0O )
 return IiII
 if 80 - 80: Oo * Oo0Ooo / O0OOo
def Iiii ( murl , mid ) :
 Ii1 = oOOoO0 ( murl , mid )
 I11II1i = [ ]
 for IIIII in json . loads ( Ii1 ) [ "server" ] :
  ooooooO0oo = [ ]
  for IIiiiiiiIi1I1 in IIIII [ "data" ] :
   i11iiII = { }
   i11iiII [ "url" ] = IIiiiiiiIi1I1 [ "ID" ]
   i11iiII [ "name" ] = IIiiiiiiIi1I1 [ "name" ]
   ooooooO0oo . append ( i11iiII )
  I11i1i11i1I = { }
  I11i1i11i1I [ "name" ] = "%s - %s (%s tập)" % ( IIIII [ "alias" ] . encode ( "utf8" ) , IIIII [ "name" ] . encode ( "utf8" ) , IIIII [ "episode" ] )
  I11i1i11i1I [ "eps" ] = ooooooO0oo
  I11II1i . append ( I11i1i11i1I )
 return I11II1i
 if 13 - 13: ooO00oOoo + o0O - iII111iiiii11 + O0OOo . iIi + I11i
 if 8 - 8: iiiIIii1IIi . ii1IiI1i - iiiIIii1IIi * OOo00O0Oo0oO
def oOOoO0 ( url , mid ) :
 OOOO = urllib2 . Request ( url )
 OOOO . add_header ( 'Accept-Encoding' , 'gzip, deflate, sdch' )
 OOO00 = ""
 if mid != "" :
  if 21 - 21: iII111iiiii11 - iII111iiiii11
  if "GetListFilmByCate" in url :
   iIii11I = urllib . urlencode ( { 'cateid' : mid } )
  else :
   iIii11I = urllib . urlencode ( { 'id' : mid } )
  OOO0OOO00oo = urllib2 . urlopen ( OOOO , data = iIii11I )
  OOO00 = OOO0OOO00oo . read ( )
  OOO0OOO00oo . close ( )
  if "gzip" in OOO0OOO00oo . info ( ) . getheader ( 'Content-Encoding' ) :
   OOO00 = zlib . decompress ( OOO00 , 16 + zlib . MAX_WBITS )
  return OOO00
 else :
  OOO0OOO00oo = urllib2 . urlopen ( OOOO )
  OOO00 = OOO0OOO00oo . read ( )
  OOO0OOO00oo . close ( )
  if "gzip" in OOO0OOO00oo . info ( ) . getheader ( 'Content-Encoding' ) :
   OOO00 = zlib . decompress ( OOO00 , 16 + zlib . MAX_WBITS )
  return OOO00
  if 31 - 31: i1 - o0oo0o . O0OOo % o0O - OO0OO0O0O0
iii11 = xbmc . translatePath ( xbmcaddon . Addon ( 'plugin.video.kodi4vn.moviebox' ) . getAddonInfo ( 'profile' ) )
if 58 - 58: o0oo0o * Oo0Ooo / o0O % O0OOo - Ii11111i / iiI1i1
if os . path . exists ( iii11 ) == False :
 os . mkdir ( iii11 )
ii11i1 = os . path . join ( iii11 , 'visitor' )
if 29 - 29: Ii11111i % ii1IiI1i + OOo000 / IiiIII111iI + o0oo0o * IiiIII111iI
if os . path . exists ( ii11i1 ) == False :
 from random import randint
 i1I1iI = open ( ii11i1 , "w" )
 i1I1iI . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 i1I1iI . close ( )
 if 93 - 93: iiiIIii1IIi % iiI1i1 * I1IiiI
def Ii11Ii1I ( utm_url ) :
 O00oO = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  OOOO = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : O00oO }
 )
  OOO0OOO00oo = urllib2 . urlopen ( OOOO ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return OOO0OOO00oo
 if 39 - 39: ooO00oOoo - i1 * I11i % IiiIII111iI * i1 % i1
def I11i11Ii ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  OoOOOOO = "1.0"
  iIi1i111II = open ( ii11i1 ) . read ( )
  OoOO00O = "MovieBox"
  oOOoO0O0O0 = "UA-52209804-2"
  Oo000o = "www.viettv24.com"
  I11IiI1I11i1i = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   iI1ii1Ii = I11IiI1I11i1i + "?" + "utmwv=" + OoOOOOO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OoOO00O ) + "&utmac=" + oOOoO0O0O0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iIi1i111II , "1" , "1" , "2" ] )
   if 92 - 92: o0O
   if 26 - 26: iIi . O0OOo
   if 68 - 68: I11i
   if 35 - 35: I11i - iIi / OOooOOo / o0O
   if 24 - 24: OOo000 - OOo000 / i1 - Ii11111i
  else :
   if group == "None" :
    iI1ii1Ii = I11IiI1I11i1i + "?" + "utmwv=" + OoOOOOO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OoOO00O + "/" + name ) + "&utmac=" + oOOoO0O0O0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iIi1i111II , "1" , "1" , "2" ] )
    if 69 - 69: iiI1i1 . O0OOo + OOo00O0Oo0oO / OOooOOo - iiI1i1
    if 63 - 63: o0oo0o % iiI1i1 * iiI1i1 * I11i / Ii11111i
    if 74 - 74: i1
    if 75 - 75: IiiIII111iI . OOo000
    if 54 - 54: i1 % o0O % Oo % iiiIIii1IIi + iiiIIii1IIi * OOo000
   else :
    iI1ii1Ii = I11IiI1I11i1i + "?" + "utmwv=" + OoOOOOO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( OoOO00O + "/" + group + "/" + name ) + "&utmac=" + oOOoO0O0O0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , iIi1i111II , "1" , "1" , "2" ] )
    if 87 - 87: OOo000 * OOooOOo % Oo0Ooo % o0O - o0oo0o
    if 68 - 68: O0OOo % I1IiiI . ooO00oOoo . Ii11111i
    if 92 - 92: iIi . O0OOo
    if 31 - 31: O0OOo . o0O / OO0OO0O0O0
    if 89 - 89: o0O
    if 68 - 68: I11i * iII111iiiii11 % OO0OO0O0O0 + I11i + OOo000
  print "============================ POSTING ANALYTICS ============================"
  Ii11Ii1I ( iI1ii1Ii )
  if 4 - 4: OOo000 + OO0OO0O0O0 * o0oo0o
  if not group == "None" :
   OOoo0O = I11IiI1I11i1i + "?" + "utmwv=" + OoOOOOO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( Oo000o ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + OoOO00O + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( OoOO00O ) + "&utmac=" + oOOoO0O0O0 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , iIi1i111II , "1" , "2" ] )
   if 67 - 67: Oo0Ooo - I1IiiI % Ii11111i . OO0OO0O0O0
   if 77 - 77: ooO00oOoo / ii1IiI1i
   if 15 - 15: ooO00oOoo . iiiIIii1IIi . iII111iiiii11 / Oo0Ooo - OOo00O0Oo0oO . I1IiiI
   if 33 - 33: Oo . IiiIII111iI
   if 75 - 75: IiiIII111iI % IiiIII111iI . O0OOo
   if 5 - 5: IiiIII111iI * OOo000 + o0O . o0oo0o + o0O
   if 91 - 91: OO0OO0O0O0
   if 61 - 61: i1
   try :
    print "============================ POSTING TRACK EVENT ============================"
    Ii11Ii1I ( OOoo0O )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 64 - 64: OOo000 / o0O - OO0OO0O0O0 - Oo
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 86 - 86: Oo % o0O / ii1IiI1i / o0O
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
