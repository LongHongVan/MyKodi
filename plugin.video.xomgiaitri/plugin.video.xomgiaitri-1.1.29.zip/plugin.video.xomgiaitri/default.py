#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xomgiaitri'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = "http://www.xom60.com/"
XomGiaiTriWebCat = "http://www.xom60.com/web/category/"
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
def iI1 ( ) :
 i1I11i ( 'Search' , iiiii + 'web/search/%s/1.html' , 'search' , 'http://echipstore.net/addonicons/Search.jpg' )
 i1I11i ( 'Phim Lẻ' , iiiii + 'web/list/phim-dien-anh' , 'index' , 'http://echipstore.net/addonicons/Movies.jpg' )
 i1I11i ( 'Phim Bộ' , iiiii + 'web/list/phim-bo' , 'index' , 'http://echipstore.net/addonicons/Series.jpg' )
 i1I11i ( 'Phim Bộ theo Quốc Gia' , iiiii , 'videosbyregion' , 'http://echipstore.net/addonicons/Regions.jpg' )
 i1I11i ( 'Phim Lẻ theo Thể Loại' , iiiii , 'videosbycategory' , 'http://echipstore.net/addonicons/Categories.jpg' )
 if 73 - 73: III - oo00oOOo * Oooo000o % OOo . OOO
 IiI1ii1 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 IiI1ii1 = xbmc . translatePath ( os . path . join ( IiI1ii1 , "temp.jpg" ) )
 urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/xomgiaitri.jpg' , IiI1ii1 )
 oooOOooo = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , IiI1ii1 )
 o0oo0oo0OO00 = xbmcgui . WindowDialog ( )
 o0oo0oo0OO00 . addControl ( oooOOooo )
 #o0oo0oo0OO00 . doModal ( )
 if 20 - 20: i111iII
def oOOo ( ) :
 i1I11i ( "Hồng Kong" , XomGiaiTriWebCat + "1/phim-bo-hong-kong.html" , "index" , "" )
 i1I11i ( "Hồng Kong (VNLT)" , XomGiaiTriWebCat + "28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 i1I11i ( "Hàn Quốc" , XomGiaiTriWebCat + "4/phim-bo-han-quoc.html" , "index" , "" )
 i1I11i ( "Hàn Quốc (vietsub)" , XomGiaiTriWebCat + "29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 i1I11i ( "Trung Quốc" , XomGiaiTriWebCat + "2/phim-bo-trung-quoc.html" , "index" , "" )
 i1I11i ( "Đài Loan" , XomGiaiTriWebCat + "3/phim-bo-dai-loan.html" , "index" , "" )
 i1I11i ( "Việt Nam" , XomGiaiTriWebCat + "5/phim-bo-viet-nam.html" , "index" , "" )
 i1I11i ( "Thái Lan" , XomGiaiTriWebCat + "22/phim-bo-thai-lan.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , XomGiaiTriWebCat + "7/cac-loai-khac.html" , "index" , "" )
 if 25 - 25: O0 + OoOoOoO0o0OO * Ooo0OO0oOO * Ii * o0o - OOO0o0o
def Ii1iI ( ) :
 i1I11i ( "Hành Động" , XomGiaiTriWebCat + "8/hanh-dong.html" , "index" , "" )
 i1I11i ( "Tình Cảm" , XomGiaiTriWebCat + "9/tinh-cam.html" , "index" , "" )
 i1I11i ( "Phim Hài" , XomGiaiTriWebCat + "10/phim-hai.html" , "index" , "" )
 i1I11i ( "Kinh Dị" , XomGiaiTriWebCat + "11/kinh-di.html" , "index" , "" )
 i1I11i ( "Kiếm Hiệp" , XomGiaiTriWebCat + "12/kiem-hiep.html" , "index" , "" )
 i1I11i ( "Việt Nam" , XomGiaiTriWebCat + "15/viet-nam.html" , "index" , "" )
 i1I11i ( "Hài Kịch" , XomGiaiTriWebCat + "16/hai-kich.html" , "index" , "" )
 i1I11i ( "Ca Nhạc" , XomGiaiTriWebCat + "17/ca-nhac.html" , "index" , "" )
 i1I11i ( "Cải Lương" , XomGiaiTriWebCat + "18/cai-luong.html" , "index" , "" )
 i1I11i ( "Phóng Sự" , XomGiaiTriWebCat + "19/phong-su.html" , "index" , "" )
 i1I11i ( "Các Loại Khác" , XomGiaiTriWebCat + "20/cac-loai-khac.html" , "index" , "" )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * OOO - i11iIiiIii
def II1Iiii1111i ( url ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 oo = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( i1IIi11111i )
 for IiII1I1i1i1ii , IIIII , I1 in oo :
  i1I11i ( "[B]" + IIIII + "[/B]" , iiiii + "xem" + IiII1I1i1i1ii , 'mirrors' , I1 )
 O0OoOoo00o = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( i1IIi11111i . replace ( "'" , '"' ) )
 for IiII1I1i1i1ii , iiiI11 in O0OoOoo00o :
  i1I11i ( iiiI11 , IiII1I1i1i1ii . replace ( "./" , iiiii + "xem/" ) , 'index' , "" )
 OOooO = xbmc . getSkinDir ( )
 if 58 - 58: OOO + i111iII / OOO0o0o * oOooOoO0Oo0O
def II111iiii ( ) :
 try :
  II = xbmc . Keyboard ( '' , 'Enter search text' )
  II . doModal ( )
  if 63 - 63: i111iII % III
  if ( II . isConfirmed ( ) ) :
   o0oOo0Ooo0O = urllib . quote_plus ( II . getText ( ) )
  II1Iiii1111i ( OO00O0O0O00Oo % o0oOo0Ooo0O )
 except : pass
 if 25 - 25: O0 % oo00oOOo - oo00oOOo . oo00oOOo
def Ii1 ( url ) :
 oOOoO0 = O0OoO000O0OO ( url )
 i1IIi11111i = o000o0o00o0Oo ( oOOoO0 )
 iiI1IiI = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( i1IIi11111i )
 for IIooOoOoo0O in iiI1IiI :
  OooO0 = [ ]
  if not any ( x in IIooOoOoo0O for x in OooO0 ) :
   i1I11i ( IIooOoOoo0O , oOOoO0 . encode ( "utf-8" ) , 'episodes' , "" )
   if 35 - 35: Ii % OOoO % i11iIiiIii / oOooOoO0Oo0O
def Ii11iI1i ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 Ooo = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % urllib2 . unquote ( name ) ) . findall ( i1IIi11111i )
 O0o0Oo = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( Ooo [ 0 ] )
 if ( "episode_bg_2" in Ooo [ 0 ] ) :
  Oo00OOOOO = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( Ooo [ 0 ] )
  O0O ( "Part - " + Oo00OOOOO [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , url , 'loadvideo' , '' , name . encode ( "utf-8" ) )
 for O00o0OO , I11i1 in O0o0Oo :
  O0O ( "Part - " + I11i1 . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , iiiii + "xem/" + O00o0OO , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 25 - 25: OOo - ooO . oOooOoO0Oo0O
def O0OoO000O0OO ( url ) :
 I11ii1 = o000o0o00o0Oo ( url )
 return re . compile ( '<p class="w_now"><a href="(.+?)" title="Xem phim trực tuyến">' ) . findall ( I11ii1 ) [ 0 ]
 if 9 - 9: OOO0o0o + Ooo0OO0oOO % OOO0o0o + III . Ii
def III1i1i ( url , name ) :
 i1IIi11111i = o000o0o00o0Oo ( url )
 if ( "proxy.link" in i1IIi11111i ) :
  iiI1 = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( i1IIi11111i )
  i1IIi11111i = o000o0o00o0Oo ( iiI1 [ 0 ] )
  if 19 - 19: o0o + ooo0Oo0
 iiI1 = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( i1IIi11111i )
 ooo = xbmcgui . ListItem ( name )
 ooo . setProperty ( "IsPlayable" , "true" )
 ooo . setPath ( iiI1 [ 0 ] )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooo )
 if 18 - 18: O0
def o000o0o00o0Oo ( url ) :
 I1i1I1II = urllib2 . Request ( url )
 I1i1I1II . add_header ( 'Host' , 'xomgiaitri.com' )
 I1i1I1II . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 I1i1I1II . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 i1 = urllib2 . urlopen ( I1i1I1II )
 i1IIi11111i = i1 . read ( )
 i1 . close ( )
 i1IIi11111i = '' . join ( i1IIi11111i . splitlines ( ) ) . replace ( '\'' , '"' )
 i1IIi11111i = i1IIi11111i . replace ( '\n' , '' )
 i1IIi11111i = i1IIi11111i . replace ( '\t' , '' )
 i1IIi11111i = re . sub ( '  +' , ' ' , i1IIi11111i )
 i1IIi11111i = i1IIi11111i . replace ( '> <' , '><' )
 return i1IIi11111i
 if 48 - 48: iIIi1iI1II111 + iIIi1iI1II111 - OoOoOoO0o0OO . ooo0Oo0 / ii11i
def O0O ( name , url , mode , iconimage , mirrorname ) :
 OoOOO00oOO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 oOoo = True
 iIii11I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iIii11I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iIii11I . setProperty ( "IsPlayable" , "true" )
 oOoo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOOO00oOO0 , listitem = iIii11I )
 return oOoo
 if 69 - 69: Ooo0OO0oOO % OOoO - O0 + OOoO - iIIi1iI1II111 % oOooOoO0Oo0O
def i1I11i ( name , url , mode , iconimage ) :
 OoOOO00oOO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 oOoo = True
 iIii11I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iIii11I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOOO00oOO0 , listitem = iIii11I , isFolder = True )
 return oOoo
 if 31 - 31: oo00oOOo - Ii . OOoO % i111iII - iIIi1iI1II111
def iii11 ( k , e ) :
 O0oo0OO0oOOOo = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for i1i1i11IIi in range ( len ( e ) ) :
  II1III = k [ i1i1i11IIi % len ( k ) ]
  iI1iI1I1i1I = chr ( ( 256 + ord ( e [ i1i1i11IIi ] ) - ord ( II1III ) ) % 256 )
  O0oo0OO0oOOOo . append ( iI1iI1I1i1I )
 return "" . join ( O0oo0OO0oOOOo )
 if 24 - 24: OoOoOoO0o0OO
def o0Oo0O0Oo00oO ( parameters ) :
 I11i1I1I = { }
 if 83 - 83: OoOoOoO0o0OO / ooo0Oo0
 if parameters :
  iIIIIii1 = parameters [ 1 : ] . split ( "&" )
  for oo000OO00Oo in iIIIIii1 :
   O0OOO0OOoO0O = oo000OO00Oo . split ( '=' )
   if ( len ( O0OOO0OOoO0O ) ) == 2 :
    I11i1I1I [ O0OOO0OOoO0O [ 0 ] ] = O0OOO0OOoO0O [ 1 ]
 return I11i1I1I
 if 70 - 70: ooO * OOo * o0o / OOO0o0o
oO = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 93 - 93: OOO % Ooo0OO0oOO . OOO * OOoO % OOO0o0o . oo00oOOo
if os . path . exists ( oO ) == False :
 os . mkdir ( oO )
iI1ii1Ii = os . path . join ( oO , 'visitor' )
if 92 - 92: i111iII
if os . path . exists ( iI1ii1Ii ) == False :
 from random import randint
 i1OOO = open ( iI1ii1Ii , "w" )
 i1OOO . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 i1OOO . close ( )
 if 59 - 59: oo00oOOo + oOooOoO0Oo0O * i111iII + III
def Oo0OoO00oOO0o ( utm_url ) :
 OOO00O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  I1i1I1II = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : OOO00O }
 )
  i1 = urllib2 . urlopen ( I1i1I1II ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return i1
 if 84 - 84: Ooo0OO0oOO * OOO / o0o - iIIi1iI1II111
def IiI1 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  Oo0O00Oo0o0 = "1.0"
  O00O0oOO00O00 = open ( iI1ii1Ii ) . read ( )
  i1Oo00 = "XomGiaiTri"
  i1i = "UA-52209804-2"
  iiI111I1iIiI = "www.viettv24.com"
  IIIi1I1IIii1II = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   O0ii1ii1ii = IIIi1I1IIii1II + "?" + "utmwv=" + Oo0O00Oo0o0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1Oo00 ) + "&utmac=" + i1i + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O00O0oOO00O00 , "1" , "1" , "2" ] )
   if 91 - 91: ooO
   if 15 - 15: oo00oOOo
   if 18 - 18: i11iIiiIii . III % oOooOoO0Oo0O / iIIi1iI1II111
   if 75 - 75: i111iII % O0 % O0 . OOoO
   if 5 - 5: O0 * ooo0Oo0 + i111iII . Ii + i111iII
  else :
   if group == "None" :
    O0ii1ii1ii = IIIi1I1IIii1II + "?" + "utmwv=" + Oo0O00Oo0o0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1Oo00 + "/" + name ) + "&utmac=" + i1i + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O00O0oOO00O00 , "1" , "1" , "2" ] )
    if 91 - 91: iIIi1iI1II111
    if 61 - 61: oo00oOOo
    if 64 - 64: ooo0Oo0 / i111iII - iIIi1iI1II111 - o0o
    if 86 - 86: o0o % i111iII / Oooo000o / i111iII
    if 42 - 42: OOO
   else :
    O0ii1ii1ii = IIIi1I1IIii1II + "?" + "utmwv=" + Oo0O00Oo0o0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1Oo00 + "/" + group + "/" + name ) + "&utmac=" + i1i + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O00O0oOO00O00 , "1" , "1" , "2" ] )
    if 67 - 67: OOoO . i11Ii11I1Ii1i . iIIi1iI1II111
    if 10 - 10: OoOoOoO0o0OO % OoOoOoO0o0OO - ii11i / Ii + OOO0o0o
    if 87 - 87: Ooo0OO0oOO * OoOoOoO0o0OO + Ii / ii11i / i11Ii11I1Ii1i
    if 37 - 37: i11Ii11I1Ii1i - ooo0Oo0 * Ooo0OO0oOO % i11iIiiIii - OOoO
    if 83 - 83: o0o / Oooo000o
    if 34 - 34: ooO
  print "============================ POSTING ANALYTICS ============================"
  Oo0OoO00oOO0o ( O0ii1ii1ii )
  if 57 - 57: Ooo0OO0oOO . o0o . III
  if not group == "None" :
   i11Iii = IIIi1I1IIii1II + "?" + "utmwv=" + Oo0O00Oo0o0 + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( iiI111I1iIiI ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + i1Oo00 + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( i1Oo00 ) + "&utmac=" + i1i + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , O00O0oOO00O00 , "1" , "2" ] )
   if 16 - 16: oo00oOOo % i111iII - oo00oOOo + OOO0o0o
   if 12 - 12: Ii / Ii + i11iIiiIii
   if 40 - 40: Oooo000o . ii11i / Oooo000o / i11iIiiIii
   if 75 - 75: o0o + O0
   if 84 - 84: ooO . i11iIiiIii . ooO * OoOoOoO0o0OO - o0o
   if 42 - 42: i11iIiiIii
   if 33 - 33: i11Ii11I1Ii1i - iIIi1iI1II111 * III * O0 - OOo
   if 32 - 32: oOooOoO0Oo0O / ii11i - O0
   try :
    print "============================ POSTING TRACK EVENT ============================"
    Oo0OoO00oOO0o ( i11Iii )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 91 - 91: i11Ii11I1Ii1i % III % ii11i
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 20 - 20: Ii % OOO0o0o / OOO0o0o + OOO0o0o
III1IiiI = o0Oo0O0Oo00oO ( sys . argv [ 2 ] )
iI = III1IiiI . get ( 'mode' )
OO00O0O0O00Oo = III1IiiI . get ( 'url' )
i1IIIII11I1IiI = III1IiiI . get ( 'name' )
if type ( OO00O0O0O00Oo ) == type ( str ( ) ) :
 OO00O0O0O00Oo = urllib . unquote_plus ( OO00O0O0O00Oo )
if type ( i1IIIII11I1IiI ) == type ( str ( ) ) :
 i1IIIII11I1IiI = urllib . unquote_plus ( i1IIIII11I1IiI )
 if 16 - 16: ii11i
oOooOOOoOo = str ( sys . argv [ 1 ] )
if iI == 'index' :
 IiI1 ( "Browse" , i1IIIII11I1IiI )
 II1Iiii1111i ( OO00O0O0O00Oo )
elif iI == 'search' :
 IiI1 ( "None" , "Search" )
 II111iiii ( )
elif iI == 'videosbyregion' :
 IiI1 ( "Browse" , i1IIIII11I1IiI )
 oOOo ( )
elif iI == 'videosbycategory' :
 IiI1 ( "Browse" , i1IIIII11I1IiI )
 Ii1iI ( )
elif iI == 'mirrors' :
 IiI1 ( "Browse" , i1IIIII11I1IiI )
 Ii1 ( OO00O0O0O00Oo )
elif iI == 'episodes' :
 IiI1 ( "Browse" , i1IIIII11I1IiI )
 Ii11iI1i ( OO00O0O0O00Oo , i1IIIII11I1IiI )
elif iI == 'loadvideo' :
 IiI1 ( "Play" , i1IIIII11I1IiI + "/" + OO00O0O0O00Oo )
 i1Iii1i1I = xbmcgui . DialogProgress ( )
 i1Iii1i1I . create ( 'Xom Giai Tri' , 'Loading video. Please wait...' )
 III1i1i ( OO00O0O0O00Oo , i1IIIII11I1IiI )
 i1Iii1i1I . close ( )
 del i1Iii1i1I
else :
 IiI1 ( "None" , "None" )
 iI1 ( )
xbmcplugin . endOfDirectory ( int ( oOooOOOoOo ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
