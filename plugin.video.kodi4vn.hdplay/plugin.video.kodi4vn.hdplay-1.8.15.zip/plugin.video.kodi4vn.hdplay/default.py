﻿import CommonFunctions as common
import urllib
import urllib2
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import urlfetch
import re
import json
from BeautifulSoup import BeautifulSoup

__settings__ = xbmcaddon.Addon(id='plugin.video.kodi4vn.hdplay')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
thumbnails = xbmc.translatePath( os.path.join( home, 'thumbnails\\' ) )

def _makeCookieHeader(cookie):
	cookieHeader = ""
	for value in cookie.values():
			cookieHeader += "%s=%s; " % (value.key, value.value)
	return cookieHeader

def make_request(url, headers=None):
	if headers is None:
			headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1',
								 'Referer' : 'http://www.google.com'}
	try:
			req = urllib2.Request(url,headers=headers)
			f = urllib2.urlopen(req)
			body=f.read()
			return body
	except urllib2.URLError, e:
			print 'We failed to open "%s".' % url
			if hasattr(e, 'reason'):
					print 'We failed to reach a server.'
					print 'Reason: ', e.reason
			if hasattr(e, 'code'):
					print 'We failed with error code - %s.' % e.code
def get_fpt():	

        def home():

		req = urllib2.Request(fptplay)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.4) Gecko/2008092417 Firefox/4.0.4')
		response = urllib2.urlopen(req, timeout=90)
		link=response.read()
		response.close()
		match=re.compile("<li ><a href=\"(.+?)\" class=\".+?\">(.+?)<\/a><\/li>").findall(link)
		for url,name in match:
				if 'livetv' in url:
						addDir('[COLOR yellow]' + name + '[/COLOR]',fptplay + url,3,logos + 'fptplay.png')
				else:
						addDir('[COLOR lime]' + name + '[/COLOR]',fptplay + url,1,icon)	


	    
	content = make_request('http://play.fpt.vn/livetv/')
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a', {'class' : 'channel_link'})
	for item in items:
		img = item.find('img')
		if img is not None:
			try:
				add_link('', item['channel'], 0, 'http://play.fpt.vn' + item['href'], img['src'], '')
			except:
				pass

	
#add_dir(name,url,mode,iconimage,query='',type='f',page=0):
def get_vtc_movies(url, query='25', type='', page=0):
	if url == '':
		content = make_request('http://117.103.206.21:88/Movie/GetMovieGenres?device=4')
		result = json.loads(content)
		for item in result:
			add_dir(item["Name"], 'http://117.103.206.21:88/Movie/GetMoviesByGenre?device=4&genreid=' + str(item["ID"]) + '&start=0&length=25', 11, '', '25', str(item["ID"]), 0)
	if 'GetMoviesByGenre' in url:
		content = make_request(url)
		result = json.loads(content)
		for item in result:
			add_link('', item["Title"], 0, 'http://117.103.206.21:88/Movie/GetMovieStream?device=4&path=' + item["MovieUrls"][0]["Path"].replace('SD', 'HD'), item["Thumbnail3"], item["SummaryShort"])
		add_dir('Next', 'http://117.103.206.21:88/Movie/GetMoviesByGenre?device=4&genreid=' + type + '&start=' + str(int(query)+page) + '&length=' + str(query), 11, '', str(int(query)+page), type, page)
	
def get_vtc(url = None):
	content = make_request(url)
	
	result = json.loads(content)
	for item in result:
		path = item["ChannelUrls"][0]["Path"]
		if 'http' in path:
			add_link('', item["Name"], 0, item["ChannelUrls"][0]["Path"], item["Thumbnail2"], '')
		else:
			add_link('', item["Name"], 0, "http://117.103.206.21:88/channel/GetChannelStream?device=4&path=" + item["ChannelUrls"][0]["Path"], item["Thumbnail2"], '')

def get_hdonline(url = None):
	if url == '':
		content = make_request('http://old.hdonline.vn/')
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		items = soup.find('div',{'id' : 'full-mn-phim-le'}).findAll('a')
		for item in items:
			href = item.get('href')
			if href is not None:
				try:
					add_dir(item.text, href, 13, thumbnails + 'HDOnline.png', query, type, 0)
				except:
					pass
		return
	if 'xem-phim' in url:	
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		items = soup.findAll('ul', {'class' : 'clearfix listmovie'})[1].findAll('li')
		for item in items:
			a = item.find('a')
			img = item.find('img')
			span = item.find('span',{'class' : 'type'})
			href = a.get('href')
			if href is not None:
				try:
					if span is not None:
						add_dir(a.get('title') + ' (' + span.text + ')', href, 9, a.img['src'], '', '', 0)
					else:	
						add_link('', a.get('title'), 0, href, img['src'], '')
				except:
					pass
		items = soup.find('div',{'class' : 'pagination pagination-right'})
		if items is not None:
			for item in items.findAll('a'):
				a = item
				href = a.get('href')
				if href is not None:
					try:
						add_dir(a.get('title'), href, 9, thumbnails + 'zui.png', '', '', 0)
					except:
						pass
		
def get_zui(url = None):
	if url == '':
		content = make_request('http://zui.vn')
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		items = soup.find('div',{'class' : 'span8 visible-desktop visible-tablet'}).findAll('a')
		for item in items:
			href = item.get('href')
			if href is not None:
				try:
					add_dir(item.text, href, 9, thumbnails + 'zui.png', query, type, 0)
				except:
					pass
		return
	if 'the-loai' in url or 'phim-' in url:	
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		groups = soup.find('ul', {'class' : 'group'})
		if groups is not None:
			for item in groups.findAll('a'):
				matchObj = re.match( r'change_group_chapter\((\d+),(\d+),(\d+)\)', item['onclick'], re.M|re.I)
				response = urlfetch.fetch(
			url = 'http://zui.vn/?site=movie&view=show_group_chapter',
			method ='POST',
			data = {
				"pos": matchObj.group(1),
				"movie_id": matchObj.group(2),
				"type": matchObj.group(3)
			}
		)
				soup = BeautifulSoup(str(response.content), convertEntities=BeautifulSoup.HTML_ENTITIES)
				for item in soup.findAll('a'):
					add_link('', u'T?p ' + item.text, 0, 'http://zui.vn/' + item['href'], thumbnails + 'zui.png', '')
		else:
			items = soup.find('ul',{'class' : 'movie_chapter'})
			if items is not None:
				for item in items.findAll('a'):
					a = item
					href = a.get('href')
					if href is not None:
						try:
							add_link('', u'T?p ' + a.text, 0, 'http://zui.vn/' + href, thumbnails + 'zui.png', '')
							#add_dir(u'T?p ' + a.text, 'http://zui.vn/' + href, 9, thumbnails + 'zui.png', '', '', 0)
						except:
							pass
			else:
				items = soup.findAll('div',{'class' : 'poster'})
				for item in items:
					a = item.find('a')
					span = item.find('span',{'class' : 'type'})
					href = a.get('href')
					if href is not None:
						try:
							if span is not None:
								add_dir(a.get('title') + ' (' + span.text + ')', href, 9, a.img['src'], '', '', 0)
							else:	
								add_link('', a.get('title'), 0, href, a.img['src'], '')
						except:
							pass
				items = soup.find('div',{'class' : 'pagination pagination-right'})
				if items is not None:
					for item in items.findAll('a'):
						a = item
						href = a.get('href')
						if href is not None:
							try:
								add_dir(a.get('title'), href, 9, thumbnails + 'zui.png', '', '', 0)
							except:
								pass
	else:
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		groups = soup.find('ul', {'class' : 'group'})
		if groups is not None:
			for item in groups.findAll('a'):
				matchObj = re.match( r'change_group_chapter\((\d+),(\d+),(\d+)\)', item['onclick'], re.M|re.I)
				response = urlfetch.fetch(
			url = 'http://zui.vn/?site=movie&view=show_group_chapter',
			method ='POST',
			data = {
				"pos": matchObj.group(1),
				"movie_id": matchObj.group(2),
				"type": matchObj.group(3)
			}
		)
				soup = BeautifulSoup(str(response.content), convertEntities=BeautifulSoup.HTML_ENTITIES)
				for item in soup.findAll('a'):
					add_link('', u'T?p ' + item.text, 0, 'http://zui.vn/' + item['href'], thumbnails + 'zui.png', '')
			return
	
		items = soup.find('ul',{'class' : 'movie_chapter'})
		if items is not None:
			for item in items.findAll('a'):
				a = item
				href = a.get('href')
				if href is not None:
					try:
						add_link('', u'T?p ' + a.text, 0, 'http://zui.vn/' + href, thumbnails + 'zui.png', '')
						#add_dir(u'T?p ' + a.text, 'http://zui.vn/' + href, 9, thumbnails + 'zui.png', '', '', 0)
					except:
						pass
	
def get_fpt_other(url):
	content = make_request(url)
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a')
	for item in items:
		href = item.get('href')
		if href is not None and 'the-loai-more' in href and 'Xem' not in item.text:
			try:
				add_dir(item.text, 'http://play.fpt.vn' + href, 8, thumbnails + 'fptplay.jpg', query, type, 0)
			except:
				pass

def get_fpt_tvshow_cat(url):
	content = make_request(url)
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	if url is not None and '/Video/' not in url:
		items = soup.findAll('div', {'class' : 'col'})
		for item in items:
			img = item.a.img['src']
			href = item.a['href']
			text = item.a.img['alt']	
			try:
				add_dir(text, 'http://play.fpt.vn' + href, 8, img, '', '', 0)
			except:
				pass

	items = soup.find('ul', {'class' : 'pagination pagination-sm'}).findAll('a')
	for item in items:
		href = ''
		href = item.get('href')
		if href is not None and 'the-loai-more' in href and 'Xem' not in item.text:
			try:
				add_dir('Trang ' + item.text, 'http://play.fpt.vn' + href, 8, thumbnails + 'fptplay.jpg', query, type, 0)
			except:
				pass
		if href is not None and '/Video/' in href:
			try:
				add_link('', u'T?p ' + item.text, 0, 'http://play.fpt.vn' + href, thumbnails + 'fptplay.jpg', '')
			except:
				pass
		
def get_htv():
	content = make_request('http://www.htvonline.com.vn/livetv')
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a', {'class' : 'mh-grids5-img'})
	for item in items:
		img = item.find('img')
		if img is not None:
			try:
				add_link('', item['title'], 0, item['href'], img['src'], '')
			except:
				pass

def get_sctv(url):
	content = make_request('http://tv24.vn/LiveTV/Tivi_Truc_Tuyen_SCTV_VTV_HTV_THVL_HBO_STARMOVIES_VTC_VOV_BongDa_Thethao_Hai_ThoiTrang_Phim_PhimHongKong.html')
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a')
	for item in items:
		img = item.find('img')
		if img is not None and 'LiveTV' in item['href']:
			try:
				add_link('', item['href'], 0, 'http://tv24.vn' + item['href'], img['src'], '')
			except:
				pass
		
def get_categories():
	
	add_link('', 'VTV1 HD VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:vtv1hd_hls.smil/playlist.m3u8', thumbnails + 'VTV1.jpg', '')
	add_link('', 'VTV3 HD VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:vtv3hd_hls.smil/playlist.m3u8', thumbnails + 'VTV3 HD.jpg', '')
	add_link('', 'VTV6 HD VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:vtv6hd_hls.smil/playlist.m3u8', thumbnails + 'VTV6 HD.jpg', '')
	add_link('', 'VTVCAB1 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:giaitritv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB2 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:phimviet_hls.smil/playlist.m3u8', thumbnails + '', '')
        add_link('', 'VTVCAB4 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:kenh17_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB7 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:ddramas_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB8 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:bibi_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB9 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:infotv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB10 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:o2tv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB12 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:styletv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB15 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:investtv_hls.smil/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HANOI 1 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:hanoi1_hls.smil/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTV9 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:htv9_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'HTVC PHU NU VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:htvcphunu_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTC4 VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:yeah1tv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'SCTVHD HAI(720P) VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:sctvhaihd_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'ARIANG VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:arirang_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'KBS VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:kbs_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'AVG VTC1 HD', 0, 'http://113.160.49.34/lives/origin03/vtchd1hd.isml/vtchd1hd-2096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC HD2', 0, 'http://113.160.49.34/lives/origin03/vtchd2hd.isml/vtchd2hd-2096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC3 HD', 0, 'http://113.160.49.34/lives/origin03/vtc3hd.isml/vtc3hd.m3u8', thumbnails + '', '')
        add_link('', 'AVG ITV HD', 0, 'http://113.160.49.34/lives/origin03/itvhd.isml/itvhd.m3u8', thumbnails + '', '')
        add_link('', 'AVG DISCOVERY HD', 0, 'http://113.160.49.34/lives/origin03/discoveryhd.isml/discoveryhd.m3u8', thumbnails + '', '')
        add_link('', 'AVG STAR MOVIES HD', 0, 'http://113.160.49.34/lives/origin03/moviehd.isml/moviehd.m3u8', thumbnails + '', '')
	add_link('', 'AVG AXN HD', 0, 'http://113.160.49.34/lives/origin03/axnhd.isml/axnhd.m3u8', thumbnails + '', '')
        add_link('', 'AVG HBO HD', 0, 'http://113.160.49.34/lives/origin03/hbohd.isml/hbohd.m3u8', thumbnails + '', '')
	add_link('', 'AVG FOXSPORT HD', 0, 'http://113.160.49.34/lives/origin03/foxhd.isml/foxhd-2096k.m3u8', thumbnails + '', '')
	add_link('', 'AVG FASHION HD', 0, 'http://113.160.49.34/lives/origin03/fashionhd.isml/fashionhd-2096k.m3u8', thumbnails + '', '')
	add_link('', 'AVG NCM BYV10', 0, 'http://113.160.49.34/lives/origin03/ncmsd.isml/ncmsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG PHIM HAY', 0, 'http://113.160.49.34/lives/origin01/phimhaysd.isml/phimhaysd-1096k.m3u8', thumbnails + '', '')
	add_link('', 'AVG AN NINH THE GIOI', 0, 'http://113.160.49.34/lives/origin01/STTVsd.isml/STTVsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG SAM CHANNEL', 0, 'http://113.160.49.34/lives/origin01/samsd.isml/samsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC NHE', 0, 'http://113.160.49.34/lives/origin03/nhacnhesd.isml/nhacnhesd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC TRU TINH', 0, 'http://113.160.49.34/lives/origin03/nhactrutinhsd.isml/nhactrutinhsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC TRE', 0, 'http://113.160.49.34/lives/origin03/nhactresd.isml/nhactresd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC CACH MANG', 0, 'http://113.160.49.34/lives/origin03/nhaccachmangsd.isml/nhaccachmangsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC THIEU NHI', 0, 'http://113.160.49.34/lives/origin03/nhacthieunhisd.isml/nhacthieunhisd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC DAN TOC', 0, 'http://113.160.49.34/lives/origin03/nhacdantocsd.isml/nhacdantocsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC NAM BO', 0, 'http://113.160.49.34/lives/origin03/nhacnambosd.isml/nhacnambosd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NHAC CO DIEN', 0, 'http://113.160.49.34/lives/origin01/nhaccodiensd.isml/nhaccodiensd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG THÐT 2', 0, 'http://113.160.49.34/lives/origin03/mientaysd.isml/mientaysd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VIETTEEN', 0, 'http://113.160.49.34/lives/origin03/vietteensd.isml/vietteensd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG DOC SACH', 0, 'http://113.160.49.34/lives/origin01/docsachsd.isml/docsachsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTV1', 0, 'http://113.160.49.34/lives/origin03/vtv1sd.isml/vtv1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTV2', 0, 'http://113.160.49.34/lives/origin03/vtv2sd.isml/vtv2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTV3', 0, 'http://113.160.49.34/lives/origin03/vtv3sd.isml/vtv3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTV4', 0, 'http://113.160.49.34/lives/origin03/vtv4sd.isml/vtv4sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTV6', 0, 'http://113.160.49.34/lives/origin03/vtv6sd.isml/vtv6sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG TTXVN', 0, 'http://113.160.49.34/lives/origin02/ttxvnsd.isml/ttxvnsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG ANTV', 0, 'http://113.160.49.34/lives/origin02/antvsd.isml/antvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG QPVN', 0, 'http://113.160.49.34/lives/origin02/qptvsd.isml/qptvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTVCAB8 BiBi', 0, 'http://113.160.49.34/lives/origin03/bibisd.isml/bibisd.m3u8', thumbnails + '', '')
        add_link('', 'AVG HTV7', 0, 'http://113.160.49.34/lives/origin01/htv7sd.isml/htv7sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG HTV9', 0, 'http://113.160.49.34/lives/origin02/htv9sd.isml/htv9sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC1', 0, 'http://113.160.49.34/lives/origin01/vtc1sd.isml/vtc1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC2', 0, 'http://113.160.49.34/lives/origin01/vtc2sd.isml/vtc2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC3', 0, 'http://113.160.49.34/lives/origin01/vtc3sd.isml/vtc3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC4', 0, 'http://113.160.49.34/lives/origin01/vtc4sd.isml/vtc4sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC5', 0, 'http://113.160.49.34/lives/origin01/vtc5sd.isml/vtc5sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC6', 0, 'http://113.160.49.34/lives/origin01/vtc6sd.isml/vtc6sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC7', 0, 'http://113.160.49.34/lives/origin01/vtc7sd.isml/vtc7sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC8', 0, 'http://113.160.49.34/lives/origin01/vtc8sd.isml/vtc8sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC9', 0, 'http://113.160.49.34/lives/origin01/vtc9sd.isml/vtc9sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC10', 0, 'http://113.160.49.34/lives/origin01/vtc10sd.isml/vtc10sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC11', 0, 'http://113.160.49.34/lives/origin01/vtc11sd.isml/vtc11sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC12', 0, 'http://113.160.49.34/lives/origin01/vtc12sd.isml/vtc12sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC13', 0, 'http://113.160.49.34/lives/origin01/vtc13sd.isml/vtc13sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC14', 0, 'http://113.160.49.34/lives/origin01/vtc14sd.isml/vtc14sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VTC16', 0, 'http://113.160.49.34/lives/origin01/vtc16sd.isml/vtc16sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG HN 1', 0, 'http://113.160.49.34/lives/origin01/h1sd.isml/h1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG HN 2', 0, 'http://113.160.49.34/lives/origin01/h2sd.isml/h2sd-1096k.m3u8', thumbnails + '', '')
	    add_link('', 'AVG HCATV VNK', 0, 'http://113.160.49.34/lives/origin01/vietnamnetsd.isml/vietnamnetsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG HAI PHONG', 0, 'http://113.160.49.34/lives/origin01/haiphongsd.isml/haiphongsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG THAI NGUYEN', 0, 'http://113.160.49.34/lives/origin01/thainguyensd.isml/thainguyensd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG HOA BINH', 0, 'http://113.160.49.34/lives/origin02/hbtvsd.isml/hbtvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG TUYEN QUANG', 0, 'http://113.160.49.34/lives/origin02/ttv2sd.isml/ttv2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG QN 1', 0, 'http://113.160.49.34/lives/origin01/qtv1sd.isml/qtv1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG  QN 3', 0, 'http://113.160.49.34/lives/origin02/qtv3sd.isml/qtv3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NINH BINH', 0, 'http://113.160.49.34/lives/origin02/ntv3sd.isml/ntv3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG THANH HOA', 0, 'http://113.160.49.34/lives/origin01/thanhhoasd.isml/thanhhoasd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NGHE AN', 0, 'http://113.160.49.34/lives/origin01/ngheansd.isml/ngheansd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG QUANG NGAI', 0, 'http://113.160.49.34/lives/origin02/ptq1sd.isml/ptq1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG NINH THUAN', 0, 'http://113.160.49.34/lives/origin02/ninhthuansd.isml/ninhthuansd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG LAM DONG', 0, 'http://113.160.49.34/lives/origin02/ltvsd.isml/ltvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG GIA LAI', 0, 'http://113.160.49.34/lives/origin02/thglsd.isml/thglsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG BINH PHUOC 2', 0, 'http://113.160.49.34/lives/origin02/bptv2sd.isml/bptv2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG DONG NAI 1', 0, 'http://113.160.49.34/lives/origin02/dn1sd.isml/dn1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG DONG NAI 2', 0, 'http://113.160.49.34/lives/origin02/dn2sd.isml/dn2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG BA RIA VUNG TAU', 0, 'http://113.160.49.34/lives/origin02/brtsd.isml/brtsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VINH LONG 1', 0, 'http://113.160.49.34/lives/origin01/vinhlongsd.isml/vinhlongsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG VINH LONG 2', 0, 'http://113.160.49.34/lives/origin02/thvl2sd.isml/thvl2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG TRA VINH', 0, 'http://113.160.49.34/lives/origin02/thtvsd.isml/thtvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG KIEN GIANG 1', 0, 'http://113.160.49.34/lives/origin02/kg1sd.isml/kg1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG AN GIANG 1', 0, 'http://113.160.49.34/lives/origin02/atvsd.isml/atvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG FBNC', 0, 'http://113.160.49.34/lives/origin02/fbncsd.isml/fbncsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG ANIMAL PLANET', 0, 'http://113.160.49.34/lives/origin03/animalsd.isml/animalsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG STAR MOVIES', 0, 'http://113.160.49.34/lives/origin03/starmoviesd.isml/starmoviesd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG CINEMAX', 0, 'http://113.160.49.34/lives/origin03/cinemaxsd.isml/cinemaxsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG STAR SPORTS', 0, 'http://113.160.49.34/lives/origin03/starsportsd.isml/starsportsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG FOX SPORTS', 0, 'http://113.160.49.34/lives/origin03/foxsd.isml/foxsd-1096k.m3u8', thumbnails + '', '')
        add_link('', 'AVG CARTOON NETWORK', 0, 'http://113.160.49.34/lives/origin03/cartoonsd.isml/cartoonsd-1096k.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTVCAB2', 0, 'http://2co1.vp9.tv/chn/phimv/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTVCAB7', 0, 'http://2co1.vp9.tv/chn/ddra/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTVCAB8', 0, 'http://2co1.vp9.tv/chn/bibi/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTVCAB10', 0, 'http://2co1.vp9.tv/chn/o2tv/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 BONGDATV HD', 0, 'http://2co1.vp9.tv/chn/bdtv/v.m3u8', thumbnails + 'bongdatv-hd.png', '')
	add_link('', 'VP9 THETHAOTV HD', 0, 'http://2co1.vp9.tv/chn/tttv/v.m3u8', thumbnails + 'TheThaoTVHD.jpg', '')
	add_link('', 'VP9 VTV1', 0, 'http://2co1.vp9.tv/chn/vtv1/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTV2', 0, 'http://2co1.vp9.tv/chn/vtv2/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTV3 HD', 0, 'http://2co1.vp9.tv/chn/vtv3/v.m3u8', thumbnails + 'VTV3 HD.jpg', '')
	add_link('', 'VP9 VTV4', 0, 'http://2co1.vp9.tv/chn/vtv4/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTV6 HD', 0, 'http://2co1.vp9.tv/chn/vtv6/v.m3u8', thumbnails + 'VTV6 HD.jpg', '')
	add_link('', 'VP9 VTC1', 0, 'http://2co1.vp9.tv/chn/vtc1/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC2', 0, 'http://2co1.vp9.tv/chn/vtc2/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC3', 0, 'http://2co1.vp9.tv/chn/vtc3/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC6', 0, 'http://2co1.vp9.tv/chn/sgc6/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC7', 0, 'http://2co1.vp9.tv/chn/tdayt/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC9', 0, 'http://2co1.vp9.tv/chn/letsv/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC11', 0, 'http://2co1.vp9.tv/chn/kids/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VTC16', 0, 'http://2co1.vp9.tv/chn/3ntv/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 ANTV', 0, 'http://2co1.vp9.tv/chn/antv/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 QPVN', 0, 'http://2co1.vp9.tv/chn/qpvn/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 VOVTV', 0, 'http://2co1.vp9.tv/chn/vovtv/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 HN1', 0, 'http://2co1.vp9.tv/chn/hn1/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 HN2', 0, 'http://2co1.vp9.tv/chn/hn2/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 HTV7', 0, 'http://2co1.vp9.tv/chn/htv7/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 ARIANG', 0, 'http://2co1.vp9.tv/chn/arirg/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 DISNEY', 0, 'http://2co1.vp9.tv/chn/disny/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 NICKELODEON', 0, 'http://2co1.vp9.tv/chn/nicke/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 STAR WOLD', 0, 'http://2co1.vp9.tv/chn/starw/v.m3u8', thumbnails + '', '')
	add_link('', 'VP9 SPORTTIME TV', 0, 'rtmp://streamer.a1.net:1935/rtmplive/redundant/channels/Sporttime/SporttimeTV/mp4:channel1_1200', thumbnails + '', '')
	add_link('', 'VTV4 (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vtv4.480p/playlist.m3u8', thumbnails + '', '')	
        add_link('', 'VTVcab2 (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vctv2.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'VTVcab4 (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vctv4.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'VTVcab10 (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vctv10.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTVC DU LICH (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:dulichcuocsong.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTVC THUAN VIET (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:thuanviet.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTVC FBNC (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:htvcfbnc.480p/htvcfbnc.m3u8', thumbnails + '', '')
        add_link('', 'SCTVHAI (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:sctvhaihd.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'SCTV7 (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:sctv7.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'SCTV14 (accessasia)', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:sctv14.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'TOM AND JERRY', 0, 'http://66.90.111.66:1935/ctv/tom/playlist.m3u8', thumbnails + '', '')
        add_link('', 'ALJAZEERA DOC', 0, 'rtmp://aljazeeraflashlivefs.fplive.net:1935/aljazeeraflashlive-live playpath=aljazeera_doc_high swfUrl=http://admin.brightcove.com/viewer/us1.25.04.00.2011-05-19124744/federatedVideoUI/BrightcovePlayer.swf live=1 pageUrl=http://upload.wikimedia.org/wikipedia/en/e/e6/Al_Jazeera_Doc.png', thumbnails + '', '')
        add_link('', 'ARTE FRANCE', 0, 'http://frlive.artestras.cshls.lldns.net/artestras/contrib/frlive/frlive_925.m3u8', thumbnails + '', '')
        add_link('', 'BBC news', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/bbc_world/ls_satlink/b_828.m3u8', thumbnails + '', '')
	add_link('', 'OUTDOOR CHANNEL USA', 0, 'rtmp://lm02.everyon.tv:1935/ptv2/pld613', thumbnails + '', '')
	add_link('', 'USA NATGEO WILD', 0, 'http://202.75.23.35/live/ch39/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA DMAX ', 0, 'http://202.75.23.34/live/ch32/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA DISCOVERY WORLD', 0, 'http://202.75.23.34/live/ch30/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA DISCOVERY', 0, 'http://202.75.23.34/live/ch29/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA DISCOVERY SC ', 0, 'http://202.75.23.34/live/ch33/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA ANIMAL PLANET', 0, 'http://202.75.23.34/live/ch31/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA TLC', 0, 'http://202.75.23.34/live/ch35/01.m3u8?Vd?u#bt!25', '', '')	
	add_link('', 'USA Fox College Sports HD 720p', 0, 'http://202.75.23.36/live/ch45/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA ABC HD 720p', 0, 'http://abclive.abcnews.com/i/abc_live4@136330/master.m3u8', '', '')
	add_link('', 'USA PAC12 CALIFORNIA Bay Area 1080p', 0, 'http://xrxs.net/video/live-p12baya-4728.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA/SPAN ESPN CANAL516', 0, 'http://200.76.77.237/LIVE/H01/CANAL516/PROFILE03.m3u8?', '', '')	
	add_link('', 'USA/SPAN FOX SPORTS CANAL522', 0, 'http://200.76.77.237/LIVE/H01/CANAL522/PROFILE03.m3u8?', '', '')
	add_link('', 'USA/SPAN FOX SPORT 2 CANAL527', 0, 'http://200.76.77.237/LIVE/H01/CANAL527/PROFILE03.m3u8?', '', '')
	add_link('', 'USA/RUS SPORT 1 Soccer', 0, 'http://178.49.132.73/streaming/sport1/tvrec/playlist.m3u8', '', '')
	add_link('', 'USA Golf Channel', 0, 'http://tvegolf-i.Akamaihd.net/hls/live/218225/golfx/2596k/prog.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA UFC FightBox', 0, 'http://stream1.zoovision.com//livespi/fightbox/playlist.m3u8', '', '')	
	add_link('', 'USA/UK SKY Sports 1', 0, 'rtmp://46.246.29.130:1935/stream playpath=WWv4pD0kYn.stream swfUrl=http://thecdn.04stream.com/p/ooolo1.swf pageUrl=http://www.04stream.com/ebb.php  timeout=10', '', '')
	add_link('', 'USA/CANADA Shopping Channel 1080p', 0, 'http://tscstreaming-lh.akamaihd.net/i/TSCLiveStreaming_1@91031/master.m3u8?b?b*t$', '', '')	
    add_link('', 'USA Big Ten Network', 0, 'http://bigten247.cdnak.bigtenhd.neulion.com/nlds/btn2go/btnnetwork/as/live/btnnetwork_hd_3000.m3u8', '', '')
### GERMANY  And  International TV ####################
	add_link('', 'USA/GERMANY Kanal Sports 720p', 0, 'http://lswb-de-08.servers.octoshape.net:1935/live/kanalsport_2000k/HD.m3u8?Vd?u#bt!25', '', '')
	add_link('', 'USA/GERMANY WDR 720p', 0, 'http://wdr_fs-lh.akamaihd.net/i/wdrfs_weltweit@112033/master.m3u8', '', '')
	add_link('', 'USA/GERMANY Family TV 720p', 0, 'rtmp://83.169.58.36/live/Stream3', '', '')	
	add_link('', 'USA/UK Vevo TV', 0, 'http://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch1/06/prog_index.m3u8', '', '')
	add_link('', 'USA/CHINA HNWS-HD 湖南卫视高清 729p', 0, 'rtsp://58.200.131.2/JSWS-HD', '', '')	
	add_link('', 'USA/ITALIA SUPER TENNIS 1080p', 0, 'http://109.87.130.13:8888www.tvonlinestreams.com/udp/238.0.16.63:1234', '', '')	
# Begin V1.8.3 date 02.05.2015	################ 46 Kenh ########Combibed 2 Versions by Long Hong ##################	
	add_link('', 'VTV1 HD', 0, 'http://vtvplay.vn/api/channel?streamid=1', thumbnails + 'vtv1hd.png', '')
	add_link('', 'SCTV HAI HD', 0, 'http://vtvplay.vn/api/channel?streamid=118', thumbnails + 'haihd.png', '')
	add_link('', 'GIAI TRI TV', 0, 'http://vtvplay.vn/api/channel?streamid=144', thumbnails + 'GTTV.png', '')
	add_link('', 'PHIM VIET', 0, 'http://vtvplay.vn/api/channel?streamid=143', thumbnails + 'PHIMVIET.png', '')
	add_link('', 'THETHAOTV SD', 0, 'http://vtvplay.vn/api/channel?streamid=149', thumbnails + 'tttvsd.png', '')
	add_link('', 'KENH17', 0, 'http://vtvplay.vn/api/channel?streamid=136', thumbnails + 'kenh17.png', '')
	add_link('', 'BIBI', 0, 'http://vtvplay.vn/api/channel?streamid=31', thumbnails + 'bibi.png', '')
	add_link('', 'INFOTV', 0, 'http://vtvplay.vn/api/channel?streamid=147', thumbnails + 'iftv.png', '')
	add_link('', 'O2TV', 0, 'http://vtvplay.vn/api/channel?streamid=145', thumbnails + 'o2tv.png', '')
	add_link('', 'INVESTTV', 0, 'http://vtvplay.vn/api/channel?streamid=146', thumbnails + 'ivtv.png', '')
	add_link('', 'BONGDATV SD', 0, 'http://vtvplay.vn/api/channel?streamid=148', thumbnails + 'bdtvsd.png', '')
	add_link('', 'AXN HD', 0, 'http://113.160.49.34/lives/origin03/axnhd.isml/axnhd-2096k.m3u8', thumbnails + 'axnhd.png', '')
	add_link('', 'HBO HD', 0, 'http://113.160.49.34/lives/origin03/hbohd.isml/hbohd-2096k.m3u8', thumbnails + 'hboHD2.png', '')
	add_link('', 'CINEMAX', 0, 'http://113.160.49.34/lives/origin03/cinemaxsd.isml/cinemaxsd-1096k.m3u8', thumbnails + 'cinemax.png', '')
	add_link('', 'ANIMAL PLANET', 0, 'http://113.160.49.34/lives/origin03/animalsd.isml/animalsd-1096k.m3u8', thumbnails + 'animal-planet.png', '')
	add_link('', 'DISCOVERY', 0, 'http://113.160.49.34/lives/origin03/discoveryhd.isml/discoveryhd.m3u8', thumbnails + 'DSC_rev.png', '')
	add_link('', 'CHANNEL V', 0, 'http://113.160.49.34/lives/origin03/channelvsd.isml/channelvsd-1096k.m3u8', thumbnails + 'channel_v.png', '')
	add_link('', 'FASHIONTV', 0, 'http://113.160.49.34/lives/origin03/fashionhd.isml/fashionhd-2096k.m3u8', thumbnails + 'Fashion_TV.png', '')
# End V1.8.3 date 02.05.2015	######################################################					
	#add_link('', 'HBO HD', 0, '', '', '')
	#http://scache.fptplay.net.vn/live/htvcplusHD_1000.stream/manifest.f4m	
	add_dir('[COLOR lime]>>> HTVOnline TV[/COLOR]', url, 5, thumbnails + 'htv.jpg', query, type, 0)
	
	#add_dir('SCTV', url, 12, thumbnails + 'SCTV.png', query, type, 0)
	#add_dir('VTCPlay - TV', 'http://117.103.206.21:88/Channel/GetChannels?device=4', 10, thumbnails + 'vtcplay.jpg', query, type, 0)
	#add_dir('VTCPlay - Movies', '', 11, thumbnails + 'vtcplay.jpg', query, type, 0)
	#add_dir('FPTPlay - TV', url, 6, thumbnails + 'fptplay_logo.jpg', query, type, 0)
	#add_dir('FPTPlay - TVShow', url, 7, thumbnails + 'fptplay_logo.jpg', query, type, 0)
	#add_dir('ZUI.VN', url, 9, thumbnails + 'zui.png', query, type, 0)
	#add_dir('HDOnline.vn', url, 13, thumbnails + 'HDOnline.png', query, type, 0)

def searchMenu(url, query = '', type='f', page=0):
	add_dir('New Search', url, 2, icon, query, type, 0)
	add_dir('Clear Search', url, 3, icon, query, type, 0)

	searchList=cache.get('searchList').split("\n")
	for item in searchList:
		add_dir(item, url, 2, icon, item, type, 0)

def resolve_url(url):
	make_request("http://feed.hdrepo.com/hitcount.php?url=" + url);
	if 'zui.vn' in url:
		headers2 = {'User-agent' : 'iOS / Chrome 32: Mozilla/5.0 (iPad; CPU OS 7_0_4 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/32.0.1700.20 Mobile/11B554a Safari/9537.53',
											 'Referer' : 'http://www.google.com'}
		content = make_request(url, headers2)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		for line in content.splitlines():
			s = line.strip()
			if s.startswith('movie_play_chapter'):
				#movie_play_chapter('mediaplayer', '1', 'rtmp://103.28.37.89:1935/vod3/mp4:/phimle/Vikingdom.2013.720p.WEB-DL.H264-PHD.mp4', '/uploads/movie_view/5c65563b1ce8d106c013.jpg', 'http://zui.vn/subtitle/Vikingdom.2013.720p.WEB-DL.H264-PHD.srt');
				matchObj = re.match( r'[^\']*\'([^\']*)\', \'([^\']*)\', \'([^\']*)\', \'([^\']*)\', \'([^\']*)\'', s, re.M|re.I)
				url = matchObj.group(3)
				url = url.replace(' ','%20')
				xbmc.Player().play(url)
				xbmc.Player().setSubtitles(matchObj.group(5))
				return
				break

	if 'play.fpt.vn/Video' in url:
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		for line in content.splitlines():
			s = line.strip()
			if s.startswith('"<source src='):
				start = s.index('\'')+1
				end = s.index('\'', start+1)
				url = s[start:end]
				break

	if 'play.fpt.vn' in url:
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		item = soup.find('div', {'id' : 'bitrate-tag'})
		url = item['highbitrate-link']
		content = make_request(url)
		for line in content.splitlines():
			s = line.strip()
			if s.startswith('<id>'):
				start = s.index('<id>')+4
				end = s.index('<', start+1)
				url = url.replace('manifest.f4m',s[start:end])
				url = 'http://scache.fptplay.net.vn/live/' + s[start:end] + '/playlist.m3u8'
				break
			       
	if 'htvonline' in url:
		content = make_request(url)
		for line in content.splitlines():
			if line.strip().startswith('file: '):
				url = line.strip().replace('file: ', '').replace('"', '').replace(',', '')
				break

	if 'tv24' in url:
		content = make_request(url)
		for line in content.splitlines():
			if line.strip().startswith('\'file\': \'http'):
				url = line.strip().replace('\'file\': ', '').replace('\'', '').replace(',', '')
				break
		
	if 'GetChannelStream' in url or 'GetMovieStream' in url or 'vtvplay' in url:
		content = make_request(url)
		url = content.replace("\"", "")
		url = url[:-5]
	item = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return

def add_link(date, name, duration, href, thumb, desc):
	description = date+'\n\n'+desc
	u=sys.argv[0]+"?url="+urllib.quote_plus(href)+"&mode=4"
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumb)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Duration": duration})
	if 'zui' in href:
		liz.setProperty('IsPlayable', 'false')
	else:
		liz.setProperty('IsPlayable', 'true')
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)



def add_dir(name,url,mode,iconimage,query='',type='f',page=0):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&query="+str(query)+"&type="+str(type)+"&page="+str(page)#+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]

	return param

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

params=get_params()

url=''
name=None
mode=None
query=None
type='f'
page=0

try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
	page=int(urllib.unquote_plus(params["page"]))
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "type: "+str(type)
print "page: "+str(page)
print "query: "+str(query)

if mode==None:
	get_categories()
#		fslink_get_video_categories(FSLINK+'/phim-anh.html')

elif mode==1:
	searchMenu(url, '', type, page)

elif mode==2:
	search(url, query, type, page)

elif mode==3:
	clearSearch()

elif mode==4:
	resolve_url(url)
elif mode==5:
	get_htv()
elif mode==6:
	get_fpt()
elif mode==7:
	get_fpt_other('http://play.fpt.vn/the-loai/tvshow')
	#get_fpt_other('http://play.fpt.vn/the-loai/sport')
	#get_fpt_other('http://play.fpt.vn/the-loai/music')
	#get_fpt_other('http://play.fpt.vn/the-loai/general')
elif mode==8:
	get_fpt_tvshow_cat(url)
elif mode==9:
	get_zui(url)
elif mode==10:
	get_vtc(url)
elif mode==11:
	get_vtc_movies(url, query, type, page)
elif mode==12:
	get_sctv(url)
elif mode==13:
	get_hdonline(url)
	 
xbmcplugin.endOfDirectory(int(sys.argv[1]))