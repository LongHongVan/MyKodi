﻿import CommonFunctions as common
import urllib
import urllib2
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import urlfetch
import re
import json
from BeautifulSoup import BeautifulSoup

__settings__ = xbmcaddon.Addon(id='plugin.video.hdplay')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
thumbnails = xbmc.translatePath( os.path.join( home, 'thumbnails\\' ) )

def _makeCookieHeader(cookie):
	cookieHeader = ""
	for value in cookie.values():
			cookieHeader += "%s=%s; " % (value.key, value.value)
	return cookieHeader

def make_request(url, headers=None):
	if headers is None:
			headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1',
								 'Referer' : 'http://www.google.com'}
	try:
			req = urllib2.Request(url,headers=headers)
			f = urllib2.urlopen(req)
			body=f.read()
			return body
	except urllib2.URLError, e:
			print 'We failed to open "%s".' % url
			if hasattr(e, 'reason'):
					print 'We failed to reach a server.'
					print 'Reason: ', e.reason
			if hasattr(e, 'code'):
					print 'We failed with error code - %s.' % e.code
def get_fpt():	

        def home():

		req = urllib2.Request(fptplay)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.4) Gecko/2008092417 Firefox/4.0.4')
		response = urllib2.urlopen(req, timeout=90)
		link=response.read()
		response.close()
		match=re.compile("<li ><a href=\"(.+?)\" class=\".+?\">(.+?)<\/a><\/li>").findall(link)
		for url,name in match:
				if 'livetv' in url:
						addDir('[COLOR yellow]' + name + '[/COLOR]',fptplay + url,3,logos + 'fptplay.png')
				else:
						addDir('[COLOR lime]' + name + '[/COLOR]',fptplay + url,1,icon)	


	    
	content = make_request('http://play.fpt.vn/livetv/')
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a', {'class' : 'channel_link'})
	for item in items:
		img = item.find('img')
		if img is not None:
			try:
				add_link('', item['channel'], 0, 'http://play.fpt.vn' + item['href'], img['src'], '')
			except:
				pass

#add_dir(name,url,mode,iconimage,query='',type='f',page=0):
def get_vtc_movies(url, query='25', type='', page=0):
	if url == '':
		content = make_request('http://117.103.206.21:88/Movie/GetMovieGenres?device=4')
		result = json.loads(content)
		for item in result:
			add_dir(item["Name"], 'http://117.103.206.21:88/Movie/GetMoviesByGenre?device=4&genreid=' + str(item["ID"]) + '&start=0&length=25', 11, '', '25', str(item["ID"]), 0)
	if 'GetMoviesByGenre' in url:
		content = make_request(url)
		result = json.loads(content)
		for item in result:
			add_link('', item["Title"], 0, 'http://117.103.206.21:88/Movie/GetMovieStream?device=4&path=' + item["MovieUrls"][0]["Path"].replace('SD', 'HD'), item["Thumbnail3"], item["SummaryShort"])
		add_dir('Next', 'http://117.103.206.21:88/Movie/GetMoviesByGenre?device=4&genreid=' + type + '&start=' + str(int(query)+page) + '&length=' + str(query), 11, '', str(int(query)+page), type, page)
	
def get_vtc(url = None):
	content = make_request(url)
	
	result = json.loads(content)
	for item in result:
		path = item["ChannelUrls"][0]["Path"]
		if 'http' in path:
			add_link('', item["Name"], 0, item["ChannelUrls"][0]["Path"], item["Thumbnail2"], '')
		else:
			add_link('', item["Name"], 0, "http://117.103.206.21:88/channel/GetChannelStream?device=4&path=" + item["ChannelUrls"][0]["Path"], item["Thumbnail2"], '')

def get_hdonline(url = None):
	if url == '':
		content = make_request('http://old.hdonline.vn/')
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		items = soup.find('div',{'id' : 'full-mn-phim-le'}).findAll('a')
		for item in items:
			href = item.get('href')
			if href is not None:
				try:
					add_dir(item.text, href, 13, thumbnails + 'HDOnline.png', query, type, 0)
				except:
					pass
		return
	if 'xem-phim' in url:	
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		items = soup.findAll('ul', {'class' : 'clearfix listmovie'})[1].findAll('li')
		for item in items:
			a = item.find('a')
			img = item.find('img')
			span = item.find('span',{'class' : 'type'})
			href = a.get('href')
			if href is not None:
				try:
					if span is not None:
						add_dir(a.get('title') + ' (' + span.text + ')', href, 9, a.img['src'], '', '', 0)
					else:	
						add_link('', a.get('title'), 0, href, img['src'], '')
				except:
					pass
		items = soup.find('div',{'class' : 'pagination pagination-right'})
		if items is not None:
			for item in items.findAll('a'):
				a = item
				href = a.get('href')
				if href is not None:
					try:
						add_dir(a.get('title'), href, 9, thumbnails + 'zui.png', '', '', 0)
					except:
						pass
		
def get_zui(url = None):
	if url == '':
		content = make_request('http://zui.vn')
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		items = soup.find('div',{'class' : 'span8 visible-desktop visible-tablet'}).findAll('a')
		for item in items:
			href = item.get('href')
			if href is not None:
				try:
					add_dir(item.text, href, 9, thumbnails + 'zui.png', query, type, 0)
				except:
					pass
		return
	if 'the-loai' in url or 'phim-' in url:	
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		groups = soup.find('ul', {'class' : 'group'})
		if groups is not None:
			for item in groups.findAll('a'):
				matchObj = re.match( r'change_group_chapter\((\d+),(\d+),(\d+)\)', item['onclick'], re.M|re.I)
				response = urlfetch.fetch(
			url = 'http://zui.vn/?site=movie&view=show_group_chapter',
			method ='POST',
			data = {
				"pos": matchObj.group(1),
				"movie_id": matchObj.group(2),
				"type": matchObj.group(3)
			}
		)
				soup = BeautifulSoup(str(response.content), convertEntities=BeautifulSoup.HTML_ENTITIES)
				for item in soup.findAll('a'):
					add_link('', u'T?p ' + item.text, 0, 'http://zui.vn/' + item['href'], thumbnails + 'zui.png', '')
		else:
			items = soup.find('ul',{'class' : 'movie_chapter'})
			if items is not None:
				for item in items.findAll('a'):
					a = item
					href = a.get('href')
					if href is not None:
						try:
							add_link('', u'T?p ' + a.text, 0, 'http://zui.vn/' + href, thumbnails + 'zui.png', '')
							#add_dir(u'T?p ' + a.text, 'http://zui.vn/' + href, 9, thumbnails + 'zui.png', '', '', 0)
						except:
							pass
			else:
				items = soup.findAll('div',{'class' : 'poster'})
				for item in items:
					a = item.find('a')
					span = item.find('span',{'class' : 'type'})
					href = a.get('href')
					if href is not None:
						try:
							if span is not None:
								add_dir(a.get('title') + ' (' + span.text + ')', href, 9, a.img['src'], '', '', 0)
							else:	
								add_link('', a.get('title'), 0, href, a.img['src'], '')
						except:
							pass
				items = soup.find('div',{'class' : 'pagination pagination-right'})
				if items is not None:
					for item in items.findAll('a'):
						a = item
						href = a.get('href')
						if href is not None:
							try:
								add_dir(a.get('title'), href, 9, thumbnails + 'zui.png', '', '', 0)
							except:
								pass
	else:
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		groups = soup.find('ul', {'class' : 'group'})
		if groups is not None:
			for item in groups.findAll('a'):
				matchObj = re.match( r'change_group_chapter\((\d+),(\d+),(\d+)\)', item['onclick'], re.M|re.I)
				response = urlfetch.fetch(
			url = 'http://zui.vn/?site=movie&view=show_group_chapter',
			method ='POST',
			data = {
				"pos": matchObj.group(1),
				"movie_id": matchObj.group(2),
				"type": matchObj.group(3)
			}
		)
				soup = BeautifulSoup(str(response.content), convertEntities=BeautifulSoup.HTML_ENTITIES)
				for item in soup.findAll('a'):
					add_link('', u'T?p ' + item.text, 0, 'http://zui.vn/' + item['href'], thumbnails + 'zui.png', '')
			return
	
		items = soup.find('ul',{'class' : 'movie_chapter'})
		if items is not None:
			for item in items.findAll('a'):
				a = item
				href = a.get('href')
				if href is not None:
					try:
						add_link('', u'T?p ' + a.text, 0, 'http://zui.vn/' + href, thumbnails + 'zui.png', '')
						#add_dir(u'T?p ' + a.text, 'http://zui.vn/' + href, 9, thumbnails + 'zui.png', '', '', 0)
					except:
						pass
	
def get_fpt_other(url):
	content = make_request(url)
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a')
	for item in items:
		href = item.get('href')
		if href is not None and 'the-loai-more' in href and 'Xem' not in item.text:
			try:
				add_dir(item.text, 'http://play.fpt.vn' + href, 8, thumbnails + 'fptplay.jpg', query, type, 0)
			except:
				pass

def get_fpt_tvshow_cat(url):
	content = make_request(url)
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	if url is not None and '/Video/' not in url:
		items = soup.findAll('div', {'class' : 'col'})
		for item in items:
			img = item.a.img['src']
			href = item.a['href']
			text = item.a.img['alt']	
			try:
				add_dir(text, 'http://play.fpt.vn' + href, 8, img, '', '', 0)
			except:
				pass

	items = soup.find('ul', {'class' : 'pagination pagination-sm'}).findAll('a')
	for item in items:
		href = ''
		href = item.get('href')
		if href is not None and 'the-loai-more' in href and 'Xem' not in item.text:
			try:
				add_dir('Trang ' + item.text, 'http://play.fpt.vn' + href, 8, thumbnails + 'fptplay.jpg', query, type, 0)
			except:
				pass
		if href is not None and '/Video/' in href:
			try:
				add_link('', u'T?p ' + item.text, 0, 'http://play.fpt.vn' + href, thumbnails + 'fptplay.jpg', '')
			except:
				pass
		
def get_htv():
	content = make_request('http://www.htvonline.com.vn/livetv')
	soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
	items = soup.findAll('a', {'class' : 'mh-grids5-img'})
	for item in items:
		img = item.find('img')
		if img is not None:
			try:
				add_link('', item['title'], 0, item['href'], img['src'], '')
			except:
				pass

		
def get_categories():
	
	add_link('', 'VTV1 HD [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:vtv1hd_hls.smil/playlist.m3u8', thumbnails + 'VTV1.jpg', '')
	add_link('', 'VTV3 HD [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:vtv3hd_hls.smil/playlist.m3u8', thumbnails + 'VTV3 HD.jpg', '')
	add_link('', 'VTV6 HD [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:vtv6hd_hls.smil/playlist.m3u8', thumbnails + 'VTV6 HD.jpg', '')
	add_link('', 'VTVCAB1 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:giaitritv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB2 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:phimviet_hls.smil/playlist.m3u8', thumbnails + '', '')
        add_link('', 'VTVCAB4 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:kenh17_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB7 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:ddramas_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB8 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:bibi_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB9 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:infotv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB10 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:o2tv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB12 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:styletv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTVCAB15 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:investtv_hls.smil/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HANOI 1 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:hanoi1_hls.smil/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTV9 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:htv9_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'HTVC PHU NU [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:htvcphunu_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'VTC4 [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:yeah1tv_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD HAI(720P) [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:sctvhaihd_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'ARIANG VTVPLAY', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:arirang_hls.smil/playlist.m3u8', thumbnails + '', '')
	add_link('', 'KBS [COLOR teal]VTVPLAY[/COLOR]', 0, 'http://vtv.live.cdn.fptplay.net/vtvlive/smil:kbs_hls.smil/playlist.m3u8', thumbnails + '', '')
	#add_link('', 'National Geographic HD', 0, 'http://www.htvonline.com.vn/livetv/national-geographic-3132366E61.html&mode=4', thumbnails + 'Natgeo-HD.jpg', '')
	#add_link('', 'Star Movies HD', 0, 'http://www.htvonline.com.vn/livetv/star-movie-hd-3132376E61.html&mode=4 ', thumbnails + 'StarMoviesHD.jpg', '')
	add_link('', 'VTV3 HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/1', '', '')
	add_link('', 'VTV6 HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/5', '', '')
	#add_link('', 'VTVCAB3 THE THAO TV [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/12', '', '')
	add_link('', 'VTVCAB16 BONG DA HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/11', '', '')
	add_link('', 'HTVC THUAN VIET HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/30', '', '')
	add_link('', 'NATGEO HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/46', '', '')
	add_link('', 'NATGEO WILD HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/48', '', '')
	add_link('', 'STAR MOVIES HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/18', '', '')
	add_link('', 'STAR WORLD HD [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/44', '', '')
	#add_link('', 'VTV1 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/2', '', '')
	add_link('', 'VTV2 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/3', '', '')
	#add_link('', 'VTV3 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/87', '', '')
	add_link('', 'VTV4 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/4', '', '')
	#add_link('', 'VTV6 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/88', '', '')
	add_link('', 'VTV9 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/6', '', '')
	add_link('', 'TTXVN [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/54', '', '')
	add_link('', 'ANTV [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/52', '', '')
	add_link('', 'VTVCAB1 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/56', '', '')
	add_link('', 'VTVCAB2 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/20', '', '')
	#add_link('', 'VTVCAB3 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/15', '', '')
	add_link('', 'VTVCAB4 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/7', '', '')
	add_link('', 'VTVCAB5 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/21', '', '')
	add_link('', 'VTVCAB6 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/23', '', '')	
	add_link('', 'VTVCAB7 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/19', '', '')
	add_link('', 'VTVCAB8 BIBI [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/59', '', '')
	add_link('', 'VTVCAB10 O2TV [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/62', '', '')
	add_link('', 'VTVCAB12 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/58', '', '')
	add_link('', 'VTVCAB15 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/14', '', '')
	#add_link('', 'VTVCAB16 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/17', '', '')
	add_link('', 'VTVCAB17 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/57', '', '')
	add_link('', 'HTV3 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/39', '', '')
	add_link('', 'HTV4 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/42', '', '')	
	add_link('', 'HTV7 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/37', '', '')
	add_link('', 'HTV9 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/38', '', '')
	add_link('', 'HTV THE THAO [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/13', '', '')
	add_link('', 'HTV CA NHAC [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/40', '', '')
	add_link('', 'HTVC FBNC [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/43', '', '')
	add_link('', 'VTC7 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/24', '', '')	
	add_link('', 'VTC9 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/29', '', '')
	#add_link('', 'BTV3 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/70', '', '')
	add_link('', 'BTV4 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/69', '', '')
	add_link('', 'THVL1 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/53', '', '')
	add_link('', 'NATGEO [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/50', '', '')
	add_link('', 'CHANNEL 1 [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/47', '', '')
	add_link('', 'CNN [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/45', '', '')
	add_link('', 'BBC WORLD NEWS [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/49', '', '')
	add_link('', 'MTV [COLOR lime]VTVPlus[/COLOR]', 0, 'plugin://plugin.video.kodi4vn.vtvplus/play/55', '', '')
	#add_link('', 'VTV1 HD FPTPLAY', 0, 'http://hlscache.fptplay.net.vn/livev/vtv1hd_1000.stream/playlist.m3u8?token=c335VydmVyX3RpbWU9MTQwMjYxNzIyNCZoYXNoX3ZhbHVl&did=NzIyNCZoYXNoX3ZhbHVl', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]VTC1 HD', 0, 'http://113.160.49.34/lives/origin03/vtchd1hd.isml/vtchd1hd-2096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC HD2', 0, 'http://113.160.49.34/lives/origin03/vtchd2hd.isml/vtchd2hd-2096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC3 HD', 0, 'http://113.160.49.34/lives/origin03/vtc3hd.isml/vtc3hd.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]ITV HD', 0, 'http://113.160.49.34/lives/origin03/itvhd.isml/itvhd.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]DISCOVERY HD', 0, 'http://113.160.49.34/lives/origin03/discoveryhd.isml/discoveryhd.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]STAR MOVIES HD', 0, 'http://113.160.49.34/lives/origin03/moviehd.isml/moviehd.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]AXN HD', 0, 'http://113.160.49.34/lives/origin03/axnhd.isml/axnhd.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HBO HD', 0, 'http://113.160.49.34/lives/origin03/hbohd.isml/hbohd.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]FOXSPORT HD', 0, 'http://113.160.49.34/lives/origin03/foxhd.isml/foxhd-2096k.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]FASHION HD', 0, 'http://113.160.49.34/lives/origin03/fashionhd.isml/fashionhd-2096k.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]NCM BYV10', 0, 'http://113.160.49.34/lives/origin03/ncmsd.isml/ncmsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]PHIM HAY', 0, 'http://113.160.49.34/lives/origin01/phimhaysd.isml/phimhaysd-1096k.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]AN NINH THE GIOI', 0, 'http://113.160.49.34/lives/origin01/STTVsd.isml/STTVsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]SAM CHANNEL', 0, 'http://113.160.49.34/lives/origin01/samsd.isml/samsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC NHE', 0, 'http://113.160.49.34/lives/origin03/nhacnhesd.isml/nhacnhesd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC TRU TINH', 0, 'http://113.160.49.34/lives/origin03/nhactrutinhsd.isml/nhactrutinhsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC TRE', 0, 'http://113.160.49.34/lives/origin03/nhactresd.isml/nhactresd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC CACH MANG', 0, 'http://113.160.49.34/lives/origin03/nhaccachmangsd.isml/nhaccachmangsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC THIEU NHI', 0, 'http://113.160.49.34/lives/origin03/nhacthieunhisd.isml/nhacthieunhisd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC DAN TOC', 0, 'http://113.160.49.34/lives/origin03/nhacdantocsd.isml/nhacdantocsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC NAM BO', 0, 'http://113.160.49.34/lives/origin03/nhacnambosd.isml/nhacnambosd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NHAC CO DIEN', 0, 'http://113.160.49.34/lives/origin01/nhaccodiensd.isml/nhaccodiensd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]THÐT 2', 0, 'http://113.160.49.34/lives/origin03/mientaysd.isml/mientaysd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VIETTEEN', 0, 'http://113.160.49.34/lives/origin03/vietteensd.isml/vietteensd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]DOC SACH', 0, 'http://113.160.49.34/lives/origin01/docsachsd.isml/docsachsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTV1', 0, 'http://113.160.49.34/lives/origin03/vtv1sd.isml/vtv1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTV2', 0, 'http://113.160.49.34/lives/origin03/vtv2sd.isml/vtv2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTV3', 0, 'http://113.160.49.34/lives/origin03/vtv3sd.isml/vtv3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTV4', 0, 'http://113.160.49.34/lives/origin03/vtv4sd.isml/vtv4sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTV6', 0, 'http://113.160.49.34/lives/origin03/vtv6sd.isml/vtv6sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]TTXVN', 0, 'http://113.160.49.34/lives/origin02/ttxvnsd.isml/ttxvnsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]ANTV', 0, 'http://113.160.49.34/lives/origin02/antvsd.isml/antvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]QPVN', 0, 'http://113.160.49.34/lives/origin02/qptvsd.isml/qptvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTVCAB8 BiBi', 0, 'http://113.160.49.34/lives/origin03/bibisd.isml/bibisd.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HTV7', 0, 'http://113.160.49.34/lives/origin01/htv7sd.isml/htv7sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HTV9', 0, 'http://113.160.49.34/lives/origin02/htv9sd.isml/htv9sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC1', 0, 'http://113.160.49.34/lives/origin01/vtc1sd.isml/vtc1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC2', 0, 'http://113.160.49.34/lives/origin01/vtc2sd.isml/vtc2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC3', 0, 'http://113.160.49.34/lives/origin01/vtc3sd.isml/vtc3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC4', 0, 'http://113.160.49.34/lives/origin01/vtc4sd.isml/vtc4sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC5', 0, 'http://113.160.49.34/lives/origin01/vtc5sd.isml/vtc5sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC6', 0, 'http://113.160.49.34/lives/origin01/vtc6sd.isml/vtc6sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC7', 0, 'http://113.160.49.34/lives/origin01/vtc7sd.isml/vtc7sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC8', 0, 'http://113.160.49.34/lives/origin01/vtc8sd.isml/vtc8sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC9', 0, 'http://113.160.49.34/lives/origin01/vtc9sd.isml/vtc9sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC10', 0, 'http://113.160.49.34/lives/origin01/vtc10sd.isml/vtc10sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC11', 0, 'http://113.160.49.34/lives/origin01/vtc11sd.isml/vtc11sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC12', 0, 'http://113.160.49.34/lives/origin01/vtc12sd.isml/vtc12sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC13', 0, 'http://113.160.49.34/lives/origin01/vtc13sd.isml/vtc13sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC14', 0, 'http://113.160.49.34/lives/origin01/vtc14sd.isml/vtc14sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VTC16', 0, 'http://113.160.49.34/lives/origin01/vtc16sd.isml/vtc16sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HN 1', 0, 'http://113.160.49.34/lives/origin01/h1sd.isml/h1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HN 2', 0, 'http://113.160.49.34/lives/origin01/h2sd.isml/h2sd-1096k.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]AVG [/COLOR]HCATV VNK', 0, 'http://113.160.49.34/lives/origin01/vietnamnetsd.isml/vietnamnetsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HAI PHONG', 0, 'http://113.160.49.34/lives/origin01/haiphongsd.isml/haiphongsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]THAI NGUYEN', 0, 'http://113.160.49.34/lives/origin01/thainguyensd.isml/thainguyensd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]HOA BINH', 0, 'http://113.160.49.34/lives/origin02/hbtvsd.isml/hbtvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]TUYEN QUANG', 0, 'http://113.160.49.34/lives/origin02/ttv2sd.isml/ttv2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]QN 1', 0, 'http://113.160.49.34/lives/origin01/qtv1sd.isml/qtv1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR] QN 3', 0, 'http://113.160.49.34/lives/origin02/qtv3sd.isml/qtv3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NINH BINH', 0, 'http://113.160.49.34/lives/origin02/ntv3sd.isml/ntv3sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]THANH HOA', 0, 'http://113.160.49.34/lives/origin01/thanhhoasd.isml/thanhhoasd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NGHE AN', 0, 'http://113.160.49.34/lives/origin01/ngheansd.isml/ngheansd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]QUANG NGAI', 0, 'http://113.160.49.34/lives/origin02/ptq1sd.isml/ptq1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]NINH THUAN', 0, 'http://113.160.49.34/lives/origin02/ninhthuansd.isml/ninhthuansd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]LAM DONG', 0, 'http://113.160.49.34/lives/origin02/ltvsd.isml/ltvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]GIA LAI', 0, 'http://113.160.49.34/lives/origin02/thglsd.isml/thglsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]BINH PHUOC 2', 0, 'http://113.160.49.34/lives/origin02/bptv2sd.isml/bptv2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]DONG NAI 1', 0, 'http://113.160.49.34/lives/origin02/dn1sd.isml/dn1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]DONG NAI 2', 0, 'http://113.160.49.34/lives/origin02/dn2sd.isml/dn2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]BA RIA VUNG TAU', 0, 'http://113.160.49.34/lives/origin02/brtsd.isml/brtsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VINH LONG 1', 0, 'http://113.160.49.34/lives/origin01/vinhlongsd.isml/vinhlongsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]VINH LONG 2', 0, 'http://113.160.49.34/lives/origin02/thvl2sd.isml/thvl2sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]TRA VINH', 0, 'http://113.160.49.34/lives/origin02/thtvsd.isml/thtvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]KIEN GIANG 1', 0, 'http://113.160.49.34/lives/origin02/kg1sd.isml/kg1sd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]AN GIANG 1', 0, 'http://113.160.49.34/lives/origin02/atvsd.isml/atvsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]FBNC', 0, 'http://113.160.49.34/lives/origin02/fbncsd.isml/fbncsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]ANIMAL PLANET', 0, 'http://113.160.49.34/lives/origin03/animalsd.isml/animalsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]STAR MOVIES', 0, 'http://113.160.49.34/lives/origin03/starmoviesd.isml/starmoviesd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]CINEMAX', 0, 'http://113.160.49.34/lives/origin03/cinemaxsd.isml/cinemaxsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]STAR SPORTS', 0, 'http://113.160.49.34/lives/origin03/starsportsd.isml/starsportsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]FOX SPORTS', 0, 'http://113.160.49.34/lives/origin03/foxsd.isml/foxsd-1096k.m3u8', thumbnails + '', '')
        add_link('', '[COLOR aqua]AVG [/COLOR]CARTOON NETWORK', 0, 'http://113.160.49.34/lives/origin03/cartoonsd.isml/cartoonsd-1096k.m3u8', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD SÓNG NHẠC (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C006_HD_4/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')	
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD DU LỊCH (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C007_HD_4/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM VIỆT (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C009_HD_4/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM CHÂU Á (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C010_HD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD HÀI (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C011_HD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD SÂN KHẤU (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C012_HD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM TỔNG HỢP (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C013_HD_4/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD GIẢI TRÍ TỔNG HỢP (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C014_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM NƯỚC NGOÀI ĐẶC SẮC (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C015_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD THIẾU NHI (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C016_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHỤ NỮ VÀ GIA ĐÌNH (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C017_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD THỂ THAO (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C008_HD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD STAR MOVIES (720P)', 0, 'http://sctv.live.cdn.anluong.info/live/C001_HD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD SÓNG NHẠC (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C006_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD DU LỊCH (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C007_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM VIỆT (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C009_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM CHÂU Á (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C010_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD HÀI (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C011_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD SÂN KHẤU (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C012_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM TỔNG HỢP (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C013_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD GIẢI TRÍ TỔNG HỢP (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C014_HD_1/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHIM NƯỚC NGOÀI ĐẶC SẮC (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C015_HD_1/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD THIẾU NHI (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C016_HD_1/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD PHỤ NỮ VÀ GIA ĐÌNH (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C017_HD_1/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD THỂ THAO (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C008_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]HD STAR MOVIES (480P)', 0, 'http://sctv.live.cdn.anluong.info/live/C001_HD_2/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]1 Hài', 0, 'http://sctv.live.cdn.anluong.info/live/C027_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]2 Âm nhạc quốc tế', 0, 'http://sctv.live.cdn.anluong.info/live/C028_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]3 Thiếu nhi', 0, 'http://sctv.live.cdn.anluong.info/live/C029_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]4 Giải trí tổng hợp', 0, 'http://sctv.live.cdn.anluong.info/live/C030_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]5 Mua sắm SCJ', 0, 'http://sctv.live.cdn.anluong.info/live/C037_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]6 Sóng nhạc', 0, 'http://sctv.live.cdn.anluong.info/live/C038_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]7 Sân khấu Văn nghệ tổng hợp', 0, 'http://sctv.live.cdn.anluong.info/live/C039_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]8 Thông tin Kinh tế Thị trường', 0, 'http://sctv.live.cdn.anluong.info/live/C040_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]9 Phim châu Á', 0, 'http://sctv.live.cdn.anluong.info/live/C041_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]10 Home Shopping Network', 0, 'http://sctv.live.cdn.anluong.info/live/C064_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]11 Hát trên truyền hình', 0, 'http://sctv.live.cdn.anluong.info/live/C066_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]12 Du lịch Khám phá', 0, 'http://sctv.live.cdn.anluong.info/live/C067_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]13 Phụ nữ và Gia đình', 0, 'http://sctv.live.cdn.anluong.info/live/C031_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]14 Phim Vietnam', 0, 'http://sctv.live.cdn.anluong.info/live/C032_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]15 The Thao', 0, 'http://sctv.live.cdn.anluong.info/live/C042_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]16 Phim truyện nước ngoà', 0, 'http://sctv.live.cdn.anluong.info/live/C033_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]17 Phim tổng hợp', 0, 'http://sctv.live.cdn.anluong.info/live/C034_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTV1 Thông Tin Tổng Hợp', 0, 'http://sctv.live.cdn.anluong.info/live/C043_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTV2 Khoa Học Giáo Dục', 0, 'http://sctv.live.cdn.anluong.info/live/C044_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTV3 Giải Trí – Thể Thao', 0, 'http://sctv.live.cdn.anluong.info/live/C035_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTV4 Vietnam Hải Ngoại', 0, 'http://sctv.live.cdn.anluong.info/live/C045_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTV6', 0, 'http://sctv.live.cdn.anluong.info/live/C046_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTV9', 0, 'http://sctv.live.cdn.anluong.info/live/C047_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-ANTV', 0, 'http://sctv.live.cdn.anluong.info/live/C048_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTVCAB5', 0, 'http://sctv.live.cdn.anluong.info/live/C059_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTVCAB9', 0, 'http://sctv.live.cdn.anluong.info/live/C055_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTVCAB10', 0, 'http://sctv.live.cdn.anluong.info/live/C054_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTVHUE', 0, 'http://sctv.live.cdn.anluong.info/live/C061_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-VTVCANTHO1', 0, 'http://sctv.live.cdn.anluong.info/live/C063_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-HN1', 0, 'http://sctv.live.cdn.anluong.info/live/C057_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-HN2', 0, 'http://sctv.live.cdn.anluong.info/live/C050_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-HTV9', 0, 'http://sctv.live.cdn.anluong.info/live/C053_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-DRT1', 0, 'http://sctv.live.cdn.anluong.info/live/C060_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-BRT', 0, 'http://sctv.live.cdn.anluong.info/live/C062_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-LA34', 0, 'http://sctv.live.cdn.anluong.info/live/C051_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR]-THVL1', 0, 'http://sctv.live.cdn.anluong.info/live/C049_SD_3/chunklist.m3u8?us=9b9aea5546402462bbb2e05df3ad5fdccb9cfdcf968ad7a6c14937bbf42a62b5ac95ddff24e337955113e2468571ec8f%7C1397200', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTVCAB2', 0, 'http://2co1.vp9.tv/chn/phimv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTVCAB7', 0, 'http://2co1.vp9.tv/chn/ddra/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTVCAB8', 0, 'http://2co1.vp9.tv/chn/bibi/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTVCAB10', 0, 'http://2co1.vp9.tv/chn/o2tv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]BONGDATV HD', 0, 'http://2co1.vp9.tv/chn/bdtv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]THETHAOTV HD', 0, 'http://2co1.vp9.tv/chn/tttv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTV1', 0, 'http://2co1.vp9.tv/chn/vtv1/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTV2', 0, 'http://2co1.vp9.tv/chn/vtv2/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTV3 HD', 0, 'http://2co1.vp9.tv/chn/vtv3/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTV4', 0, 'http://2co1.vp9.tv/chn/vtv4/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTV6 HD', 0, 'http://2co1.vp9.tv/chn/vtv6/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC1', 0, 'http://2co1.vp9.tv/chn/vtc1/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC2', 0, 'http://2co1.vp9.tv/chn/vtc2/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC3', 0, 'http://2co1.vp9.tv/chn/vtc3/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC6', 0, 'http://2co1.vp9.tv/chn/sgc6/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC7', 0, 'http://2co1.vp9.tv/chn/tdayt/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC9', 0, 'http://2co1.vp9.tv/chn/letsv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC11', 0, 'http://2co1.vp9.tv/chn/kids/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VTC16', 0, 'http://2co1.vp9.tv/chn/3ntv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]ANTV', 0, 'http://2co1.vp9.tv/chn/antv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]QPVN', 0, 'http://2co1.vp9.tv/chn/qpvn/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]VOVTV', 0, 'http://2co1.vp9.tv/chn/vovtv/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]HN1', 0, 'http://2co1.vp9.tv/chn/hn1/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]HN2', 0, 'http://2co1.vp9.tv/chn/hn2/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]HTV7', 0, 'http://2co1.vp9.tv/chn/htv7/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]ARIANG', 0, 'http://2co1.vp9.tv/chn/arirg/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]NICKELODEON', 0, 'http://2co1.vp9.tv/chn/nicke/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]STAR WOLD', 0, 'http://2co1.vp9.tv/chn/starw/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]BEIN1 SPORT', 0, 'http://115.146.126.226/chn/bin01/v.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]VP9 [/COLOR]BEIN4 SPORT', 0, 'http://115.146.126.226/chn/bin04/v.m3u8', thumbnails + '', '')
	add_link('', 'VTV4 ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vtv4.480p/playlist.m3u8', thumbnails + '', '')	
        add_link('', 'VTVcab2 ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vctv2.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'VTVcab4 ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vctv4.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'VTVcab10 ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:vctv10.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTVC DU LICH ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:dulichcuocsong.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTVC THUAN VIET ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:thuanviet.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', 'HTVC FBNC ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:htvcfbnc.480p/htvcfbnc.m3u8', thumbnails + '', '')
        add_link('', '[COLOR fuchsia]SCTV[/COLOR]HAI ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:sctvhaihd.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', '[COLOR fuchsia]SCTV[/COLOR]7 ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:sctv7.480p/playlist.m3u8', thumbnails + '', '')
        add_link('', '[COLOR fuchsia]SCTV[/COLOR]14 ([COLOR lime]AccessASIA[/COLOR])', 0, 'http://live.accessasia.tv:1935/vnptg_channels/mp4:sctv14.480p/playlist.m3u8', thumbnails + '', '')
	#add_link('', 'VietNews', 0, 'rtmp://69.178.181.93:1935/VietNews/myStream', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Viet USA TV', 0, 'http://stream.onworldtv.com/live/vus/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Phim 24h', 0, 'http://stream.onworldtv.com/live/film24/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Cuoi 24h', 0, 'http://stream.onworldtv.com/live/laugh24/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Itv HomeShopping', 0, 'http://stream.onworldtv.com/live/itvshop/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]SGN TV Houston TX 51.3', 0, 'http://stream.onworldtv.com/live/sgn/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]BYN CHANNEL', 0, 'http://stream.onworldtv.com/live/byn/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]News 24h', 0, 'http://stream.onworldtv.com/live/news24/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]SOL CHANNEL', 0, 'http://stream.onworldtv.com/live/sol/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Little Saigon TV', 0, 'http://stream.onworldtv.com/live/lstv/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Vietnamese American Network', 0, 'http://stream.onworldtv.com/live/van/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]ACTIVA TV', 0, 'http://stream.onworldtv.com/live/activatv/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Teleprogreso TV', 0, 'http://stream.onworldtv.com/live/teleprogreso/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]The Gioi Tu Thien Channel', 0, 'http://stream.onworldtv.com/live/thegioituthien/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Teleceiba TV Channel', 0, 'http://stream.onworldtv.com/live/teleceiba/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]TV Centro', 0, 'http://stream.onworldtv.com/live/centrotv/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]CampusTV HD', 0, 'http://stream.onworldtv.com/live/campus/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]TVO TV Channel', 0, 'http://stream.onworldtv.com/live/tvo/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]MTV 24 Giờ', 0, 'http://stream.onworldtv.com/live/mtv24/index.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]OnWorldTV [/COLOR]Teleprogreso TV', 0, 'http://stream.onworldtv.com/live/teleprogreso/index.m3u8', thumbnails + '', '')
        add_link('', 'TOM AND JERRY', 0, 'http://66.90.111.66:1935/ctv/tom/playlist.m3u8', thumbnails + '', '')
        add_link('', 'ALJAZEERA DOC', 0, 'rtmp://aljazeeraflashlivefs.fplive.net:1935/aljazeeraflashlive-live playpath=aljazeera_doc_high swfUrl=http://admin.brightcove.com/viewer/us1.25.04.00.2011-05-19124744/federatedVideoUI/BrightcovePlayer.swf live=1 pageUrl=http://upload.wikimedia.org/wikipedia/en/e/e6/Al_Jazeera_Doc.png', thumbnails + '', '')
        add_link('', 'ARTE FRANCE', 0, 'http://frlive.artestras.cshls.lldns.net/artestras/contrib/frlive/frlive_925.m3u8', thumbnails + '', '')
        add_link('', 'BBC news', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/bbc_world/ls_satlink/b_828.m3u8', thumbnails + '', '')
	add_link('', 'ABC NEWS', 0, 'http://abclive.abcnews.com/i/abc_live4@136330/index_1200_av-b.m3u8?sd=10&b=1200&rebase=on', thumbnails + '', '')
	add_link('', 'NHK WORLD', 0, 'http://plslive-w.nhk.or.jp/nhkworld/app/live.m3u8', thumbnails + '', '')
	add_link('', 'FRANCE24', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/france24_en/ls_satlink/b_828.m3u8', thumbnails + '', '')
	add_link('', 'EURONEWS', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/euronews_ar/ls_satlink/b_828.m3u8', thumbnails + '', '')	
	add_link('', 'ARIANG', 0, 'http://worldlive-ios.arirang.co.kr/arirang/arirangtvworldios.mp4.m3u8', thumbnails + '', '')
	add_link('', 'CBS', 0, 'http://cbs-live.gscdn.com/cbs-live/cbs-live.stream/hasbahca.m3u8', thumbnails + '', '')
	add_link('', 'ALJAZEERA', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/aljazeera_en/ls_satlink/b_828.m3u8', thumbnails + '', '')
	add_link('', 'CNN', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/cnn/ls_satlink/b_828.m3u8', thumbnails + '', '')
	add_link('', 'DW', 0, 'http://dwtvios_asiaplus-i.akamaihd.net/hls/live/200521/dwtvasiaplus/x6x/playlist6x.m3u8', thumbnails + '', '')
	add_link('', 'I24 NEWS', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/i24/ls_satlink/b_828.m3u8', thumbnails + '', '')
	add_link('', 'LIFE NEWS', 0, 'http://tv.life.ru/lifetv/720p/index.m3u8', thumbnails + '', '')
	add_link('', 'RUSIA TODAY', 0, 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/livestation/ls_lmle/rt_828.m3u8', thumbnails + '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]NATGEO WILD', 0, 'http://202.75.23.35/live/ch39/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]DMAX ', 0, 'http://202.75.23.34/live/ch32/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]DISCOVERY WORLD', 0, 'http://202.75.23.34/live/ch30/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]DISCOVERY', 0, 'http://202.75.23.34/live/ch29/01.m3u8?Vd?u#bt!25', '', '')
	#add_link('', '[COLOR aqua]USA [/COLOR]DISCOVERY SC ', 0, 'http://202.75.23.34/live/ch33/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]ANIMAL PLANET', 0, 'http://202.75.23.34/live/ch31/01.m3u8?Vd?u#bt!25', '', '')
	#add_link('', '[COLOR aqua]USA [/COLOR]TLC', 0, 'http://202.75.23.34/live/ch35/01.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]Fox College Sports HD 720p', 0, 'http://ftve1100-i.akamaihd.net/hls/live/217047/fcsp/3964k/prog.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]ABC HD 720p', 0, 'http://abclive.abcnews.com/i/abc_live4@136330/master.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]PAC12 CALIFORNIA Bay Area 1080p', 0, 'http://xrxs.net/video/live-p12baya-4728.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]SPAN ESPN CANAL516', 0, 'http://200.76.77.237/LIVE/H01/CANAL516/PROFILE03.m3u8?', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]SPAN FOX SPORTS CANAL522', 0, 'http://200.76.77.237/LIVE/H01/CANAL522/PROFILE03.m3u8?', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]SPAN FOX SPORT 2 CANAL527', 0, 'http://200.76.77.237/LIVE/H01/CANAL527/PROFILE03.m3u8?', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]RUS SPORT 1 Soccer 720p', 0, 'http://178.49.132.73/streaming/sport1/tvrec/playlist.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]Golf Channel 720p', 0, 'http://tvegolf-i.Akamaihd.net/hls/live/218225/golfx/2596k/prog.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]UFC FightBox', 0, 'http://83.139.104.112/Content/HLS/Live/Channel(fight_channel)/Stream(03)/index.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]CANADA Shopping Channel 1080p', 0, 'http://tscstreaming-lh.akamaihd.net/i/TSCLiveStreaming_1@91031/master.m3u8?b?b*t$', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]Big Ten Network 720p', 0, 'http://bigten247.cdnak.bigtenhd.neulion.com/nlds/btn2go/btnnetwork/as/live/btnnetwork_hd_3000.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]GERMANY Kanal Sports 720p', 0, 'http://lswb-de-08.servers.octoshape.net:1935/live/kanalsport_2000k/HD.m3u8?Vd?u#bt!25', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]GERMANY WDR 720p', 0, 'http://wdr_fs-lh.akamaihd.net/i/wdrfs_weltweit@112033/master.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]GERMANY Family TV 720p', 0, 'rtmp://83.169.58.36/live/Stream3', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]UK Vevo TV 730p', 0, 'http://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch1/06/prog_index.m3u8', '', '')
	add_link('', 'VTV1 HD', 0, 'http://vtvplay.vn/api/channel?streamid=1', thumbnails + 'vtv1hd.png', '')
	add_link('', '[COLOR fuchsia]SCTV[/COLOR] HAI HD', 0, 'http://vtvplay.vn/api/channel?streamid=118', thumbnails + 'haihd.png', '')
	add_link('', 'GIAI TRI TV', 0, 'http://vtvplay.vn/api/channel?streamid=144', thumbnails + 'GTTV.png', '')
	add_link('', 'PHIM VIET', 0, 'http://vtvplay.vn/api/channel?streamid=143', thumbnails + 'PHIMVIET.png', '')
	add_link('', 'THETHAOTV SD', 0, 'http://vtvplay.vn/api/channel?streamid=149', thumbnails + 'tttvsd.png', '')
	add_link('', 'KENH17', 0, 'http://vtvplay.vn/api/channel?streamid=136', thumbnails + 'kenh17.png', '')
	add_link('', 'BIBI', 0, 'http://vtvplay.vn/api/channel?streamid=31', thumbnails + 'bibi.png', '')
	add_link('', 'INFOTV', 0, 'http://vtvplay.vn/api/channel?streamid=147', thumbnails + 'iftv.png', '')
	add_link('', 'O2TV', 0, 'http://vtvplay.vn/api/channel?streamid=145', thumbnails + 'o2tv.png', '')
	add_link('', 'INVESTTV', 0, 'http://vtvplay.vn/api/channel?streamid=146', thumbnails + 'ivtv.png', '')
	add_link('', 'BONGDATV SD', 0, 'http://vtvplay.vn/api/channel?streamid=148', thumbnails + 'bdtvsd.png', '')
	add_link('', 'AXN HD', 0, 'http://113.160.49.34/lives/origin03/axnhd.isml/axnhd-2096k.m3u8', thumbnails + 'axnhd.png', '')
	add_link('', 'HBO HD', 0, 'http://113.160.49.34/lives/origin03/hbohd.isml/hbohd-2096k.m3u8', thumbnails + 'hboHD2.png', '')
	add_link('', 'CHANNEL V', 0, 'http://113.160.49.34/lives/origin03/channelvsd.isml/channelvsd-1096k.m3u8', thumbnails + 'channel_v.png', '')
	add_link('', '[COLOR aqua]USA [/COLOR]BEIN SPORTS (720p)', 0, 'rtmp://65.111.174.111/iptv/beinsports2.stream', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]NBA TV (720p)', 0, 'http://hls35.livestreamingcdn.com/livecdn625/myStream.sdp/chunklist_w1461107752.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]FOX SPOPRTS UK (720p)', 0, 'http://foxsportshdhls-lh.akamaihd.net/i/fsnewshls_0@136427/index_2128_av-p.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]HBO 2', 0, 'rtmp://89.248.168.57:1935/iguide playpath=0bf02qe6msgtu4s swfUrl=http://www.iguide.to/player/secure_player_iguide_token.swf live=1 pageUrl=http://www.iguide.to/view/1/HBO token=#ed%h0#w18623jsda6523lDGDve', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]ESPN', 0, 'http://200.38.126.38:8081/TPHLSWeb/M3U8LiveFile?format=2&profile=389&lan=2&rows=40&f=.m3u8', '', '')
	add_link('', '[COLOR aqua]USA [/COLOR]FOX ACTION 1080', 0, 'http://200.38.126.38:8081/TPHLSWeb/M3U8LiveFile?format=2&profile=302&lan=2&rows=40&f=.m3u8', '', '')
	#http://scache.fptplay.net.vn/live/htvcplusHD_1000.stream/manifest.f4m
	add_dir(' >>> HTVOnline TV', url, 5, thumbnails + 'htv.jpg', query, type, 0)
	#add_dir('VTCPlay - TV', 'http://117.103.206.21:88/Channel/GetChannels?device=4', 10, thumbnails + 'vtcplay.jpg', query, type, 0)
	#add_dir('VTCPlay - Movies', '', 11, thumbnails + 'vtcplay.jpg', query, type, 0)
	#add_dir('FPTPlay - TV', url, 6, thumbnails + 'fptplay_logo.jpg', query, type, 0)
	#add_dir('FPTPlay - TVShow', url, 7, thumbnails + 'fptplay_logo.jpg', query, type, 0)
	#add_dir('ZUI.VN', url, 9, thumbnails + 'zui.png', query, type, 0)
	#add_dir('HDOnline.vn', url, 13, thumbnails + 'HDOnline.png', query, type, 0)

def searchMenu(url, query = '', type='f', page=0):
	add_dir('New Search', url, 2, icon, query, type, 0)
	add_dir('Clear Search', url, 3, icon, query, type, 0)

	searchList=cache.get('searchList').split("\n")
	for item in searchList:
		add_dir(item, url, 2, icon, item, type, 0)

def resolve_url(url):
	make_request("http://feed.hdrepo.com/hitcount.php?url=" + url);
	if 'zui.vn' in url:
		headers2 = {'User-agent' : 'iOS / Chrome 32: Mozilla/5.0 (iPad; CPU OS 7_0_4 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/32.0.1700.20 Mobile/11B554a Safari/9537.53',
											 'Referer' : 'http://www.google.com'}
		content = make_request(url, headers2)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		for line in content.splitlines():
			s = line.strip()
			if s.startswith('movie_play_chapter'):
				#movie_play_chapter('mediaplayer', '1', 'rtmp://103.28.37.89:1935/vod3/mp4:/phimle/Vikingdom.2013.720p.WEB-DL.H264-PHD.mp4', '/uploads/movie_view/5c65563b1ce8d106c013.jpg', 'http://zui.vn/subtitle/Vikingdom.2013.720p.WEB-DL.H264-PHD.srt');
				matchObj = re.match( r'[^\']*\'([^\']*)\', \'([^\']*)\', \'([^\']*)\', \'([^\']*)\', \'([^\']*)\'', s, re.M|re.I)
				url = matchObj.group(3)
				url = url.replace(' ','%20')
				xbmc.Player().play(url)
				xbmc.Player().setSubtitles(matchObj.group(5))
				return
				break

	if 'play.fpt.vn/Video' in url:
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		for line in content.splitlines():
			s = line.strip()
			if s.startswith('"<source src='):
				start = s.index('\'')+1
				end = s.index('\'', start+1)
				url = s[start:end]
				break

	if 'play.fpt.vn' in url:
		content = make_request(url)
		soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
		item = soup.find('div', {'id' : 'bitrate-tag'})
		url = item['highbitrate-link']
		content = make_request(url)
		for line in content.splitlines():
			s = line.strip()
			if s.startswith('<id>'):
				start = s.index('<id>')+4
				end = s.index('<', start+1)
				url = url.replace('manifest.f4m',s[start:end])
				url = 'http://scache.fptplay.net.vn/live/' + s[start:end] + '/playlist.m3u8'
				break
			       
	if 'htvonline' in url:
		content = make_request(url)
		for line in content.splitlines():
			if line.strip().startswith('file: '):
				url = line.strip().replace('file: ', '').replace('"', '').replace(',', '')
				break

			
	if 'GetChannelStream' in url or 'GetMovieStream' in url or 'vtvplay' in url:
		content = make_request(url)
		url = content.replace("\"", "")
		url = url[:-5]
	item = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return

def add_link(date, name, duration, href, thumb, desc):
	description = date+'\n\n'+desc
	u=sys.argv[0]+"?url="+urllib.quote_plus(href)+"&mode=4"
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumb)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Duration": duration})
	if 'zui' in href:
		liz.setProperty('IsPlayable', 'false')
	else:
		liz.setProperty('IsPlayable', 'true')
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)



def add_dir(name,url,mode,iconimage,query='',type='f',page=0):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&query="+str(query)+"&type="+str(type)+"&page="+str(page)#+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]

	return param

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

params=get_params()

url=''
name=None
mode=None
query=None
type='f'
page=0

try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
try:
	page=int(urllib.unquote_plus(params["page"]))
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "type: "+str(type)
print "page: "+str(page)
print "query: "+str(query)

if mode==None:
	get_categories()
#		fslink_get_video_categories(FSLINK+'/phim-anh.html')

elif mode==1:
	searchMenu(url, '', type, page)

elif mode==2:
	search(url, query, type, page)

elif mode==3:
	clearSearch()

elif mode==4:
	resolve_url(url)
elif mode==5:
	get_htv()
elif mode==6:
	get_fpt()
elif mode==7:
	get_fpt_other('http://play.fpt.vn/the-loai/tvshow')
	#get_fpt_other('http://play.fpt.vn/the-loai/sport')
	#get_fpt_other('http://play.fpt.vn/the-loai/music')
	#get_fpt_other('http://play.fpt.vn/the-loai/general')
elif mode==8:
	get_fpt_tvshow_cat(url)
elif mode==9:
	get_zui(url)
elif mode==10:
	get_vtc(url)
elif mode==11:
	get_vtc_movies(url, query, type, page)
elif mode==13:
	get_hdonline(url)
	 
xbmcplugin.endOfDirectory(int(sys.argv[1]))