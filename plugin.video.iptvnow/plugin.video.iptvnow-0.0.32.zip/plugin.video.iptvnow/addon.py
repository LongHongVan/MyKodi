import sys
import os
import json
import urllib, urllib2
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import load_channels
import hashlib
import re
import time
import base64
import server
import config
import string
import ctypes
from common import *
import traceback,cookielib
import urlresolver, HTMLParser, binascii, linecache
import xbmc,uuid

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 
MyAddonUrlLink = addondir + "MyAddonUrlLink.txt"
MyChannelsList_uktvnow = addondir + "MyChannelsList_uktvnow.txt"
MyChannelsList_uktvnow_sports = addondir + "MyChannelsList_uktvnow_sports.txt"

MyChannelsList_unitv = addondir + "MyChannelsList_unitv.txt"
MyChannelsList_unitv_ret = addondir + "MyChannelsList_unitv_ret.txt"
Mycloudm3ulist = addondir + "Mycloudm3ulist.txt"

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;

xbmcplugin.setContent(addon_handle, 'movies')
addon_id = 'plugin.video.iptvnow'
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.jpg'))
fanart_robot = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'robot.jpg'))
icon_svr = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'serverb.jpg'))
icon_setting = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'setting.jpg'))
usrdata = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.iptvnow/')

AuthSignFile = addondir + "AuthSign.txt"

# +++++++++++++++++++++++Start UniTV 03.28.2016++++++++++++++++++++++++++++++++++
#################################################################################
addon_id = 'plugin.video.iptvnow'
selfAddon = xbmcaddon.Addon(id=addon_id)	
profile_path =  xbmc.translatePath(selfAddon.getAddonInfo('profile'))
#UniTVcats=['Extra Time','TSN','Cth Stadium','UFC','T20 World Cup','Horse Racing','Cricket','Footbal','Sports','Golf','Boxing & Wrestling','T20 Big Bash League','NFL Live','Footbal Clubs','Sports Time']

def getUniTVPage():
    #ShowMessage('getUniTVPage [1]', "Start getUniTVPage..")
    fname='unitvpage.json'
    fname=os.path.join(profile_path, fname)
    try:
        jsondata=getCacheData(fname,4*60*60)
        if not jsondata==None:
            return jsondata
    except:
        print 'file getting error'
        traceback.print_exc(file=sys.stdout)
    #ShowMessage('getUniTVPage [2]', "Done set path for unitvpage.json. fname: ", str(fname)) 
    req = urllib2.Request( base64.b64decode('aHR0cDovL3VuaXZlcnNhbHR2LmRkbnMubmV0L1VuaXZlcnNhbC1UVi1IRC9jbXMvWFZlci9nZXRDb250dFYxLTAucGhw') )      
    req.add_header(base64.b64decode("VXNlci1BZ2VudA=="),base64.b64decode("VW5pdmVyc2FsVFZIRC8xLjAgQ0ZOZXR3b3JrLzc1OC4wLjIgRGFyd2luLzE1LjAuMA==")) 
    req.add_header(base64.b64decode("QXV0aG9yaXphdGlvbg=="),base64.b64decode("QmFzaWMgYWpOMGRtVnljMkZzT21SeVFHY3diakZ2YzBBM09EWT0=")) 
    response = urllib2.urlopen(req)
    link=response.read()
    #ShowMessage('getUniTVPage [2B]', "Done response.read(). link: ", str(link)) 
    import rc
    #from rc import RNCryptor
    #ShowMessage('getUniTVPage [2C]', "Done import rc ")
    cryptor=rc.RNCryptor()
    #ShowMessage('getUniTVPage [2D]', "Done rc.RNCryptor ")
    d=base64.b64decode(link)    
    decrypted_data = cryptor.decrypt(d, base64.b64decode("dGVsYzA5OVBAc3N3b3JkNzg2"))
    #ShowMessage('getUniTVPage [2E]', "Done cryptor.decrypt ")
    decrypted_data=json.loads(decrypted_data)
    dataUrl=decrypted_data[0]["LiveLink"]
    #ShowMessage('getUniTVPage [2F]', "Done decrypted_data. dataUrl: ", str(dataUrl))
    req = urllib2.Request( dataUrl)      
    req.add_header(base64.b64decode("VXNlci1BZ2VudA=="),base64.b64decode("VW5pdmVyc2FsVFZIRC8xLjAgQ0ZOZXR3b3JrLzc1OC4wLjIgRGFyd2luLzE1LjAuMA==")) 
    req.add_header(base64.b64decode("QXV0aG9yaXphdGlvbg=="),base64.b64decode("QmFzaWMgYWpOMGRtVnljMkZzT21SeVFHY3diakZ2YzBBM09EWT0=")) 
    response = urllib2.urlopen(req)
    link=response.read()
    #ShowMessage('getUniTVPage [2G]', "Done response.read link: ", str(link))
    d=base64.b64decode(link)    
    decrypted_data = cryptor.decrypt(d, base64.b64decode("dGVsYzA5OVBAc3N3b3JkNzg2"))
    #print decrypted_data
    jsondata=json.loads(decrypted_data)
    try:
        storeCacheData(jsondata,fname)
    except:
        print 'unitv file saving error'
        traceback.print_exc(file=sys.stdout)
    #ShowMessage('getUniTVPage [3]', "Done getUniTVPage..")
    if selfAddon.getSetting('channellist')=='true': 
		try: SaveList(MyChannelsList_unitv, jsondata)
		except: pass
    return jsondata

def AddUniTVSports(url=None):   

    if url=="sss":
        cats=['Extra Time','TSN','Cth Stadium','UFC','T20 World Cup','Horse Racing','Cricket','Footbal','Sports','Golf','Boxing & Wrestling','T20 Big Bash League','NFL Live','Footbal Clubs','Sports Time']
        isSports=True
        addDir(Colored('>>Click here for All Categories<<'.capitalize(),'red') ,"unitv",66 ,'', False, True,isItFolder=True)
    else:
        cats=[url]
        isSports=False
    for cname,ctype,curl,imgurl in getUniTVChannels(cats,isSports):
        cname=cname.encode('ascii', 'ignore').decode('ascii')
        if ctype=='manual2':
            mm=37
        elif ctype=='manual3':
            mm=45
        else:
            mm=11
        addDir(Colored(cname.capitalize(),'ZM') ,base64.b64encode(curl) ,mm ,imgurl, False, True,isItFolder=False)		#name,url,mode,icon
    return
#UniTVcats=['Extra Time','Cth Stadium','UFC','T20 World Cup','Horse Racing','Cricket','Footbal','Sports','Golf','Boxing & Wrestling','T20 Big Bash League','NFL Live','Footbal Clubs','Sports Time', 'USA Channels', 'TSN']
UniTVcats=['TSN', 'Extra Time', 'Entertainment']
def getUniTVChannels(categories, forSports=True):
    ret=[]
    try:
        xmldata=getUniTVPage()
        ShowMessage('getUniTVChannels [1]', "getUniTVPage" , "xmldata: " + str(xmldata))
        for source in xmldata:#Cricket#
            if source["categoryName"] in categories:
            #if source["categoryName"].strip() in categories or (forSports and ('sport' in source["categoryName"].lower() or 'BarclaysPremierLeague' in source["categoryName"] )    ) :

                ss=source
                cname=ss["channelName"]
                #print cname
                if 'ebound.tv' in ss["channelLink"]:
                    curl='ebound2:'+ss["channelLink"].replace(':1935','')
                else:
                    curl='direct2:'+ss["channelLink"]
                    if ss["channelLink"].startswith('http'): curl+='|User-Agent=AppleCoreMedia/1.0.0.13A452 (iPhone; U; CPU OS 9_0_2 like Mac OS X; en_gb)' 
                cimage=ss["categoryImageLink"]
                
                if len([i for i, x in enumerate(ret) if x[2] ==curl ])==0:                    
                    #print cname
                    ret.append((cname +' v8' ,'manual', curl ,cimage))   
        if len(ret)>0:
            ret=sorted(ret,key=lambda s: s[0].lower()   )
    except:
        traceback.print_exc(file=sys.stdout)
    ShowMessage('getUniTVChannels [2]', "Done getUniTVChannels..ret: ", str(ret))
    if selfAddon.getSetting('channellist')=='true': 
		try: SaveList(MyChannelsList_unitv_ret, ret)
		except: pass
    return ret


# +++++++++++++++++++++++End UniTV 03.28.2016++++++++++++++++++++++++++++++++++
#
#
#######################################################################################

# +++++++++++++++++++++++Start New uktvnow 02.28.2016++++++++++++++++++++++++++++++++++

UKTVGenCategoryAll=['movies', 'religious','news','food', 'entertainment', 'usa ch.', 'documentary', 'sports', 'kids', 'music', 'others']
def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None):
    #ShowMessage('getUrl [1]', "Start..getUrl", "url: " + str(url))
    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    #ShowMessage('getUrl [2]', "Done..req.add_header")
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)

    response = opener.open(req,post,timeout=timeout)
    #ShowMessage('getUrl [3]', "Done..response opener")
    link=response.read()
    response.close()
    #ShowMessage('getUrl [4]', "Done..All getUrl", "return link: " + str(link))
    return link;
    

#DONOTCACHE=   selfAddon.getSetting( "donotcache" ) =="true" 
def storeCacheData(data, fname):
    #if DONOTCACHE: return
    #ShowMessage('storeCacheData [1]', "Start..storeCacheData")
    from time import time
    now=time()
    #ShowMessage('storeCacheData [2]', "Call..now=time()")
    sessiondata=json.loads('{"cache":[{"time":%s}]}'%str(now))
    sessiondata["cache"][0]["data"]=data
    #ShowMessage('storeCacheData [3]', "Set.sessiondata: ", str(sessiondata))
    with open(fname, 'w') as txtfile:
        json.dump(sessiondata, txtfile)
        #ShowMessage('storeCacheData [4]', "json.dump: ", str(sessiondata))
    print 'file saved',fname
    #ShowMessage('storeCacheData [5]', "Done..storeCacheData", "file saved fname: " + fname)
	
def getCacheData(fname, timeout=0):
    #ShowMessage('getCacheData [1]', "Start..getCacheData")
    #if DONOTCACHE: return None
    with open(fname) as data_file:
        data = json.loads(data_file.read())
    #ShowMessage('getCacheData [2]', "Done..json.loads")
    currentime=0
    time_init = float(data["cache"][0]["time"]);
    now=time()
    #ShowMessage('getCacheData [3]', "Done..now=time()")
    # update 12h
    if (now - time_init)>timeout:
        return None
    else:
        print 'returning data'
        return data["cache"][0]["data"]
    #ShowMessage('getCacheData [4]', "Done..getCacheData")
	
def local_time(zone='America/Los_Angeles'):#'Asia/Karachi'):
    #ShowMessage('local_time [1]', "Start local_time")
    from datetime import datetime
    from pytz import timezone
    #ShowMessage('local_time [2]', "import timezone")
    other_zone = timezone(zone)
    other_zone_time = datetime.now(other_zone)
    #ShowMessage('local_time [3]', "Done local_time", "zone_time: " + other_zone_time.strftime('%B-%d-%Y'))
    return other_zone_time.strftime('%B-%d-%Y')
    
	
def getAPIToken( url,  username):
    #ShowMessage('getAPIToken [1]', "Start..getAPIToken")
    print url,username
    #from datetime import datetime, timedelta
    from pytz import timezone
    #ShowMessage('getAPIToken [2]', "import timezone", "url: " + url, "username: " + username)
    dt=local_time()
    #ShowMessage('getAPIToken [3]', "Get..local_time", "local_time: " + str(dt))
    s = "uktvnow-token-"+ dt + "-"+ "_|_-" + url + "-" + username +"-" + "_|_"+ "-"+ base64.b64decode("MTIzNDU2IUAjJCVedWt0dm5vd14lJCNAITY1NDMyMQ==")#123456!@#$%^uktvnow^%$#@!654321
    #ShowMessage('getAPIToken [4]', "Get..uktvnow-token", "Full token code s: " + str(s))
    print s
    import hashlib
    #ShowMessage('getAPIToken [5]', "Done All getAPIToken")
    return hashlib.md5(s).hexdigest()	
    


def getUKTVPage():
    #infoDialog('[COLOR red]**GET getUKTVPage: [/COLOR]', '**Server live.m3u [1]')
    fname='uktvpage.json'
    fname=os.path.join(profile_path, fname)
    #ShowMessage('getUKTVPage [2]', "Start getUKTVPage", "set pathname fname: ", str(fname))
    try:
        jsondata=getCacheData(fname,10*60)
        if not jsondata==None:
            return jsondata
    except:
        #print 'file getting error'
        traceback.print_exc(file=sys.stdout)
	#infoDialog('[COLOR red]**GET getUKTVPage: [/COLOR]', '**Server live.m3u [2]')
    usernames=eval(base64.b64decode("WydTZXJnaW8nLCdEYXNoJywnRnJhemVyJywnWmVkJywnQWxhbicsJ0RvbWluaWMnLCdLZW50JywnSG93YXJkJywnRXJpYycsJ0plbidd"))
    import random
    username = random.choice(usernames)
    post = {'username':username}
    post = urllib.urlencode(post)
    #infoDialog('[COLOR red]**GET getUKTVPage: [/COLOR]', '**Server live.m3u [3]')
    headers=[('User-Agent','USER-AGENT-UKTVNOW-APP-V1'),('app-token',getAPIToken(base64.b64decode("aHR0cDovL2FwcC51a3R2bm93Lm5ldC92MS9nZXRfYWxsX2NoYW5uZWxz"),username))]
    jsondata=getUrl(base64.b64decode("aHR0cDovL2FwcC51a3R2bm93Lm5ldC92MS9nZXRfYWxsX2NoYW5uZWxz"),post=post,headers=headers)#http://app.uktvnow.net/v1/get_all_channels
    jsondata=json.loads(jsondata)
    #infoDialog('[COLOR red]**GET getUKTVPage: [/COLOR]', '**Server live.m3u [4]')
    #ShowMessage('getUKTVPage [4]', "json.loads", "jsondata: ", str(jsondata))
    if selfAddon.getSetting('channellist')=='true': 
		try: SaveList(MyChannelsList_uktvnow, jsondata)
		except: pass
    try:
        if len(jsondata["msg"]["channels"])>0:
			storeCacheData(jsondata,fname)
    except:
        print 'uktv file saving error'
        traceback.print_exc(file=sys.stdout)
    #infoDialog('[COLOR red]**DONE getUKTVPage: [/COLOR]', '**Server live.m3u [5]')
    #ShowMessage('getUKTVPage [5]', "DONE getUKTVPage", "return jsondata: ", str(jsondata))
    #infoDialog('[COLOR aqua]**DONE getUKTVPage: [/COLOR]', '**Server live.m3u [5]')
    return jsondata
	
def addDirUK(name,url,mode,iconimage,showContext=False,showLiveContext=False,isItFolder=True, linkType=None):

	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )

	if showContext==True:
		cmd1 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "DM")
		cmd2 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "LINK")
		cmd3 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "Youtube")
		cmd4 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "PLAYWIRE")
		cmd5 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "EBOUND")
		cmd6 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "PLAYWIRE")
		cmd7 = "XBMC.RunPlugin(%s&linkType=%s)" % (u, "VIDRAIL")

		liz.addContextMenuItems([('Show All Sources',cmd6),('Play Vidrail video',cmd7),('Play Ebound video',cmd5),('Play Playwire video',cmd4),('Play Youtube video',cmd3),('Play DailyMotion video',cmd1),('Play Tune.pk video',cmd2)])
	if linkType:
		u="XBMC.RunPlugin(%s&linkType=%s)" % (u, linkType)
	
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isItFolder)
	return ok
	
def AddUKTVNowChannels(url=None):
    for cname,ctype,curl,imgurl in getUKTVChannels(['sports']):#(['sports']): (By Long Hong)
        cname=cname.encode('ascii', 'ignore').decode('ascii')
        mm=101
#        print repr(curl)
       
        addDirUK(Colored(cname.capitalize(),'ZM') ,base64.b64encode(curl) ,mm ,imgurl, False, True,isItFolder=False)		#name,url,mode,icon
    return

def AddUKTVNowCategory(url=None, uktvcat='sports'):
    #ShowMessage('AddUKTVNowCategory [1]', "Start AddUKTVNowCategory")
    for cname,ctype,curl,imgurl in getUKTVChannels(uktvcat):
        cname=cname.encode('ascii', 'ignore').decode('ascii')
        mm=102
        addDirUK(Colored(cname.capitalize(),'ZM') ,base64.b64encode(curl) ,mm ,imgurl, False, True,isItFolder=False)		#name,url,mode,icon
		#addLink(name,url,mode,iconimage,fanart,description=''):
        #addLink(cname, curl, mm, imgurl,'', '')
    #ShowMessage('AddUKTVNowCategory [2]', "Done AddUKTVNowCategory")
    return

#UKTVGenCategoryAll=['movies', 'religious','news','food', 'entertainment', 'usa ch.', 'documentary', 'sports', 'kids', 'music', 'others']
MyChannelsList_uktvnow_all = addondir + "MyChannelsList_uktvnow_all.txt"
parkistan_ch =["Movies Ok", "Set Max", "Star Gold", "Zee Cinema", "ARY Digital", "ARY News", "ARY QTV", "Ary Zindagi", "Colors", "Express Ent.", 
"PTV Home", "Star Plus", "The Vault", "Zee TV", "92 News HD", "ABP News", "Geo News", "IBN Marathi", "Hum TV", "Sama News", "Sama News 2", "WWOR"]
def getUKTVChannels(categories=[], channels=[]):
    #ShowMessage('getUKTVChannels [1]', "Done AddUKTVNowCategory")
    ret=[]
    try:

        jsondata=getUKTVPage()
        ShowMessage('getUKTVChannels [2]', "jsondata getUKTVPage" + " categories count: ", str(len(categories)))
        EXTM3U = "#EXTM3U\n"
        myhost = "localhost:" + str(selfAddon.getSetting('server_port'))
        myportal = "&tmp=1&portal=1&channel="
        ShowMessage('getUKTVChannels [2]', "jsondata getUKTVPage" + "myhost: ", str(myhost))
        for channel in jsondata["msg"]["channels"]:
            if (channel["cat_name"].strip().lower() in categories or channel["channel_name"].strip().lower() in categories) and (channel["channel_name"] not in parkistan_ch)  :
                    cname=channel["channel_name"]
                    curl='uktvnow:'+channel["pk_id"]
                    pkid=channel["pk_id"]
                    chttp_stream=channel["http_stream"]
                    crtmp_stream=channel["rtmp_stream"]
                    ccat_name=channel["cat_name"]
                    cimage=channel["img"]
                    if not cimage.startswith("http"):
                        cimage='https://app.uktvnow.net/'+cimage
                    if cname==None: cname=curl
                    if cname=="E": cname="E! entertainment"
                    if cname=="ITV": cname="ITV1"
                    if cname=="ITV+": cname="ITV +1"
                    if len([i for i, x in enumerate(ret) if x[2] ==curl  ])==0:                    
                        ret.append(("tvg-id=" + pkid, "tvg-logo=" + cimage, "group-title=" + ccat_name, "tvg-name=" + cname, "http_stream=" + chttp_stream.split('?')[0]))
                        #ret.append((cname +' uktv' ,'manual', curl ,cimage))
                        EXTM3U += '#EXTINF:-1, tvg-id="' + curl + '" tvg-name="' + cname.replace("TNT HD", "TNT").replace("TBS HD", "TBS").replace("USA-Network", "USA Network").replace("Fox HD", "Fox").replace("AMC HD", "AMC").replace("Bravo HD", "Bravo").replace("NBC", "NBC New York").replace("NBC New York HD", "NBC New York") + '" tvg-logo="' + cimage.replace("https://", "") + '" group-title="' + ccat_name + '", ' + cname.replace("Sky Movies", "Sky").replace("Crime", "Thriller").replace("Scifi", "Horror").replace("Disnep", "Disney").replace("Film 4", "Film4").replace("SkySports", "Sky Sports").replace("Sports Net World", "Sportsnet World HD").replace("Arena Sport", "Arenasport").replace("Super Sports", "SuperSport").replace("the races", "The Races").replace("Bein Sports 11", "bein-sports-11hd").replace("Bein Sports 10", "bein-sports-10hd").replace("Bein Sports 2", "bein-sports-2hd").replace("Bein Sports 3", "bein-sports-3hd").replace("Bein Sports 4", "bein-sports-4hd").replace("Bein Sports 5", "bein-sports-5hd").replace("Bein Sports 6", "bein-sports-6hd").replace("Bein Sports 7", "bein-sports-7hd").replace("Bein Sports 8", "bein-sports-8hd").replace("Bein Sports 9", "bein-sports-9hd").replace("Bein Sports 1", "bein-sports-1hd").replace("Bein Sports USA", "bein-sports").replace("ESPN", "ESPNU").replace("ESPNU 2", "ESPN2").replace("Espn HD", "ESPN").replace("Euro Sport", "Eurosport").replace("Golf Channel", "The Golf Channel").replace("LFC TV", "lfctv").replace("MU TV", "MUTV").replace("Premier Sports", "Premier Sports HD").replace("Sky Sports News", "Sky Spts News").replace("Bt sports", "BT Sport").replace("Astro SuperSport 1", "Astro SuperSport").replace("Quest", "QUEST").replace("Sky 1", "Sky1").replace("Sky 2", "Sky2").replace("Sony TV", "Sony Movie Channel").replace("TG 4", "TG4").replace("Travel", "Travel Channel").replace("UK Gold", "Gold").replace("BBC Three", "BBC THREE").replace("BBC Four", "BBC FOUR").replace("Dmax", "DMAX").replace("A&E", "A and E").replace("ABC HD", "ABC Miami").replace("Animal Planet.", "Animal Planet").replace("CBS HD", "CBS New York").replace("CNN.", "CNN").replace("Discovery.", "Discovery Channel").replace("Food Network.", "Food Network HD").replace("FX.", "FX").replace("Fox News", "FOX News").replace("H2", "H2USA").replace("History HD", "HISTORY").replace("MTV.", "MTV MUSIC").replace("Nat Geo.", "National Geographic Channel HD").replace("NBC", "NBC New York").replace("Nick.", "Nickelodeon").replace("Cartoon Network.", "Cartoon Network").replace("ESPNU News", "ESPNEWS").replace("Discovery Investigation", "ID").replace("Nat Geo HD", "National Geographic Channel HD").replace("History", "HISTORY").replace("Discovery HISTORY", "Discovery History").replace("True Movies 1", "True Movies").replace("USA Network", "USA Network HD" ).replace("USA-Network", "USA Network").replace("Comedy Central.", "Comedy Central") + '\n'
                        EXTM3U += 'http://' + myhost + '/uktvnow.m3u?' + '&pkid=' + pkid + myportal + chttp_stream.split('?')[0] + "?" +'\n\n';
						
        if len(ret)>0:
            ret=sorted(ret,key=lambda s: s[0].lower() )                        
    except:
        traceback.print_exc(file=sys.stdout)
    ShowMessage('getUKTVChannels [3]', "Done getUKTVChannels ret: ", str(ret))
    if selfAddon.getSetting('iptv_server')=='true': 
		#MyChannelsList_uktvnow_cat = addondir + "MyChannelsList_uktvnow_" + str(categories) + ".txt"
		if len(categories)==1: MyUktvM3uFile = "C:\Users\Long\MediaFire\TV-Guide\MyUktvM3uFile" + "_" + categories[0] + ".m3u"
		else: MyUktvM3uFile = "C:\Users\Long\MediaFire\TV-Guide\MyUktvM3uFile.m3u"
		try: 
			write_file(MyUktvM3uFile, EXTM3U)
			ShowMessage('getUKTVChannels [4]', "MyUktvM3uFile: " + str(MyUktvM3uFile), "categories: " + categories[0], "MyUktvM3uFile: " + str(EXTM3U))
		except: pass
    return ret

stream_select = int(selfAddon.getSetting('link_select'))
def PlayUKTVNowChannels(url):
    #ShowMessage('PlayUKTVNowChannels [1]', "Start getUKTVPage", "set pathname fname: ", str(stream_select))
    jsondata=getUKTVPage()
    #ShowMessage('PlayUKTVNowChannels [2]', "Done getUKTVPage", "set pathname fname: ", str(jsondata))
    #infoDialog('Start PlayUKTVNowChannels', 'PlayUKTVNowChannels [1]')
    cc=[item for item in jsondata["msg"]["channels"]
            if item["pk_id"]== url]
                
    #listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ) )
    #played=False
    try:
        #import uktvplayer
        if stream_select==1:
			stream_url=cc[0]["http_stream"].split('|')[0]# Long Hong Added
        else:
			stream_url=cc[0]["rtmp_stream"].split('|')[0]         
    except: pass
    #ShowMessage('PlayUKTVNowChannels [1]', "Done PlayUKTVNowCh - return stream_url:", str(stream_url))
    #infoDialog('Done stream_url: ' + str(stream_url), 'PlayUKTVNowChannels [2]')
    return stream_url


def get_uktv_authcode():
	infoDialog(Colored('Start get_uktv_authcode', 'blue'), 'get_uktv_authcode [1]')
	try:
		GetMyAuthSign = PlayUKTVNowChannels("99")
		write_file(AuthSignFile, str(GetMyAuthSign))
	except: pass
	infoDialog(Colored('Done get_uktv_authcode', 'lime'), 'get_uktv_authcode [2]')

# +++++++++++++++++++++++End New uktvnow 02.28.2016++++++++++++++++++++++++++++++++++
#####################################################################################



def Main():
	#addDir('[COLOR darkorange]          *** TEAM DNA PRESENTS DNA TV ***[/COLOR]','',0,icon, fanart)
	#addDir('[COLOR darkorange]ENTER DNA TV GUIDE[/COLOR]','0',1001,icon, fanart)
	#addDir('[COLOR darkred][I]###--Maintenance Tools--###[/I][/COLOR]','',0,icon, fanart)
	addDir('[COLOR lime]Start Server [/COLOR]','0',1004,icon_svr, fanart_robot)
	addDir('[COLOR aqua]Open Settings [/COLOR]','0',1005,icon_setting, fanart_robot)
	#addDir('[COLOR blue]Clear IPTV Now Cache[/COLOR]','0',1002,icon, fanart)
	addDir('[COLOR blue]Clear Kodi Cache[/COLOR]','0',1003,icon, fanart)
	#addDir('[COLOR lime]UKTV Movies[/COLOR]','0',1006,icon, fanart)
	#addDir('[COLOR deeppink]Get Top Cloud USA Channels..[/COLOR]','0',1012,icon, fanart)
	#addDir('[COLOR aqua]get UKTV Channels All Group[/COLOR]','0',1008,icon, fanart)
	#addDir('[COLOR aqua]get UKTV Channels 1 group channel[/COLOR]','0',1009,icon, fanart)
	#addDir('[COLOR lime]get UNITV Channels[/COLOR]','0',1010,icon, fanart)
	#addDir('[COLOR blue]get UNITV Page - create Ch list[/COLOR]','0',1011,icon, fanart)#find_subdir
	#addDir('[COLOR green]Test - find_subdir[/COLOR]','0',1012,icon, fanart)#find_subdir
	xbmc.executebuiltin('Container.SetViewMode(50)')
	

def dnatvguide():
	xbmc.executebuiltin("RunAddon(script.dnatvguide)")
	
	
def CacheDel():
	if not os.path.exists(usrdata):
		dialog.ok(addonname, 'There is no userdata present for DNA TV')
		addDir('[COLOR yellow]*** DNA TV Cache Cleared ***[/COLOR]','0',0,icon,'',fanart)
		xbmc.executebuiltin('Container.SetViewMode(50)')
		
	if os.path.exists(usrdata):
		shutil.rmtree(usrdata)
		addDir('[COLOR yellow]*** DNA TV Cache Cleared ***[/COLOR]','0',0,icon,'',fanart)
		xbmc.executebuiltin('Container.SetViewMode(50)')


def DeleteCache(url):
    print '###DELETING KODI CACHE###'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete KODI Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
    
	addDir('[COLOR yellow]*** KODI Cache Cleared ***[/COLOR]','0',0,icon,'',fanart)
	xbmc.executebuiltin('Container.SetViewMode(50)')
	
		
def addLink(name,url,mode,iconimage,fanart,description=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		
def addDir(name,url,mode,iconimage,fanart,description=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)

def mysvr_start():
	port = addon.getSetting('server_port');
	ActiveMac = config.configMac('1');	
	dp = xbmcgui.DialogProgressBG();
	dp.create('IPTV Server', 'Working ... ActiveMac ' + str(ActiveMac));
	
	if server.serverOnline():
			xbmcgui.Dialog().notification(addonname, 'Server already started. Will stop server in moment.', xbmcgui.NOTIFICATION_INFO );
			time.sleep(1);
			server.stopServer();
			time.sleep(3);
			dpb = xbmcgui.DialogProgressBG();
			dpb.create('IPTV Server', 'Restarting..Mac: ' + str(ActiveMac));
			time.sleep(1);			
			server.startServer();
			time.sleep(3);
			
			if server.serverOnline():
				xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
				dpb.close();
				#return True;
			else:
				xbmcgui.Dialog().notification(addonname, 'Server not started. Wait one moment and try again. ', xbmcgui.NOTIFICATION_ERROR );
				time.sleep(1);
				#return False;
				
	else:	
			server.startServer();
			time.sleep(5);
			if server.serverOnline():
				xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
				#return True;
			else:
				xbmcgui.Dialog().notification(addonname, 'Server not started. Wait one moment and try again. ', xbmcgui.NOTIFICATION_ERROR );
				#return False;
				
	
	dp.close();	
	#time.sleep(2);
	Main();
	#homeLevel();
	xbmcplugin.endOfDirectory(addon_handle);
	#return server.serverOnline();
	#xbmc.executebuiltin('Container.SetViewMode(50)');				

def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				e4=sys.argv[2]
				cleanedparams=e4.replace('?','')
				if (e4[len(e4)-1]=='/'):
						e4=e4[0:len(e4)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]	
		return param
		   
e4=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:url=urllib.unquote_plus(e4["url"])
except:pass
try:name=urllib.unquote_plus(e4["name"])
except:pass
try:mode=int(e4["mode"])
except:pass
try:iconimage=urllib.unquote_plus(e4["iconimage"])
except:pass		
	
		
if mode==None or url==None or len(url)<1:Main()
elif mode==1001:dnatvguide()
elif mode==1002:CacheDel()
elif mode==1003:DeleteCache(url)
elif mode==1004:
	mysvr_start()
elif mode==1005: # DoA("start")
	showAddonSettings()
elif mode==1006:
	AddUKTVNowChannels(url)

elif mode==1007:
	get_uktv_authcode()
	Main()

elif mode==1008:
	getUKTVChannels(UKTVGenCategoryAll)
	Main()
#UKTVGenCategoryAll=['movies', 'religious','news','food', 'entertainment', 'usa ch.', 'documentary', 'sports', 'kids', 'music', 'others']	
elif mode==1009:
	getUKTVChannels(['entertainment'])# single proup ch.
	Main()
	
elif mode==1010:
	getUniTVChannels(UniTVcats)# single proup ch.
	Main()

elif mode==1011:#
	getUniTVPage()# single proup ch.
	Main()



elif mode==1012:# Test Import File #('C:\\Users\Long\AppData\Roaming\Kodi\addons\plugin.video.ccloudtv\default.py')
    from import_file import import_file
    mylibpath = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ccloudtv/default.py'))
    if not os.path.isfile(mylibpath):
        ShowMessage('TEST', 'unable to find mylibpath - reault: ', mylibpath)
        #break
    else:
		mycloud = import_file(mylibpath)
    mycloud.msg('test', "done import_file: ", mylibpath)
    mym3ulist = mycloud.make_request()
    mycloud.msg('test', 'done GetHttpStatusAndData:', str(mym3ulist))
    AandECh = 'bb38d9048b7b91706264169a031f32a4.m3u8'
    m3u_regex = '#(.+?),(.+)\s*(.+)\s*'
    m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
    group_regex = 'group-title=[\'"](.*?)[\'"]'
    tvgname_regex = 'tvg-name=[\'"](.*?)[\'"]'
    try:
		#searchText = '(Top10)'
		if len(mym3ulist) > 0:		
			match = re.compile(m3u_regex).findall(mym3ulist)
			#ShowMessage('Get Ch match', 'match :', str(match))
			mychlist = ''
			#mychlist = '#EXTM3U' + '\n\n'
			ccount = 0
			for thumb, name, url in match:
			#if re.search(AandECh, match, re.IGNORECASE):
				name = re.sub('\s+', ' ', name).strip()
				#logo = thumb = re.compile(logo_regex).findall(str(logo))[0].replace(' ', '%20')
				url = url.replace('"', ' ').replace('&amp;', '&').strip()
				if 'tvg-logo' in thumb:
					thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
				#if ('http://167.114.102.27/live/' in url) and ('Top10' in name or 'Spike TV' in name or 'Lifetime' in name or 'Animal Planet' in name or 'USA Network' in name or 'Fx' in name or 'Fox' in name):
				if 'bb38d9048b7b91706264169a031f32a4.m3u8' in url:
					namex = name.replace(' (Top10) (US) (English)', "").replace('History', "HISTORY").replace('National Geographic Channel', "National Geographic Channel HD").replace(' (Entertainment) (US) (English)', "").replace('Fx', "FX").replace(' (Documentary) (US) (English)', "").replace(' (Family) (US) (English)', "").replace(' (News) (US) (English)', "").replace(' (Movie Channels) (US) (English)', "").replace('Fox', "FOX")
					mychlist += '\n' + '#EXTINF:0 ' + 'tvg-name="' + namex + '" '  + 'group-title="Top Cloud USA TV" ' + 'tvg-logo="' + thumb.replace('http://', "").replace('https://', "") + '", ' + namex + '\n' + url + '\n'
					ccount += 1
					mychlist_url = url				
    except:
		pass
    write_file(Mycloudm3ulist, mychlist_url)
	#write_file(Mycloudm3ulist, mychlist)
    ShowMessage('write_file', '[COLOR lime]Done![/COLOR]' , 'Wrote ' + str(ccount) + ' channel(s)')
    Main()







def addPortal(portal):

	if portal['url'] == '':
		return;

	url = build_url({
		'mode': 'genres', 
		'portal' : json.dumps(portal)
		});
	
	cmd = 'XBMC.RunPlugin(' + base_url + '?mode=cache&stalker_url=' + portal['url'] + ')';	
	
	li = xbmcgui.ListItem(portal['name'], iconImage='DefaultProgram.png')
	li.addContextMenuItems([ ('Clear Cache', cmd) ]);

	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
	#infoDialog('Done', 'addPortal')
	
	
def build_url(query):
	return base_url + '?' + urllib.urlencode(query)
	#infoDialog('Done', 'build_url')


def homeLevel():
	global portal_1, portal_2, portal_3, go;
	
	#todo - check none portal

	if go:
		addPortal(portal_1);
#		addPortal(portal_2);
#		addPortal(portal_3);
	
		xbmcplugin.endOfDirectory(addon_handle);

def genreLevel():
	
	try:
		data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		
		return;

	data = data['genres'];
		
	url = build_url({
		'mode': 'vod', 
		'portal' : json.dumps(portal)
	});
			
	li = xbmcgui.ListItem('VoD', iconImage='DefaultVideo.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
	
	
	for id, i in data.iteritems():

		title 	= i["title"];
		
		url = build_url({
			'mode': 'channels', 
			'genre_id': id, 
			'genre_name': title.title(), 
			'portal' : json.dumps(portal)
			});
			
		if id == '10':
			iconImage = 'OverlayLocked.png';
		else:
			iconImage = 'DefaultVideo.png';
			
		li = xbmcgui.ListItem(title.title(), iconImage=iconImage)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
		

	xbmcplugin.endOfDirectory(addon_handle);
	#infoDialog('Done', 'genreLevel')

def vodLevel():
	
	try:
		data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;
	
	
	data = data['vod'];
	
		
	for i in data:
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		
		
		if logo != '':
			logo_url = portal['url'] + logo;
		else:
			logo_url = 'DefaultVideo.png';
				
				
		url = build_url({
				'mode': 'play', 
				'cmd': cmd, 
				'tmp' : '0', 
				'title' : name.encode("utf-8"),
				'genre_name' : 'VoD',
				'logo_url' : logo_url, 
				'portal' : json.dumps(portal)
				});
			

		li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url)
		li.setInfo(type='Video', infoLabels={ "Title": name })

		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.endOfDirectory(addon_handle);
	#infoDialog('Done', 'vodLevel')

def channelLevel():
	stop=False;
	#infoDialog('Start loading...', 'channel Level', time=2000)	
	try:
		data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir);
		
	except Exception as e:
#		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		genrepain()
		return;
	
	
	data = data['channels'];
	genre_name 	= args.get('genre_name', None);
	
	genre_id_main = args.get('genre_id', None);
	genre_id_main = genre_id_main[0];
	
	if genre_id_main == '10' and portal['parental'] == 'true':
		result = xbmcgui.Dialog().input('Parental', hashlib.md5(portal['password'].encode('utf-8')).hexdigest(), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY);
		if result == '':
			stop = True;

	
	if stop == False:
		for i in data.values():
			
			name 		= i["name"];
			cmd 		= i["cmd"];
			tmp 		= i["tmp"];
			number 		= i["number"];
			genre_id 	= i["genre_id"];
			logo 		= i["logo"];
		
			if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
				continue;
		
		
			if genre_id_main == genre_id or genre_id_main == '*':
		
				if logo != '':
					logo_url = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
				else:
					logo_url = 'DefaultVideo.png';
				
				
				url = build_url({
					'mode': 'play', 
					'cmd': cmd, 
					'tmp' : tmp, 
					'title' : name.encode("utf-8"),
					'genre_name' : genre_name,
					'logo_url' : logo_url,  
					'portal' : json.dumps(portal)
					});
			

				li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url);
				li.setInfo(type='Video', infoLabels={ 
					'title': name,
					'count' : number
					});

				xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li);
		
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);
		
		
		xbmcplugin.endOfDirectory(addon_handle);
		#infoDialog('[COLOR lime]All Done![/COLOR]', 'channelLevel', time=2000)
		
def pain():
	__addon__ = xbmcaddon.Addon()
	__addonname__ = __addon__.getAddonInfo('name')
 
	line1 = "Server Overloaded"
	line2 = "Please try again..."
 
	xbmcgui.Dialog().ok(__addonname__, line1, line2)
	

def genrepain():
	__addon__ = xbmcaddon.Addon()
	__addonname__ = __addon__.getAddonInfo('name')
 
	line1 = "If the channels don't load on first attempt,"
	line2 = "Please clear your DNA TV cache and try a few more times..."
 
	xbmcgui.Dialog().ok(__addonname__, line1, line2)
	
	
		
def playLevel():
	#infoDialog('Start', 'playLevel', time=1000)
	dp = xbmcgui.DialogProgressBG();
	dp.create('Channel', 'Loading ' + str(portal['mac']));
	
	title 	= args['title'][0];
	cmd 	= args['cmd'][0];
	tmp 	= args['tmp'][0];
	genre_name 	= args['genre_name'][0];
	logo_url 	= args['logo_url'][0];
	
	try:
		if genre_name != 'VoD':
			url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], cmd, tmp);
		else:
			url = load_channels.retriveVoD(portal['mac'], portal['url'], portal['serial'], cmd);

	
	except Exception as e:
		dp.close();
		pain()
#		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;

	
	dp.update(80);
	
	title = title.decode("utf-8");
	
	title += ' (' + portal['name'] + ')';
	
#	li = xbmcgui.ListItem(title, iconImage=logo_url); <modified 9.0.19
	li = xbmcgui.ListItem(title, iconImage='DefaultVideo.png', thumbnailImage=logo_url);
	li.setInfo('video', {'Title': title, 'Genre': genre_name});
	#infoDialog('url: '+ str(url), 'playLevel', time=1000)
	time.sleep(1)
	#infoDialog('url: '+ str(url), 'playLevel', time=1000)
	xbmc.Player().play(item=url, listitem=li);
	
	dp.update(100);
	
	dp.close();
	#infoDialog('[COLOR lime]Done![/COLOR]', 'playLevel')


	
	
def auto_run():
	port = addon.getSetting('server_port');
	ActiveMac = config.configMac('1');	
	ActiveDelay = addon.getSetting('server_delay');
	ActiveRepeat = addon.getSetting('server_repeat');
	action =  args.get('action', None);
	action = action[0];
	dp = xbmcgui.DialogProgressBG();
	dp.create('IPTV Server', 'Working ... ActiveMac ' + str(ActiveMac));
	
	if action == 'start':
	  for x in range(0, int(ActiveRepeat)):
		if server.serverOnline():
			xbmcgui.Dialog().notification(addonname, 'Server already started. Will stop server in moment.\nPort: ' + str(port) + ' Sever has been started in ' + str(x * int(ActiveDelay)) + ' Seconds ', xbmcgui.NOTIFICATION_INFO );
			time.sleep(1);
			server.stopServer();
			time.sleep(1);
					
			#ActiveMac = config.configMac('3');
			dpb = xbmcgui.DialogProgressBG();
			dpb.create('IPTV Server', 'Restarting... Index ['  + str(x + 1)  + '] ActiveMac ' + str(ActiveMac));
			time.sleep(1);			
			
			server.startServer();
			time.sleep(1);
			
			if server.serverOnline():
			 xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port) + ' - ' + str(x + 1) + ' times.', xbmcgui.NOTIFICATION_INFO );
			 time.sleep(int(ActiveDelay));
			 dpb.close();
			else:
			 xbmcgui.Dialog().notification(addonname, 'Server not started. Wait one moment and try again. ', xbmcgui.NOTIFICATION_ERROR );
			 time.sleep(5);
		else:
			server.startServer();
			time.sleep(5);
			if server.serverOnline():
				xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
			else:
				xbmcgui.Dialog().notification(addonname, 'Server not started. Wait one moment and try again. ', xbmcgui.NOTIFICATION_ERROR );
				
	else: # action == 'stop':
		if server.serverOnline():
			server.stopServer();
			time.sleep(5);
			xbmcgui.Dialog().notification(addonname, 'Server stopped.', xbmcgui.NOTIFICATION_INFO );
		else:
			xbmcgui.Dialog().notification(addonname, 'Server is already stopped.', xbmcgui.NOTIFICATION_INFO );
	
	dp.close();	
	
	
	
	

mode = args.get('mode', None);
portal =  args.get('portal', None)


if portal is None:
	portal_1 = config.portalConfig('1');
	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

else:
	portal = json.loads(portal[0]);

#  Modification to force outside call to portal_1 (9.0.19)

	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

	if not ( portal['name'] == portal_2['name'] or portal['name'] == portal_3['name'] ) :
		portal = config.portalConfig('1');

	

if mode is None:
	homeLevel();

elif mode[0] == 'cache':	
	stalker_url = args.get('stalker_url', None);
	stalker_url = stalker_url[0];	
	load_channels.clearCache(stalker_url, addondir);

elif mode[0] == 'genres':
	genreLevel();
		
elif mode[0] == 'vod':
	vodLevel();

elif mode[0] == 'channels':
	channelLevel();
	
elif mode[0] == 'play':
	playLevel();
	
elif mode[0] == 'server':
	auto_run();



#addon_id = 'cGx1Z2luLnZpZGVvLmRuYXR2'.decode('base64')#plugin.video.dnatv (original)
data_folder = 'special://userdata/addon_data/'
Url= 'https://raw.githubusercontent.com/macblizzard/dnarepo/master/plugin.video.dnatv/userdata/'
File = ['http_nfps_stalkerclone_network', 'http_nfps_stalkerclone_network-genres']

def download(url, dest, dp = None):
    if not dp:
        dp = xbmcgui.DialogProgress()
#        dp.create("Loading")
#    dp.update(0)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url, dp):
    try:
       
        dp.update
    except:
        
        dp.update(percent)

for file in File:
	url = Url + file
	fix = xbmc.translatePath(os.path.join( data_folder, file))
	download(url, fix)
	
