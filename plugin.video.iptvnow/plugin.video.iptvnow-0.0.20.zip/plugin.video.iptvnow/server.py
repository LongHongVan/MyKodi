import sys
import json
import urllib
import urllib2
from urlparse import urlparse, parse_qs
import load_channels
import SocketServer
import socket
import SimpleHTTPServer
import string,cgi,time
from os import curdir, sep
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import config
import re
import threading
from common import *
import traceback,cookielib
import urlresolver, HTMLParser, base64, binascii
from import_file import import_file
import random
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 
MyServerUrlLink = addondir + "MyServerUrlLink.txt"

portals = None;
server = None;

UKTVGenCategoryAll=['movies', 'religious','news','food', 'entertainment', 'usa Ch.', 'documentary', 'sports', 'kids', 'music', 'others']
def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None):
    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)

    response = opener.open(req,post,timeout=timeout)
    link=response.read()
    response.close()
    return link;
    

#DONOTCACHE=   selfAddon.getSetting( "donotcache" ) =="true" 
def storeCacheData(data, fname):
    from time import time
    now=time()
    sessiondata=json.loads('{"cache":[{"time":%s}]}'%str(now))
    sessiondata["cache"][0]["data"]=data
    with open(fname, 'w') as txtfile:
        json.dump(sessiondata, txtfile)
    print 'file saved',fname

def getCacheData(fname, timeout=0):
    with open(fname) as data_file:
        data = json.loads(data_file.read())
    currentime=0
    time_init = float(data["cache"][0]["time"]);
    now=time()
    if (now - time_init)>timeout:
        return None
    else:
        print 'returning data'
        return data["cache"][0]["data"]

def local_time(zone='Asia/Karachi'):
    from datetime import datetime
    from pytz import timezone
    other_zone = timezone(zone)
    other_zone_time = datetime.now(other_zone)
    return other_zone_time.strftime('%B-%d-%Y')
    
	
def getAPIToken( url,  username):
    print url,username
    from pytz import timezone
    dt=local_time()
    s = "uktvnow-token-"+ dt + "-"+ "_|_-" + url + "-" + username +"-" + "_|_"+ "-"+ base64.b64decode("MTIzNDU2IUAjJCVedWt0dm5vd14lJCNAITY1NDMyMQ==")
    print s
    import hashlib
    return hashlib.md5(s).hexdigest()	
    

addon_id = 'plugin.video.iptvnow'
selfAddon = xbmcaddon.Addon(id=addon_id)	
profile_path =  xbmc.translatePath(selfAddon.getAddonInfo('profile'))
def getUKTVPage():
    fname='uktvpage.json'
    fname=os.path.join(profile_path, fname)
    try:
        jsondata=getCacheData(fname,10*60)
        if not jsondata==None:
            return jsondata
    except:
        traceback.print_exc(file=sys.stdout)
    usernames=eval(base64.b64decode("WydTZXJnaW8nLCdEYXNoJywnRnJhemVyJywnWmVkJywnQWxhbicsJ0RvbWluaWMnLCdLZW50JywnSG93YXJkJywnRXJpYycsJ0plbidd"))
    import random
    username = random.choice(usernames)
    post = {'username':username}
    post = urllib.urlencode(post)
    headers=[('User-Agent','USER-AGENT-UKTVNOW-APP-V1'),('app-token',getAPIToken(base64.b64decode("aHR0cDovL2FwcC51a3R2bm93Lm5ldC92MS9nZXRfYWxsX2NoYW5uZWxz"),username))]
    jsondata=getUrl(base64.b64decode("aHR0cDovL2FwcC51a3R2bm93Lm5ldC92MS9nZXRfYWxsX2NoYW5uZWxz"),post=post,headers=headers)#http://app.uktvnow.net/v1/get_all_channels
    jsondata=json.loads(jsondata)
    try:
        if len(jsondata["msg"]["channels"])>0:
			storeCacheData(jsondata,fname)
    except:
        print 'uktv file saving error'
        traceback.print_exc(file=sys.stdout)
    return jsondata

stream_select = int(selfAddon.getSetting('link_select'))
def PlayUKTVNowChannels(url):
    jsondata=getUKTVPage()
    cc=[item for item in jsondata["msg"]["channels"]
            if item["pk_id"]== url]                
    try:
        if stream_select==1:
			stream_url=cc[0]["http_stream"].split('|')[0]# Long Hong Added
        else:
			stream_url=cc[0]["rtmp_stream"].split('|')[0]         
    except: pass
    infoDialog('Done get stream_url: ' + str(stream_url), 'PlayUKTVNowChannels [2]')
    return stream_url

# F4M Proxy - .ts Links
def playF4mLink(url,name,proxy=None,use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth_string=None,streamtype='HDS',setResolved=False,swf=""):
    from resources.lib.F4mProxy import f4mProxyHelper
    player=f4mProxyHelper()
    if setResolved:
        urltoplay,item=player.playF4mLink(url, name, proxy, use_proxy_for_chunks,maxbitrate,simpleDownloader,auth_string,streamtype,setResolved,swf)
    else: urltoplay = url   
    return urltoplay

def get_uktv_authcode():
	try:
		GetMyAuthSign = PlayUKTVNowChannels("99")
		write_file(AuthSignFile, str(GetMyAuthSign))
	except: pass

class TimeoutError(RuntimeError):
    pass

class AsyncCall(object):
    def __init__(self, fnc, callback = None):
        self.Callable = fnc
        self.Callback = callback

    def __call__(self, *args, **kwargs):
        self.Thread = threading.Thread(target = self.run, name = self.Callable.__name__, args = args, kwargs = kwargs)
        self.Thread.start()
        return self

    def wait(self, timeout = None):
        self.Thread.join(timeout)
        if self.Thread.isAlive():
            raise TimeoutError()
        else:
            return self.Result

    def run(self, *args, **kwargs):
        self.Result = self.Callable(*args, **kwargs)
        if self.Callback:
            self.Callback(self.Result)

class AsyncMethod(object):
    def __init__(self, fnc, callback=None):
        self.Callable = fnc
        self.Callback = callback

    def __call__(self, *args, **kwargs):
        return AsyncCall(self.Callable, self.Callback)(*args, **kwargs)

def Async(fnc = None, callback = None):
    if fnc == None:
        def AddAsyncCallback(fnc):
            return AsyncMethod(fnc, callback)
        return AddAsyncCallback
    else:
        return AsyncMethod(fnc, callback)

def GetClientIP():# not working yet!
	#clientIP = '';
	try:
		s = socket.socket( socket.AF_INET, socket.SOCK_STREAM );
		s.bind( (HOST, PORT) );
		s.listen(1);
		conn, addr = s.accept();
		clientIP = addr;
		s.close();
		return clientIP
	except: pass
	
AuthSignFile = addondir + "AuthSign.txt"
client_ipaddr_log = addondir + "client_ipaddr.txt"
upcode = ['AsQ1HmDb/QzTnMq3G/', 'yfbCjFjE/scg56P9B/'] #'Cmb9Hf5J/gKUMZkBN/'
MainHost = 'http://185.115.32.12:8000/live/'
MyDTCode = MainHost + random.choice(upcode)
MyIptvSubsCodetv = 'http://2.welcm.tv:8000/live/thuyvo174@gmail.com/voo_174/'
MyIptvSubsCodevod = 'http://2.welcm.tv:8000/movie/thuyvo174@gmail.com/voo_174/'
class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        global portals, server;
        from time import gmtime, strftime, altzone
        mydebug = selfAddon.getSetting('debug_message')
        if mydebug =="true":
			try:
				client_ipaddr = self.address_string()
				infoDialog('Client-IP: ' + str(client_ipaddr), 'Server do_GET')
				timestamp = strftime("%Y-%m-%d %H:%M:%S", gmtime())
				#now_pacific = now_utc.astimezone(timezone('US/Pacific'))
				writeappend_file(client_ipaddr_log, 'GM Time ' + timestamp + ' ' + client_ipaddr)
			except: pass
        
        infoDialog('Start process IPTV Server...', 'BaseHTTPRequestHandler')
                
        try:
            if re.match('.*channels-([0-9])\..*|.*channels\..*\?portal=([0-9])', self.path):

            	host = self.headers.get('Host');
                infoDialog('M3U for IPTV Simple Clients on start up: ' + str(host), 'Server do_GET 2', time=1000);


            	searchObj = re.search('.*channels-([0-9])\..*|.*channels\..*\?portal=([0-9])', self.path);
            	if searchObj.group(1) != None:
            		numportal = searchObj.group(1);
            	elif searchObj.group(2) != None:
            		numportal = searchObj.group(2);
            	else:
            		self.send_error(400,'Bad Request');
            		return;
            	

            	portal = portals[numportal];
            	
            	EXTM3U = "#EXTM3U\n";
            	
            	try:

					data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir);
					data = load_channels.orderChannels(data['channels'].values());

					for i in data:
						name 		= i["name"];
						cmd 		= i["cmd"];
						tmp 		= i["tmp"];
						number 		= i["number"];
						genre_title = i["genre_title"];
						genre_id 	= i["genre_id"];
						logo 		= i["logo"];

						if logo != '':
							#logo = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
							# LHong Fixed Logo for PVR IPTV Simple
							logox = portal['url'].replace("http://", "");
							logo = logox + '/stalker_portal/misc/logos/320/' + logo;
				
					
						parameters = urllib.urlencode( { 'channel' : cmd, 'tmp' : tmp, 'portal' : numportal } );
					
						EXTM3U += '#EXTINF:-1, tvg-id="' + number + '" tvg-name="' + name + '" tvg-logo="' + logo + '" group-title="' + genre_title + '", ' + name + '\n';
						EXTM3U += 'http://' + host + '/live.m3u?'  + parameters +'\n\n';
					
            	except Exception as e:
						EXTM3U += '#EXTINF:-1, tvg-id="Error" tvg-name="Error" tvg-logo="" group-title="Error", ' + portal['name'] + ' ' + str(e) + '\n';
						EXTM3U += 'http://\n\n';
        	
        	
                self.send_response(200)
                self.send_header('Content-type',	'application/x-mpegURL')
                #self.send_header('Content-type',	'text/html')
                self.send_header('Connection',	'close')
                self.send_header('Content-Length', len(EXTM3U))
                self.end_headers()
                self.wfile.write(EXTM3U.encode('utf-8'))
                self.finish()
                
            elif 'live.m3u' in self.path:
				args = parse_qs(urlparse(self.path).query);
				infoDialog('args: ' + str(args), 'Server live.m3u 2');
				cmd = args['channel'][0];
				tmp = args['tmp'][0];
				numportal = args['portal'][0];
				#infoDialog('***cmd: ' + str(cmd) + ' numportal: ' + str(numportal), 'Server live.m3u 3', time=1000);
				portal = portals[numportal];
				#infoDialog('portal: ' + str(portal), 'Server live.m3u 4', time=1000);
				url = load_channels.retrive_defaultUrl(portal['url'], cmd, tmp)
				#if tmp == '0': url = cmd.replace('ffrt2 ', "")
				#if 'rtmp://' in url: url = url + " timeout=14"
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				writeappend_file(client_ipaddr_log, ' redirect live.m3u: ' + str(url))
				self.finish()
			
            elif 'uktvnow.m3u' in self.path:                
				if mydebug =="true": infoDialog('Detected uktvnow.m3u in path', 'Server uktvnow [1]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				tmp = args['tmp'][0];
				#portal = portals[numportal];
				pk_id = args['pkid'][0];
				url = PlayUKTVNowChannels(pk_id)
				if "rtmp://" in url: url = url + " timeout=15"
				#time.sleep(5)
				self.send_response(301)
				self.send_header('Location', url)
				#time.sleep(5)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect uktvnow.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'Server uktvnow [2]')
				self.finish()

            elif 'dtiptv.m3u' in self.path:
				infoDialog('Detected dtiptv.m3u', 'dtiptv [1]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				#numportal = args['portal'][0];
				url = str(MyDTCode) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + url, 'dtiptv [2]');
				#if url == "": time.sleep(7)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect dtiptv.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'dtiptv [3]')
				self.finish()

            elif 'iptvsubstv.m3u' in self.path:
				infoDialog('Detected iptvsub.m3u', '[COLOR red]iptvsub [1][/COLOR]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				#numportal = args['portal'][0];
				url = str(MyIptvSubsCodetv) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + url, 'iptvsub [2]');
				#if url == "": time.sleep(7)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect iptvsub.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'iptvsub [3]')
				self.finish()
				
            elif 'tsf4mst.m3u' in self.path:
				infoDialog('Start tsf4mst Proxy', 'tsf4mst [1]');
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				url = playF4mLink(url=cmd, name=pk_id, maxbitrate=0, streamtype="TSDOWNLOADER", setResolved=True)
				infoDialog('[COLOR green]get url for Client..[/COLOR]' + url, 'tsf4mst [2]')
				self.send_response(301)
				self.send_header('Location', urllib.unquote_plus(url))
				self.end_headers()
				infoDialog('[COLOR green]Done Proxy, ready to stream now.. [/COLOR]' + str(url), 'tsf4mst [3]')
				self.finish()
                
            elif 'epg.xml' in self.path:
				
				args = parse_qs(urlparse(self.path).query);
				numportal = args['portal'][0];
				
				portal = portals[numportal];
				
				try:
					xml = load_channels.getEPG(portal['mac'], portal['url'], portal['serial'], addondir);
				except Exception as e:
					xml  = '<?xml version="1.0" encoding="ISO-8859-1"?>'
					xml += '<error>' + str(e) + '</error>';
					
				
				self.send_response(200)
				self.send_header('Content-type',	'txt/xml')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(xml))
				self.end_headers()
				self.wfile.write(xml)
				self.finish()
                 
            elif 'stop' in self.path:
				msg = 'Stopping ...';
				#infoDialog('msg Stopping ...', 'Server Stop 1', time=1000);
				self.send_response(200)
				self.send_header('Content-type',	'text/html')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(msg))
				self.end_headers()
				self.wfile.write(msg.encode('utf-8'))
				#infoDialog('msg: ' + str(msg.encode('utf-8')), 'Server Stop 2', time=1000);
				server.socket.close();
                
            elif 'online' in self.path:
				msg = 'Yes. I am.';
				#infoDialog('msg online ...', 'Server online 1', time=1000);
				self.send_response(200)
				self.send_header('Content-type',	'text/html')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(msg))
				self.end_headers()
				#infoDialog('msg: ' + str(msg.encode('utf-8')), 'Server online 2', time=1000);
				self.wfile.write(msg.encode('utf-8'))
            
            
            else:
            	self.send_error(400,'Bad Request');
            	#infoDialog('***send_error***', 'Server do_Get', time=1000);
        except IOError:
            self.send_error(500,'Internal Server Error ' + str(IOError))
        infoDialog('[COLOR lime]All Done![/COLOR]', 'IPTV Server', time=3000);
	



@Async
def startServer():
	global portals, server;
	
	server_enable = addon.getSetting('server_enable');
	port = int(addon.getSetting('server_port'));
	
	if server_enable != 'true':
		return;

	portals = { 
		'1' : config.portalConfig('1'), 
		'2' : config.portalConfig('2'), 
		'3' : config.portalConfig('3') };

	try:
		server = SocketServer.TCPServer(('', port), MyHandler);
		server.serve_forever();
		
	except KeyboardInterrupt:
		if server != None:
			server.socket.close();

def serverOnline():
	
	port = addon.getSetting('server_port');
	
	try:
		url = urllib.urlopen('http://localhost:' + str(port) + '/online');
		code = url.getcode();
		
		if code == 200:
			return True;
	
	except Exception as e:
		return False;

	return False;


def stopServer():
	
	port = addon.getSetting('server_port');
	
	try:
		url = urllib.urlopen('http://localhost:' + str(port) + '/stop');
		code = url.getcode();

	except Exception as e:
		return;

	return;

if __name__ == '__main__':
	startServer();
