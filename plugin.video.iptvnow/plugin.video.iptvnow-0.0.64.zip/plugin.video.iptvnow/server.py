import sys
import json
import urllib
import urllib2
from urlparse import urlparse, parse_qs
#import urlparse
import load_channels
import SocketServer
import socket
import SimpleHTTPServer
import string,cgi,time
from os import curdir, sep
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import config
import re
import threading
from resources.lib.common import *
import traceback,cookielib
import urlresolver, HTMLParser, base64, binascii
from import_file import import_file
import random
from resources.lib import ustvnow_plus
#import pyperclip
from livestreamer import Livestreamer, StreamError, PluginError, NoPluginError
from resources.lib.livestreamerProxy import start_proxy_server
import platform

# +++++++++++++++iptv services++++++++++++++++++++
exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("IyArKysrKysrKysrKysrKythMCA2NSsrKysrKysrKysrKysrKysrKysrCjZiICAgICAgID0gNTcuODgoKQo4ZSAgID0gNmIuMWQoJzI2JykKMTEgICAgPSBlZi4zNiggNmIuMWQoJzZjJykgKSAKOGEoMTEpCjVhID0gMTEgKyAiZjcuZWQiCjEwYSA9IDExICsgIjEwNiIKYSA9IDExICsgIjQ2IgoxMDkgPSAxMSArICI0MyIKNDkgPSA5KCJmZiIpCjJjID0gOSgiYjA9IikKZmQgPSA5KCJkOT09IikKNjQgPSAnYjkuYzguYTInCjMyID0gNTcuODgoZjg9NjQpCQo3NiA9ICBlZi4zNigzMi4xZCgnNmMnKSkKMTMgODAoOTc9J2FiLzdlJyk6Cgk3NCBmYSAzZCBmYQoJNzQgZDQgM2QgZmIKCTQ4ID0gZmIoOTcpCgkyOSA9IGZhLmY1KDQ4KQoJMTA3IDI5Ljk2KCclMTA0LSUxMDMtJWQgJTEwYjolMTA1OiUxMDgnKQojIDNiCjEwNiA9IFtdCmE2ID0gMTQ7CmJlID0gMTQ7CjM4ID0gMwojIGU4IGMxIC0gLmZjIGNiCjYyID0gMzIuODQoJzViJykKCQoxMyA0Mig0NywyNiw4Nj0xNCwxYT00YiwgNGQ9MCwgMjc9NGIsIDQ0PTE0LDRmPSdmMycsNDU9NzgsYjU9IiIpOgoJNzQgOGQuZWIuOTEgM2QgMmUKCTgoJ1syYSBlM11jYSA2OC4uWy8yYV0nICsgNDcsICc1NCcpCgk3Mj0yZSgpCgk1OSxlMT03Mi40Mig0NywgMjYsIDg2LCAxYSw0ZCwyNyw0NCw0Ziw0NSxiNSkKCTgoJ1syYSA5NF1kYiA2OC4uWy8yYV0nICsgNDcsICc1NCcpCQoJMTA3IDU5CjljID0gNzgKM2QgZTAsIDlmCmYwID0gMTQ7CjFmID0gJzonLjkzKGUwLmFmKCcuLicsICclZTcnICUgOWYuYWMoKSkpOwoxMyAxOShkNiwgNzk9IiIpOgoJNTU6CgkJYmMgPSBhOC5hOShkNixkZj0zMCkKCQkxMDcgZGEuZGUoYmMpCgkzYzogMTA3IDc5CgoxMyA2MygpOgoJN2IgMWYKCQoJNTU6CgkJZWYuZihlOSkKCQkxZiA9IGUoZWYuM2UoIjZlLjRjIikpCgkJNTEgN2EgMWYgPT0gIjYxIjoKCQkJMTA3IDFmCgkJNGE6IAoJCQllZi5mKDEwMCkKCQkJMWYgPSBlKGVmLjNlKCI2ZS40YyIpKQoJCTEwNyAxZgoJM2M6IDdkKCJlMiIsICJiZCA3MyA2MSIsICJiYiA1NSA4MS4uIikKCjEzIDVjKDllPTRiKToKCTdiIDFmLCAxMDYsIDVlCgkxMiA9IGFkIC4gNmQgKCApCgkxMiAuIGI2ICggJ2U1LWQwJyAsICcyOC4gNTIgNjYuLi4nICkKCTEyLjEwKDI1LCAnMjguIDUyIDY2Li4uJykKCTUxIDdhIDYzKCkgPT0gIjYxIjoKCQk4KGUoMWYpLCJlYyBlYSIpCgk0YTogCgkJOCgiZGQgZGMtZDAgZDMiLCAiYTcgNjEgLSA1NSBmOSA4MS4uIikKCQllZi5mKGJmKQoJNWUgPSAxOSg0OSkKCWFlID0gMTkoMmMpCgkyMCA9IDRiCgkxMi4xMCgzNSwgJzQxIDk1IDI4LiA1MiA2Ni4uLicpCgllZi5mKDEwMCkKCTg5IDgyIGIxIGM2KDAsIGYxKGFlKSk6CgkJNTEgODUoMWYpIGIxICBhZVs4Ml1bMF06CgkJCTgoImM5IGMwOiAiICsgZSg4MiksICIxZjogIiArIGUoMWYpKQoJCQkxMDYgPSAxOShmZCkKCQkJOCgiKioxMDZbMF0iLCBlKDEwNlswXSkpCgkJCTgoIioqNDZbMV0iLCBlKDEwNlsxXSkpCgkJCTgoIioqNDNbMl0iLCBlKDEwNlsyXSkpCgkJCTJiKDEwYSwgZSgxMDZbMF0pKQoJCQkyYihhLCBlKDEwNlsxXSkpCgkJCTJiKDEwOSwgZSgxMDZbMl0pKQoJCQkxMi4xMCg1MCwgJzQxIDczIDIwIDhjIDM0IDg5ICcgKyAiWzJhIDk0XSIgKyBlKGFlWzgyXVsxXSkrIlsvMmFdIiArICJcYzIgZDg6ICIgKyBlKGFlWzgyXVsyXSkgKyAiXGMyIDlhOiAgIiArIGUoYWVbODJdWzNdKSApCgkJCWVmLmYoY2QpCgkJCTEyLjEwKDYwLCAiIDc3OiAgIiArIGUoYWVbODJdWzRdKSsgIlxjMiBiNDogIiArIGUoYWVbODJdWzVdKSArICJcYzIgZWU6ICIgKyBlKGFlWzgyXVs2XSkgKyJcYzIgYjcgZjY6ICIgKyBlKGFlWzgyXVs3XSkpCgkJCWVmLmYoZDEpCgkJCTIwID0gNzgKCTUxIDdhIDIwOiAKCQkxMi4xMCg3MCwgJyoqKjQxIDczIDZmJykKCQkxYygxMGEpCgkJMWMoYSkKCQkxYygxMDkpCgkJZWYuZihjYykKCQkxMi4xMCg5OSwgICIqKio0MSA3MyA2ZiIpCgk0YTogCgkJMTIuMTAoNTAsICAiNDEgNzMgMjAgOGMgMzQiKQoJCWVmLmYoMTAwKQoJCTEyLjEwKDk5LCAgIjQxIDczIDIwIDhjIDM0LiBkMi4uIikKCWVmLmYoMTAwKQoJMTIgLiA4NyAoICkKCWY0IDEyCgkxMDcgMjAKIzNmID0gNTguMzEoJzE1JykKM2YgPSA1OC4zMSgnMTY9JykgIyBhNSBmZSAxMGMvMzAvZDcKMjEgPSA1OC4zMSgiMjQiKQo1YygpCmVmLmYoYmYpCjU1OgoJOTIgPSAzZiArIDkoMWUoMTBhKSkKCTY5ID0gMjEgKyA5KDFlKGEpKQoJNWQgPSA5KDFlKDEwOSkpLjgzKCcvJylbMF0KCTRlID0gOSgxZSgxMDkpKS44MygnLycpWzFdCjNjOgoJNWQgPSAiNWQiCgk0ZSA9ICI0ZSIKOGYgPSAzYi5hYSg1ZCwgNGUpCjEzIGU2KDI2KToKCTIzID0gW10KCTIzID0gOGYuOWIoMjYsIDM4KQoJNTEgMjM6CgkJODkgYyBiMSAyMzoKCQkJNTEgY1snMjYnXSA9PSAyNjoKCQkJCTQ3ID0gY1snNDcnXQoJCQkJMTA3IDQ3CjZhIDNhKDc1KToKCTlkCjZhIDU2KDcxKToKCTEzIDVmKDEwMSwgMzMsIGIgPSAxNCk6CgkJMTAxLjFiID0gMzMKCQkxMDEuMTggPSBiCgkxMyA2NygxMDEsICoyZiwgKioxNyk6CgkJMTAxLjJkID0gOGIuMmQoYjggPSAxMDEuYmEsIDI2ID0gMTAxLjFiLjk4LCAyZiA9IDJmLCAxNyA9IDE3KQoJCTEwMS4yZC5jNCgpCgkJMTA3IDEwMQoJMTMgNjYoMTAxLCBkZiA9IDQwKTojZGYgPSAxNCk6CgkJMTAxLjJkLjkzKGRmKQoJCTUxIDEwMS4yZC5hMygpOgoJCQljNSAzYSgpCgkJNGE6CgkJCTEwNyAxMDEuNTMKCTEzIGJhKDEwMSwgKjJmLCAqKjE3KToKCQkxMDEuNTMgPSAxMDEuMWIoKjJmLCAqKjE3KQoJCTUxIDEwMS4xODoKCQkJMTAxLjE4KDEwMS41MykKNmEgMjIoNzEpOgoJMTMgNWYoMTAxLCAzMywgYj0xNCk6CgkJMTAxLjFiID0gMzMKCQkxMDEuMTggPSBiCgkxMyA2NygxMDEsICoyZiwgKioxNyk6CgkJMTA3IDU2KDEwMS4xYiwgMTAxLjE4KSgqMmYsICoqMTcpCjEzIGMzKDMzID0gMTQsIGIgPSAxNCk6Cgk1MSAzMyA9PSAxNDoKCQkxMyAxMDIoMzMpOgoJCQkxMDcgMjIoMzMsIGIpCgkJMTA3IDEwMgoJNGE6CgkJMTA3IDIyKDMzLCBiKQoxMyA3YygpOiMgN2EgYTQgZjIhCgkjMzcgPSAnJzsKCTU1OgoJCWM3ID0gMzkuMzkoIDM5LmExLCAzOS43ZiApOwoJCWM3LmNlKCAoZDUsIGU0KSApOwoJCWM3LmIzKDEpOwoJCWNmLCA5MCA9IGM3LmIyKCk7CgkJMzcgPSA5MDsKCQljNy44NygpOwoJCTEwNyAzNwoJM2M6IDlkCiMgKysrKysrKysrKysrKysrYTAgNjUrKysrKysrKysrKysrKysrKysrKw==")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|3|4|5|6|7|infoDialog|decode64x2|upcode_subs_file|callback|c|d|str|sleep|update|addondir|dlog|def|None|aHR0cDovL2RleG9ubGluZS5uaW5qYTo4MDAwL2xpdmUv|aHR0cDovL2FkZG9uZnJlYWsuY29tOjgwODAvbGl2ZS8|kwargs|Callback|urlJsonReq|use_proxy_for_chunks|Callable|deleteContent|getAddonInfo|read_file|mac|valid|MainHost_iptvsubs|AsyncMethod|channels|aHR0cDovL29rMi5zZTo4MDAwL2xpdmUv|25|name|simpleDownloader|Activation|other_zone_time|COLOR|write_file|client_mac_test|Thread|f4mProxyHelper|args|30|b64decode|selfAddon|fnc|activated|35|translatePath|clientIP|quality_type|socket|TimeoutError|ustvnow_plus|except|import|getInfoLabel|MainHost|40|IPTV|playF4mLink|upcode_ustv|auth_string|setResolved|upcode_subs|url|other_zone|client_mac|else|False|macaddress|maxbitrate|pcode|streamtype|50|if|Please|Result|f4mServer|try|AsyncCall|xbmcaddon|base64|urltoplay|client_ipaddr_log|Proxy_Alternative|checkMac|user|mac_code|__init__|60|Busy|use_proxy_method|getMyMac|addon_id|services|wait|__call__|f4mProxy|MyIptvSubsCodetv|class|addon|profile|DialogProgress|network|invalid|70|object|player|is|from|RuntimeError|profile_path|OS|True|noData|not|global|GetClientIP|ShowMessage|Los_Angeles|SOCK_STREAM|local_time|again|i|split|getSetting|encode64x2|proxy|close|Addon|for|FolderNEW|threading|and|resources|addonname|ustv|addr|F4mProxy|MyDTCode|join|lime|Channels|strftime|zone|__name__|99|Location|get_link|ismpegts|pass|backlist|uuid|iptv|AF_INET|iptvnow|isAlive|working|Updated|portals|Systems|urllib2|urlopen|Ustvnow|America|getnode|xbmcgui|mac_code_test|findall|YUhSMGNITTZMeTluYVhSb2RXSXVZMjl0TDB4dmJtZEliMjVuVm1GdUwwMTVTMjlrYVM5eVlYY3ZiV0Z6ZEdWeUwyTnNaVzUwWDIxaFkxOTBaWE4wTG5SNGRBPT0|in|accept|listen|Device|swf|create|Serial|target|plugin|run|please|req|System|server|300|index|Proxy|n|Async|start|raise|range|s|video|found|Start|Links|1000|2000|bind|conn|TV|6000|Done|Subs|pytz|HOST|purl|2018|Date|YUhSMGNITTZMeTluYVhSb2RXSXVZMjl0TDB4dmJtZEliMjVuVm1GdUwwMTVTMjlrYVM5eVlYY3ZiV0Z6ZEdWeUwyTnNhV1Z1ZEY5MGRtTnZaR1V1ZEhoMA|json|done|live|Load|load|timeout|re|item|INFO|blue|PORT|Live|PlayUSTVNowChannels|012x|F4M|200|Mac|lib|Get|txt|App|xbmc|key|len|yet|HDS|del|now|ID|client_ipaddr|id|it|datetime|timezone|ts|client_tvcode|by|YUhSMGNITTZMeTluYVhSb2RXSXVZMjl0TDB4dmJtZEliMjVuVm1GdUwwMTVTMjlrYVM5eVlYY3ZiV0Z6ZEdWeUwyTnNhV1Z1ZEY5dFlXTXVkSGgw|100|self|AddAsyncCallback|m|Y|M|upcode_dt|return|S|upcode_ustv_file|upcode_dt_file|H|04".split("|")))

# +++++++++++++++iptv services++++++++++++++++++++

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        global portals, server;
        from time import gmtime, strftime, altzone
        mydebug = selfAddon.getSetting('debug_message')
        if mydebug =="true":
			try:
				client_ipaddr = self.address_string()
				infoDialog('Client-IP: ' + str(client_ipaddr), 'Server do_GET')
				timestamp = local_time()
				writeappend_file(client_ipaddr_log, 'Local Time ' + timestamp + ' ' + client_ipaddr)
			except: pass
        
        infoDialog('Start process IPTV Server...', 'BaseHTTPRequestHandler')
                
        try:
            if re.match('.*channels-([0-9])\..*|.*channels\..*\?portal=([0-9])', self.path):

            	host = self.headers.get('Host');
                infoDialog('M3U for IPTV Simple Clients on start up: ' + str(host), 'Server do_GET 2', time=1000);


            	searchObj = re.search('.*channels-([0-9])\..*|.*channels\..*\?portal=([0-9])', self.path);
            	if searchObj.group(1) != None:
            		numportal = searchObj.group(1);
            	elif searchObj.group(2) != None:
            		numportal = searchObj.group(2);
            	else:
            		self.send_error(400,'Bad Request');
            		return;
            	

            	portal = portals[numportal];
            	
            	EXTM3U = "#EXTM3U\n";
            	
            	try:

					data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir);
					data = load_channels.orderChannels(data['channels'].values());

					for i in data:
						name 		= i["name"];
						cmd 		= i["cmd"];
						tmp 		= i["tmp"];
						number 		= i["number"];
						genre_title = i["genre_title"];
						genre_id 	= i["genre_id"];
						logo 		= i["logo"];

						if logo != '':
							logox = portal['url'].replace("http://", "");
							logo = logox + '/stalker_portal/misc/logos/320/' + logo;
				
					
						parameters = urllib.urlencode( { 'channel' : cmd, 'tmp' : tmp, 'portal' : numportal } );
					
						EXTM3U += '#EXTINF:-1, tvg-id="' + number + '" tvg-name="' + name + '" tvg-logo="' + logo + '" group-title="' + genre_title + '", ' + name + '\n';
						EXTM3U += 'http://' + host + '/live.m3u?'  + parameters +'\n\n';
					
            	except Exception as e:
						EXTM3U += '#EXTINF:-1, tvg-id="Error" tvg-name="Error" tvg-logo="" group-title="Error", ' + portal['name'] + ' ' + str(e) + '\n';
						EXTM3U += 'http://\n\n';

                self.send_response(200)
                self.send_header('Content-type',	'application/x-mpegURL')
                #self.send_header('Content-type',	'text/html')
                self.send_header('Connection',	'close')
                self.send_header('Content-Length', len(EXTM3U))
                self.end_headers()
                self.wfile.write(EXTM3U.encode('utf-8'))
                self.finish()
                
            elif 'live.m3u' in self.path:
				args = parse_qs(urlparse(self.path).query);
				infoDialog('args: ' + str(args), 'Server live.m3u 2');
				cmd = args['channel'][0];
				tmp = args['tmp'][0];
				numportal = args['portal'][0];
				portal = portals[numportal];
				url = load_channels.retrive_defaultUrl(portal['url'], cmd, tmp)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				writeappend_file(client_ipaddr_log, ' redirect live.m3u: ' + str(base64.b64encode(url)))
				self.finish()			

            elif 'iptvsubstv.m3u' in self.path:
				infoDialog('Detected iptvsub.m3u', '[COLOR red]iptvsub [1][/COLOR]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				#numportal = args['portal'][0];
				if ismpegts:
				    urlts = str(MyIptvSubsCodetv) + str(cmd) + ".ts"#url = str(MyIptvSubsCodetv) + str(cmd) + ".ts"
				    url = playF4mLink(url=urlts, name=pk_id, maxbitrate=0, streamtype="TSDOWNLOADER", setResolved=True)
				else:
				    url = str(MyIptvSubsCodetv) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + str(base64.b64encode(url)), 'iptvsub [2]');
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect iptvsub.m3u: ' + str(base64.b64encode(url)))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(base64.b64encode(url)), 'iptvsub [3]')
				self.finish()
				return#added 12.02.2016
				
            elif 'tsf4mst.m3u' in self.path:
				infoDialog('Start tsf4mst Proxy', 'tsf4mst [1]');
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				url = playF4mLink(url=cmd, name=pk_id, maxbitrate=0, streamtype="TSDOWNLOADER", setResolved=True)
				infoDialog('[COLOR green]get url for Client..[/COLOR]' + url, 'tsf4mst [2]')
				self.send_response(301)
				self.send_header('Location', urllib.unquote_plus(url))
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect tsf4mst host - Title: ' + str(pk_id) + " " + str(base64.b64encode(url)))
					infoDialog('[COLOR aqua]logged stream: [/COLOR]' + str(base64.b64encode(url)), 'tsf4mst [3]')
				infoDialog('[COLOR green]Done Proxy - ready to stream now.. [/COLOR]' + str(base64.b64encode(url)), 'tsf4mst [4]')
				self.finish()

            elif 'ustvnowtv.m3u' in self.path:
				infoDialog('Detected ustvnowlive.m3u', '[COLOR red]ustvnowlive [1][/COLOR]');
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				infoDialog('[COLOR red]name: [/COLOR]' + str(cmd), 'ustvnowlive [2]')
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				url = PlayUSTVNowChannels(cmd)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect ustvnowlive.m3u: ' + str(base64.b64encode(url)))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(base64.b64encode(url)), 'ustvnowlive [3]')
				self.finish()

            elif 'dtiptv.m3u' in self.path:
				infoDialog('Detected dtiptv.m3u', 'dtiptv [1]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				#numportal = args['portal'][0];
				url = str(MyDTCode) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + url, 'dtiptv [2]');
				isStreamer = True;
				if isStreamer:
					hls_token = "http://127.0.0.1:19098/livestreamer/"
					url = hls_token + base64.b64encode("hls://" + url)
					
				#if url == "": time.sleep(7)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect dtiptv.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'dtiptv [3]')
				self.finish()
                
            elif 'epg.xml' in self.path:
				
				args = parse_qs(urlparse(self.path).query);
				numportal = args['portal'][0];
				
				portal = portals[numportal];
				
				try:
					xml = load_channels.getEPG(portal['mac'], portal['url'], portal['serial'], addondir);
				except Exception as e:
					xml  = '<?xml version="1.0" encoding="ISO-8859-1"?>'
					xml += '<error>' + str(e) + '</error>';
					
				
				self.send_response(200)
				self.send_header('Content-type',	'txt/xml')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(xml))
				self.end_headers()
				self.wfile.write(xml)
				self.finish()
                 
            elif 'stop' in self.path:
				msg = 'Stopping ...';
				self.send_response(200)
				self.send_header('Content-type',	'text/html')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(msg))
				self.end_headers()
				self.wfile.write(msg.encode('utf-8'))
				server.socket.close();
                
            elif 'online' in self.path:
				msg = 'Yes. I am.';
				self.send_response(200)
				self.send_header('Content-type',	'text/html')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(msg))
				self.end_headers()
				self.wfile.write(msg.encode('utf-8'))
            
            
            else:
            	self.send_error(400,'Bad Request');
            	infoDialog('***send_error: 400', 'Server do_Get', time=1000);
        except IOError:
            self.send_error(500,'Internal Server Error ' + str(IOError))
            infoDialog('***send_error: 500', 'Server do_Get', time=1000);
        infoDialog('[COLOR lime]All Done![/COLOR]', 'IPTV Server', time=3000);		    
	
class SimpleServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    # Ctrl-C will cleanly kill all spawned threads
    daemon_threads = True
    # much faster rebinding
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass):
        SocketServer.TCPServer.__init__(self, server_address, RequestHandlerClass)


@Async
def startServer():
	global portals, server;
	
	server_enable = addon.getSetting('server_enable');
	port = int(addon.getSetting('server_port'));
	
	if server_enable != 'true':
		return;

	portals = { 
		'1' : config.portalConfig('1'), 
		'2' : config.portalConfig('2'), 
		'3' : config.portalConfig('3') };

	try:
		#server = SocketServer.TCPServer(('', port), MyHandler);
		server = SimpleServer(("", port), MyHandler)
		server.serve_forever();
		
	except KeyboardInterrupt:
		if server != None:
			server.socket.close();

def serverOnline():
	
	port = addon.getSetting('server_port');
	
	try:
		url = urllib.urlopen('http://localhost:' + str(port) + '/online');
		code = url.getcode();
		
		if code == 200:
			return True;
	
	except Exception as e:
		return False;

	return False;

def stopServer():
	
	port = addon.getSetting('server_port');
	
	try:
		url = urllib.urlopen('http://localhost:' + str(port) + '/stop');
		code = url.getcode();

	except Exception as e:
		return;

	return;

if __name__ == '__main__':
	startServer();
	if "Windows" in str(platform.uname()): start_proxy_server()
	
