import sys
import os
import json
import urllib
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import load_channels
import hashlib
import re
import base64
import server
import random

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 
# 00:1A:78:51:33:34 Origin
#pm			= '4D4441364D5545364E7A67364E4463364E4463364E44633D'.decode('hex').decode('base64')#00:1A:78:47:47:47
pm = ['00:1A:78:00:55:99']#, '00:1A:78:12:34:90', '00:1A:78:12:35:72', '00:1A:78:12:13:19']# '00:1A:78:06:06:06' # temp = ['00:1A:78:12:34:90', '00:1A:78:12:35:72', 00:1A:78:12:13:19]
# pu			= '6148523063446F764C32356D63484D75633352686247746C636D4E736232356C4C6D356C64486476636D733D'.decode('hex').decode('base64')
pu			= 'http://mw1.iptv66.tv'#'http://portal.iptvrocket.tv'#'http://portal.iptvprivateserver.tv' #'http://mw1.iptv66.tv'
'''
pm = ['00:1A:79:91:00:00',
'00:1A:78:10:00:03',
'00:1A:78:10:00:06',
'00:1A:78:10:00:58',
'00:1A:78:10:00:70',
'00:1A:78:10:00:73',
'00:1A:78:10:00:87',
'00:1A:78:12:34:79',
'00:1A:78:08:08:08',
'00:1A:78:10:00:20',
'00:1A:78:17:17:17',
'00:1A:78:98:76:54',
'00:1A:78:01:11:22',
'00:1A:79:23:23:23',
'00:1A:78:12:34:99',
'00:1A:78:23:23:23',
'00:1A:78:24:79:42',
'00:1A:78:66:66:52',
'00:1A:79:00:10:50',
'00:1A:79:12:34:99',
'00:1A:78:11:22:63',
'00:1A:78:12:34:68',
'00:1A:78:12:34:70',
'00:1A:78:12:34:62',
'00:1A:78:12:34:64',
'00:1A:78:12:34:67']
'''
def portalConfig(number):

	portal = {};
	
	portal['parental'] = addon.getSetting("parental");
	portal['password'] = addon.getSetting("password");
	
	portal['name'] = addon.getSetting("portal_name_" + number);
	portal['url'] = pu;
	portal['mac'] = configMac(number);
	portal['serial'] = configSerialNumber(number);
		
	return portal;


def configMac(number):
	global go;
	
	custom_mac = addon.getSetting('custom_mac_' + number);
	portal_mac = random.choice(pm); #pm;
	
	if custom_mac != 'true':
		portal_mac = '';
		
	elif not (custom_mac == 'true' and re.match("[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", portal_mac.lower()) != None):
		xbmcgui.Dialog().notification(addonname, 'Custom Mac ' + number + ' is Invalid.', xbmcgui.NOTIFICATION_ERROR );
		portal_mac = '';
		go=False;
		
	return portal_mac;
	
	
def configSerialNumber(number):
	global go;
	
	send_serial = addon.getSetting('send_serial_' + number);
	custom_serial = addon.getSetting('custom_serial_' + number);
	serial_number = addon.getSetting('serial_number_' + number);
	device_id = addon.getSetting('device_id_' + number);
	device_id2 = addon.getSetting('device_id2_' + number);
	signature = addon.getSetting('signature_' + number);

	
	if send_serial != 'true':
		return None;
	
	elif send_serial == 'true' and custom_serial == 'false':
		return {'custom' : False};
		
	elif send_serial == 'true' and custom_serial == 'true':
	
		if serial_number == '' or device_id == '' or device_id2 == '' or signature == '':
			xbmcgui.Dialog().notification(addonname, 'Serial information is invalid.', xbmcgui.NOTIFICATION_ERROR );
			go=False;
			return None;
	
		return {'custom' : True, 'sn' : serial_number, 'device_id' : device_id, 'device_id2' : device_id2, 'signature' : signature};
		
	return None;