import sys
import json
import urllib
import urllib2
from urlparse import urlparse, parse_qs
import load_channels
import SocketServer
import socket
import SimpleHTTPServer
import string,cgi,time
from os import curdir, sep
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import config
import re
import threading
from common import *
import traceback,cookielib
import urlresolver, HTMLParser, base64, binascii
from import_file import import_file
import random
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 
MyServerUrlLink = addondir + "MyServerUrlLink.txt"

portals = None;
server = None;
mac_address = "";

def getMacAddress(): 
    if sys.platform == 'win32': 
        for line in os.popen("ipconfig /all"): 
            if line.lstrip().startswith('Physical Address'): 
                mac = line.split(':')[1].strip().replace('-',':') 
                break 
    else: 
        for line in os.popen("/sbin/ifconfig"): 
            if line.find('Ether') > -1: 
                mac = line.split()[4] 
                break 
    return mac      
'''
def local_time(zone='Asia/Karachi'):
    from datetime import datetime
    from pytz import timezone
    other_zone = timezone(zone)
    other_zone_time = datetime.now(other_zone)
    return other_zone_time.strftime('%B-%d-%Y')
 '''   	    

addon_id = 'plugin.video.iptvnow'
selfAddon = xbmcaddon.Addon(id=addon_id)	
profile_path =  xbmc.translatePath(selfAddon.getAddonInfo('profile'))

# F4M Proxy - .ts Links
def playF4mLink(url,name,proxy=None,use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth_string=None,streamtype='HDS',setResolved=False,swf=""):
    from resources.lib.F4mProxy import f4mProxyHelper
    player=f4mProxyHelper()
    if setResolved:
        urltoplay,item=player.playF4mLink(url, name, proxy, use_proxy_for_chunks,maxbitrate,simpleDownloader,auth_string,streamtype,setResolved,swf)
    else: urltoplay = url   
    return urltoplay

class TimeoutError(RuntimeError):
    pass

class AsyncCall(object):
    def __init__(self, fnc, callback = None):
        self.Callable = fnc
        self.Callback = callback

    def __call__(self, *args, **kwargs):
        self.Thread = threading.Thread(target = self.run, name = self.Callable.__name__, args = args, kwargs = kwargs)
        self.Thread.start()
        return self

    def wait(self, timeout = None):
        self.Thread.join(timeout)
        if self.Thread.isAlive():
            raise TimeoutError()
        else:
            return self.Result

    def run(self, *args, **kwargs):
        self.Result = self.Callable(*args, **kwargs)
        if self.Callback:
            self.Callback(self.Result)

class AsyncMethod(object):
    def __init__(self, fnc, callback=None):
        self.Callable = fnc
        self.Callback = callback

    def __call__(self, *args, **kwargs):
        return AsyncCall(self.Callable, self.Callback)(*args, **kwargs)

def Async(fnc = None, callback = None):
    if fnc == None:
        def AddAsyncCallback(fnc):
            return AsyncMethod(fnc, callback)
        return AddAsyncCallback
    else:
        return AsyncMethod(fnc, callback)

	
AuthSignFile = addondir + "AuthSign.txt"
client_ipaddr_log = addondir + "client_ipaddr.txt"
upcode = ['hWrb6XkX/tPzbyqbZ/']
upcode_iptvsubs = ['bHZob25ndXNAeWFob28uY29tL2l2eV9nb2VzOTkv', 'dGh1eXZvMTc0QGdtYWlsLmNvbS93aGUzNDY1Zy8=']
MainHost = 'http://158.69.54.54:8000/live/'
MainHost_iptvsubs = base64.b64decode('aHR0cDovL2J1bGxzaXB0di5zZTo5ODUwL2xpdmUv')
MyDTCode = MainHost + random.choice(upcode)
MyIptvSubsCodetv = MainHost_iptvsubs + base64.b64decode(random.choice(upcode_iptvsubs))
MyIptvSubsCodevod = MainHost_iptvsubs + base64.b64decode(random.choice(upcode_iptvsubs))

MainHost_iptvusa = base64.b64decode('aHR0cDovL3VzYWlwdHYuZGRucy5uZXQ6OTA5MC9sb2FkLw==')
MyIptvusaCodetv = MainHost_iptvusa + base64.b64decode('MDg1NWViZDRmOTBiLw==')

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        global portals, server;
        from time import gmtime, strftime, altzone
        mydebug = selfAddon.getSetting('debug_message')
        if mydebug =="true":
			try:
				client_ipaddr = self.address_string()
				infoDialog('Client-IP: ' + str(client_ipaddr), 'Server do_GET')
				timestamp = strftime("%Y-%m-%d %H:%M:%S", gmtime())
				#now_pacific = now_utc.astimezone(timezone('US/Pacific'))
				writeappend_file(client_ipaddr_log, 'GM Time ' + timestamp + ' ' + client_ipaddr)
			except: pass
        
        infoDialog('Start process IPTV Server...', 'BaseHTTPRequestHandler')
                
        try:
            if re.match('.*channels-([0-9])\..*|.*channels\..*\?portal=([0-9])', self.path):

            	host = self.headers.get('Host');
                infoDialog('M3U for IPTV Simple Clients on start up: ' + str(host), 'Server do_GET 2', time=1000);


            	searchObj = re.search('.*channels-([0-9])\..*|.*channels\..*\?portal=([0-9])', self.path);
            	if searchObj.group(1) != None:
            		numportal = searchObj.group(1);
            	elif searchObj.group(2) != None:
            		numportal = searchObj.group(2);
            	else:
            		self.send_error(400,'Bad Request');
            		return;
            	

            	portal = portals[numportal];
            	
            	EXTM3U = "#EXTM3U\n";
            	
            	try:

					data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir);
					data = load_channels.orderChannels(data['channels'].values());

					for i in data:
						name 		= i["name"];
						cmd 		= i["cmd"];
						tmp 		= i["tmp"];
						number 		= i["number"];
						genre_title = i["genre_title"];
						genre_id 	= i["genre_id"];
						logo 		= i["logo"];

						if logo != '':
							#logo = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
							# LHong Fixed Logo for PVR IPTV Simple
							logox = portal['url'].replace("http://", "");
							logo = logox + '/stalker_portal/misc/logos/320/' + logo;
				
					
						parameters = urllib.urlencode( { 'channel' : cmd, 'tmp' : tmp, 'portal' : numportal } );
					
						EXTM3U += '#EXTINF:-1, tvg-id="' + number + '" tvg-name="' + name + '" tvg-logo="' + logo + '" group-title="' + genre_title + '", ' + name + '\n';
						EXTM3U += 'http://' + host + '/live.m3u?'  + parameters +'\n\n';
					
            	except Exception as e:
						EXTM3U += '#EXTINF:-1, tvg-id="Error" tvg-name="Error" tvg-logo="" group-title="Error", ' + portal['name'] + ' ' + str(e) + '\n';
						EXTM3U += 'http://\n\n';
        	
        	
                self.send_response(200)
                self.send_header('Content-type',	'application/x-mpegURL')
                #self.send_header('Content-type',	'text/html')
                self.send_header('Connection',	'close')
                self.send_header('Content-Length', len(EXTM3U))
                self.end_headers()
                self.wfile.write(EXTM3U.encode('utf-8'))
                self.finish()
                
            elif 'live.m3u' in self.path:
				args = parse_qs(urlparse(self.path).query);
				infoDialog('args: ' + str(args), 'Server live.m3u 2');
				cmd = args['channel'][0];
				tmp = args['tmp'][0];
				numportal = args['portal'][0];
				portal = portals[numportal];
				url = load_channels.retrive_defaultUrl(portal['url'], cmd, tmp)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				writeappend_file(client_ipaddr_log, ' redirect live.m3u: ' + str(url))
				self.finish()			

            elif 'dtiptv.m3u' in self.path:
				infoDialog('Detected dtiptv.m3u', 'dtiptv [1]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				url = str(MyDTCode) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + url, 'dtiptv [2]');
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect dtiptv.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'dtiptv [3]')
				self.finish()

            elif 'iptvsubstv.m3u' in self.path:
				infoDialog('Detected iptvsub.m3u', '[COLOR red]iptvsub [1][/COLOR]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				#numportal = args['portal'][0];
				url = str(MyIptvSubsCodetv) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + url, 'iptvsub [2]');
				#if url == "": time.sleep(7)
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect iptvsub.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'iptvsub [3]')
				self.finish()
            elif 'iptvusatv.m3u' in self.path:
				infoDialog('Detected iptvusatv.m3u', '[COLOR red]iptvusatv [1][/COLOR]');
				url = ""
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				tmp = args['tmp'][0];
				url = str(MyIptvusaCodetv) + str(cmd) + ".m3u8"
				infoDialog('[COLOR green]Get url: [/COLOR]' + url, 'iptvusatv [2]');
				self.send_response(301)
				self.send_header('Location', url)
				self.end_headers()
				if mydebug =="true": 
					writeappend_file(client_ipaddr_log, ' redirect iptvusatv.m3u: ' + str(url))
					infoDialog('[COLOR aqua]stream: [/COLOR]' + str(url), 'iptvusatv [3]')
				self.finish()
				
            elif 'tsf4mst.m3u' in self.path:
				infoDialog('Start tsf4mst Proxy', 'tsf4mst [1]');
				args = parse_qs(urlparse(self.path).query);
				cmd = args['channel'][0];
				pk_id = args['pkid'][0];
				url = playF4mLink(url=cmd, name=pk_id, maxbitrate=0, streamtype="TSDOWNLOADER", setResolved=True)
				infoDialog('[COLOR green]get url for Client..[/COLOR]' + url, 'tsf4mst [2]')
				self.send_response(301)
				self.send_header('Location', urllib.unquote_plus(url))
				self.end_headers()
				if mydebug =="true":
					writeappend_file(client_ipaddr_log, ' redirect tsf4mst.m3u: ' + str(url))
				infoDialog('[COLOR green]Done Proxy - ready to stream now.. [/COLOR]' + str(url), 'tsf4mst [3]')
				self.finish()
                
            elif 'epg.xml' in self.path:
				
				args = parse_qs(urlparse(self.path).query);
				numportal = args['portal'][0];
				
				portal = portals[numportal];
				
				try:
					xml = load_channels.getEPG(portal['mac'], portal['url'], portal['serial'], addondir);
				except Exception as e:
					xml  = '<?xml version="1.0" encoding="ISO-8859-1"?>'
					xml += '<error>' + str(e) + '</error>';
					
				
				self.send_response(200)
				self.send_header('Content-type',	'txt/xml')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(xml))
				self.end_headers()
				self.wfile.write(xml)
				self.finish()
                 
            elif 'stop' in self.path:
				msg = 'Stopping ...';
				#infoDialog('msg Stopping ...', 'Server Stop 1', time=1000);
				self.send_response(200)
				self.send_header('Content-type',	'text/html')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(msg))
				self.end_headers()
				self.wfile.write(msg.encode('utf-8'))
				#infoDialog('msg: ' + str(msg.encode('utf-8')), 'Server Stop 2', time=1000);
				server.socket.close();
                
            elif 'online' in self.path:
				msg = 'Yes. I am.';
				#mac_address = getMacAddress();
				infoDialog('getauthmac: ' + str(mac_address), 'getauthmac 1', time=1000);
				infoDialog('msg online ...', 'Server online 1', time=1000);
				self.send_response(200)
				self.send_header('Content-type',	'text/html')
				self.send_header('Connection',	'close')
				self.send_header('Content-Length', len(msg))
				self.end_headers()
				infoDialog('msg: ' + str(msg.encode('utf-8')), 'Server online 2', time=1000);
				self.wfile.write(msg.encode('utf-8'))
            
            
            else:
            	self.send_error(400,'Bad Request');
            	#infoDialog('***send_error***', 'Server do_Get', time=1000);
        except IOError:
            self.send_error(500,'Internal Server Error ' + str(IOError))
        infoDialog('[COLOR lime]All Done![/COLOR]', 'IPTV Server', time=3000);
	



@Async
def startServer():
	global portals, server, mac_address;
	
	server_enable = addon.getSetting('server_enable');
	port = int(addon.getSetting('server_port'));
	mac_address = getMacAddress();
	
	if server_enable != 'true':
		return;

	portals = { 
		'1' : config.portalConfig('1'), 
		'2' : config.portalConfig('2'), 
		'3' : config.portalConfig('3') };

	try:
		server = SocketServer.TCPServer(('', port), MyHandler);
		server.serve_forever();
		
	except KeyboardInterrupt:
		if server != None:
			server.socket.close();

def serverOnline():
	
	port = addon.getSetting('server_port');
	
	try:
		url = urllib.urlopen('http://localhost:' + str(port) + '/online');
		code = url.getcode();
		
		if code == 200:
			return True;
	
	except Exception as e:
		return False;

	return False;


def stopServer():
	
	port = addon.getSetting('server_port');
	
	try:
		url = urllib.urlopen('http://localhost:' + str(port) + '/stop');
		code = url.getcode();

	except Exception as e:
		return;

	return;

if __name__ == '__main__':
	startServer();
