# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib
import urllib2
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import hashlib
import re
import time
import xbmc
import shutil
import hashlib
import string
import ctypes
import linecache
import logging, random, datetime
from resources.lib.common import *
#import urlfetch
#from BeautifulSoup import BeautifulSoup
from resources.lib import urlfetch
from resources.lib.BeautifulSoup import BeautifulSoup

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') )
addon_id = 'plugin.video.iptvnow'
selfAddon = xbmcaddon.Addon(id=addon_id)


fpt_catid = ['Kênh Phổ Biến','Kênh Thể Thao','Kênh Phim Truyện','Kênh Thiếu Nhi',
'Kênh Giải Trí Tổng Hợp','Kênh Tin Tức','Kênh Khoa Giáo','Nhóm Kênh Khác', 'Nhóm Kênh Khác']	
offline_ch = [
"Ch 1 ", "Ch 2 ", "Ch 3 ","Ch 4 ", "Ch 5 ", "Ch 6 ", "Ch 7 ", "Ch 8 "]
offline_fptch = [
"Bóng Đá TV HD", "Thể Thao TV HD", "Bóng Đá TV", "Thể Thao TV"]
cache_path = xbmc.translatePath('special://temp')

##### For FPTPlay LivetV ++++++++++++++++++++++++++++++++++++++++++++++
MyTiviChan_list = addondir + 'fpt_MyTiviChan_list.txt'
tv_channels = addondir + 'fpt_tv_channels.txt'
raw_contents = addondir + 'fpt_raw_contents.txt'
dirs_soup = addondir + 'fpt_dirs_soup.txt'
dirs_items = addondir + 'fpt_dirs_items.txt'
dirs_movies = addondir + 'fpt_dirs_movies.txt'
request_contents = addondir + 'request_contents.txt'
AllChannels_cns_fpt = addondir + 'AllChannels_cns_fpt.txt'
AllChannels_cns_fpt_list  = addondir + 'AllChannels_cns_fpt_list.txt'
getAllChannels_d = addondir + 'getAllChannels_d.txt'
getAllChannels_o = addondir + 'getAllChannels_o.txt'


#fptdebug = True
getdirectlink_fpt = False #True
getchanelnamelist = True

fptplay = 'http://fptplay.net/'
fpthome = 'http://fptplay.net/livetv'
homeUrl = 'https://fptplay.net/livetv'

getUrl = 'http://fptplay.net/show/getlinklivetv'

dict = {'&amp;':'&', '&acirc;':'â', '&Aacute;':'Á', '&agrave;':'à', '&aacute;':'á', '&atilde;':'ã', '&igrave;':'ì', '&iacute;':'í', '&uacute;':'ú', '&ugrave;':'ù', '&oacute;':'ó', '&ouml;':'ö', '&ograve;':'ò', '&otilde;':'õ', '&ocirc;':'ô', '&Ocirc;':'Ô', '&eacute;':'é', '&egrave;':'è', '&ecirc;':'ê', '&Yacute;':'Ý', '&yacute;':'ý', "&#039;":"'"}


def GetNowLocalTime():
    import datetime
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%d %H:%M")

def make_request_fptplay(fpthome, params=None, headers=None):
    if headers is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1',
        		   'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        		   'X-Requested-With': 'XMLHttpRequest',
                   'Referer' : 'http://fptplay.net'}
    try:
    	if params is not None:
    		params = urllib.urlencode(params)
        req = urllib2.Request(fpthome,params,headers)
        f = urllib2.urlopen(req)
        body=f.read()
        return body
    except:
    	pass
	
livetv_fptplay_channel_content = addondir + 'livetv_fptplay_channel.txt'
livetv_fptplay_channel_movies = addondir + 'livetv_fptplay_channel_movies.txt'
directlink_fpt =  addondir + 'directlink_fpt_channel_info.txt'
livetv_fptplay_channel_info = addondir + 'livetv_fptplay_channel_info.txt'

cats = [
('52804883169a58104bf33ffe', fpt_catid[0]),
('55572f1117dc13323d89f93a', fpt_catid[1]),
('55572ed417dc13323f89f962', fpt_catid[2]),
('563324f717dc136ea126eab6', fpt_catid[3]),
('52804895169a58104bf34000', fpt_catid[4]),
('55572f7f17dc13323e89f93e', fpt_catid[5]),
('55572fa317dc13323d89f93d', fpt_catid[6]),
('55572fcd17dc13323f89f966', fpt_catid[7]),
('52b2dd1ec9692820fbacc075', fpt_catid[8])]

ipaddress = str(addon.getSetting('ipaddress'))
port = str(selfAddon.getSetting('server_port'))

def LoadFPTChannels():
    infoDialog('[COLOR green]Start FPT m3u List[/COLOR]', 'LoadFPTChannels [1]')
    content=make_request_fptplay(fpthome)
    tv_contruct = []
    link_fpt = []
    myhost = 'http://' + ipaddress + ':' + port + '/fptplay.m3u?'
    myportal = "&tmp=1&portal=1&channel="
    index = 0
    EXTM3U = "#EXTM3U\n\n"
    EXTM3U += "### FPT Channels - Author: Long Hong TV-Box auto created m3u playlist date: " + GetNowLocalTime() + " ...###\n\n"
    soup = BeautifulSoup(str(content), convertEntities=BeautifulSoup.HTML_ENTITIES)
    items = soup.findAll('a',{'class' : 'tv_channel '})
    for item in items:
        lock = item.find('img',{'class':'lock'})
        if lock is None:
            title = item.find('img',{'class':'img-responsive'}).get('alt')
            name = item.get('data-href')
            thumb = item.find('img',{'class':'img-responsive'}).get('data-original')
            parent = item.get('parent')
            for k, v in cats: parent = parent.replace(k, v.decode("utf-8"))
            if title.encode('utf-8') not in offline_fptch:
                index += 1
                EXTM3U += '#EXTINF:-1,' + '" tvg-name="' + title.encode("utf-8") + '" tvg-logo="' + thumb.replace("https://", "").replace(" ", "%20") + '" group-title="' + parent + '",' + title.encode("utf-8") + '\n' 
                EXTM3U += myhost + '&pkid=' + str(index) + myportal + name.encode("utf-8") +'\n\n'
    fpt_playlist = "C:\Users\Long\MediaFire\TV-Guide\fpt_playlist.m3u"
    from common import write_file
    write_file(fpt_playlist, EXTM3U)
    infoDialog('[COLOR lime]Done FPT m3u List[/COLOR]', 'LoadFPTChannels [2]')
    return EXTM3U

def resolveUrl_fpt(url):
    params = url.split('/')
    id = params[len(params) - 1]
    result = urlfetch.fetch(
        homeUrl,
        headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36'
            })
    cookie='laravel_session=' + result.cookies.get('laravel_session') + ";"
    csrf = urllib.unquote(result.cookies.get('token'))
    result = urlfetch.post(
        getUrl,
        data={"id": id,
            "quality": "3", #addon.getSetting('quality'),
            "mobile": "web",
            "type" : "newchannel"
            },
        headers={'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36',
                'X-Requested-With':'XMLHttpRequest',
                'Referer':'https://fptplay.net/livetv',
                'x-csrf-token': csrf,
                'cookie':cookie
                }
        )
    jsonObject = json.loads(result.content)
    mediaUrl = jsonObject['stream']
    return mediaUrl
