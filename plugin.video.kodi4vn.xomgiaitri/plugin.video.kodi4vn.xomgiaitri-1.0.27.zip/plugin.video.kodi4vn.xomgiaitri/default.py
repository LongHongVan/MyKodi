#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , json , logging
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.kodi4vn.xomgiaitri'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
if 5 - 5: iiI / ii1I
def ooO0OO000o ( ) :
 OoOoOO00 ( 'Search' , 'http://www.xom68.com/xem/search/%s/1.html' , 'search' , 'http://www.viettv24.com/addonicons/Search.jpg' )
 OoOoOO00 ( 'Phim Lẻ' , 'http://www.xom68.com/xem/the-loai/phim-dien-anh' , 'index' , 'http://www.viettv24.com/addonicons/Movies.jpg' )
 OoOoOO00 ( 'Phim Bộ' , 'http://www.xom68.com/xem/the-loai/phim-bo' , 'index' , 'http://www.viettv24.com/addonicons/Series.jpg' )
 OoOoOO00 ( 'Phim Bộ theo Quốc Gia' , 'http://www.xom68.com/' , 'videosbyregion' , 'http://www.viettv24.com/addonicons/Regions.jpg' )
 OoOoOO00 ( 'Phim Lẻ theo Thể Loại' , 'http://www.xom68.com/' , 'videosbycategory' , 'http://www.viettv24.com/addonicons/Categories.jpg' )
 if 28 - 28: Ii11111i * iiI1i1
def i1I1ii1II1iII ( ) :
 OoOoOO00 ( "Hồng Kong" , "http://www.xom68.com/xem/category/1/phim-bo-hong-kong.html" , "index" , "" )
 OoOoOO00 ( "Hồng Kong (VNLT)" , "http://www.xom68.com/xem/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 OoOoOO00 ( "Hàn Quốc" , "http://www.xom68.com/xem/category/4/phim-bo-han-quoc.html" , "index" , "" )
 OoOoOO00 ( "Hàn Quốc (vietsub)" , "http://www.xom68.com/xem/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 OoOoOO00 ( "Trung Quốc" , "http://www.xom68.com/xem/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 OoOoOO00 ( "Đài Loan" , "http://www.xom68.com/xem/category/3/phim-bo-dai-loan.html" , "index" , "" )
 OoOoOO00 ( "Việt Nam" , "http://www.xom68.com/xem/category/5/phim-bo-viet-nam.html" , "index" , "" )
 OoOoOO00 ( "Thái Lan" , "http://www.xom68.com/xem/category/22/phim-bo-thai-lan.html" , "index" , "" )
 OoOoOO00 ( "Các Loại Khác" , "http://www.xom68.com/xem/category/7/cac-loai-khac.html" , "index" , "" )
 if 86 - 86: oO0o
def IIII ( ) :
 OoOoOO00 ( "Hành Động" , "http://www.xom68.com/xem/category/8/hanh-dong.html" , "index" , "" )
 OoOoOO00 ( "Tình Cảm" , "http://www.xom68.com/xem/category/9/tinh-cam.html" , "index" , "" )
 OoOoOO00 ( "Phim Hài" , "http://www.xom68.com/xem/category/10/phim-hai.html" , "index" , "" )
 OoOoOO00 ( "Kinh Dị" , "http://www.xom68.com/xem/category/11/kinh-di.html" , "index" , "" )
 OoOoOO00 ( "Kiếm Hiệp" , "http://www.xom68.com/xem/category/12/kiem-hiep.html" , "index" , "" )
 OoOoOO00 ( "Việt Nam" , "http://www.xom68.com/xem/category/15/viet-nam.html" , "index" , "" )
 OoOoOO00 ( "Hài Kịch" , "http://www.xom68.com/xem/category/16/hai-kich.html" , "index" , "" )
 OoOoOO00 ( "Ca Nhạc" , "http://www.xom68.com/xem/category/17/ca-nhac.html" , "index" , "" )
 OoOoOO00 ( "Cải Lương" , "http://www.xom68.com/xem/category/18/cai-luong.html" , "index" , "" )
 OoOoOO00 ( "Phóng Sự" , "http://www.xom68.com/xem/category/19/phong-su.html" , "index" , "" )
 OoOoOO00 ( "Các Loại Khác" , "http://www.xom68.com/xem/category/20/cac-loai-khac.html" , "index" , "" )
 if 59 - 59: II1i * o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( url ) :
 i1oOOoo00O0O = i1111 ( url )
 i11 = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( i1oOOoo00O0O )
 for I11 , Oo0o0000o0o0 , oOo0oooo00o in i11 :
  OoOoOO00 ( "[B]" + Oo0o0000o0o0 + "[/B]" , "http://www.xom68.com/xem" + I11 , 'mirrors' , oOo0oooo00o )
 oO0o0o0ooO0oO = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( i1oOOoo00O0O . replace ( "'" , '"' ) )
 for I11 , oo0o0O00 in oO0o0o0ooO0oO :
  OoOoOO00 ( oo0o0O00 , I11 . replace ( "./" , "http://www.xom68.com/xem/" ) , 'index' , "" )
  if 68 - 68: o00oo . iI1OoOooOOOO + i11iiII
def I1iiiiI1iII ( ) :
 try :
  IiIi11i = xbmc . Keyboard ( '' , 'Enter search text' )
  IiIi11i . doModal ( )
  if 43 - 43: o0O0 * O00O0O0O0
  if ( IiIi11i . isConfirmed ( ) ) :
   ooO0O = urllib . quote_plus ( IiIi11i . getText ( ) )
  o0oOoO00o ( oo % ooO0O )
 except : pass
 if 28 - 28: i1iIIIiI1I - Oo0oO0ooo
def OoO000 ( url ) :
 IIiiIiI1 = iiIiIIi ( url )
 i1oOOoo00O0O = i1111 ( IIiiIiI1 )
 ooOoo0O = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( i1oOOoo00O0O )
 ooOoo0O . reverse ( )
 if "Server VIP B :" in ooOoo0O :
  ooOoo0O . insert ( 0 , ooOoo0O . pop ( ooOoo0O . index ( "Server VIP B :" ) ) )
 if "Server VIP A :" in ooOoo0O :
  ooOoo0O . insert ( 0 , ooOoo0O . pop ( ooOoo0O . index ( "Server VIP A :" ) ) )
 for OooO0 in range ( len ( ooOoo0O ) ) :
  II11iiii1Ii = [ ]
  if not any ( x in ooOoo0O [ OooO0 ] for x in II11iiii1Ii ) :
   OoOoOO00 ( "[%d] - %s" % ( OooO0 + 1 , ooOoo0O [ OooO0 ] ) , IIiiIiI1 . encode ( "utf-8" ) , 'episodes' , "" )
   if 70 - 70: o00 / ii1I % i1iIIIiI1I % i11iIiiIii . IIIiiIIii
def O0o0Oo ( url , name ) :
 i1oOOoo00O0O = i1111 ( url )
 if 78 - 78: ii1I - iI1OoOooOOOO * iiI1i1 + II1i + i11iiII + i11iiII
 name = name . split ( "] - " ) [ 1 ]
 I11I11i1I = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % name ) . findall ( i1oOOoo00O0O )
 ii11i1iIII = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( I11I11i1I [ 0 ] )
 if ( "episode_bg_2" in I11I11i1I [ 0 ] ) :
  Ii1I = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( I11I11i1I [ 0 ] )
  Oo0o0 ( "Part - " + Ii1I [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , url , 'loadvideo' , '' , name . encode ( "utf-8" ) )
 for III1ii1iII , oo0oooooO0 in ii11i1iIII :
  Oo0o0 ( "Part - " + oo0oooooO0 . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , "http://www.xom68.com/xem/" + III1ii1iII , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 19 - 19: o00oo + i1iIIIiI1I
def iiIiIIi ( url ) :
 ooo = i1111 ( url )
 return re . compile ( '<p class="w_now"><a href="(.+?)" title="Xem phim trực tuyến">' ) . findall ( ooo ) [ 0 ]
 if 18 - 18: II1i
def I1i1I1II ( url , name ) :
 i1oOOoo00O0O = i1111 ( url )
 if ( "proxy.link" in i1oOOoo00O0O ) :
  i1IiIiiI = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( i1oOOoo00O0O )
  i1oOOoo00O0O = i1111 ( i1IiIiiI [ 0 ] )
 i1IiIiiI = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( i1oOOoo00O0O )
 if ( len ( i1IiIiiI ) == 0 ) :
  I1I = re . compile ( 'https://app.box.com/embed_widget/s/(.+?)\?' ) . findall ( i1oOOoo00O0O ) [ 0 ]
  i1I11i = i1111 ( "https://app.box.com/index.php?rm=preview_embed&sharedName=%s" % I1I )
  oOO00oOO = json . loads ( i1I11i ) [ "file" ] [ "versionId" ]
  i1IiIiiI . append ( "https://app.box.com/representation/file_version_%s/video_480.mp4?shared_name=%s" % ( oOO00oOO , I1I ) )
 OoOo = xbmcgui . ListItem ( name )
 OoOo . setProperty ( "IsPlayable" , "true" )
 if "://" not in i1IiIiiI [ 0 ] :
  iI = o00O ( "http://www.xom68.com/xem/" + i1IiIiiI [ 0 ] )
  if iI != "" :
   i1I11i = i1111 ( "https://drive.google.com/file/d/%s" % iI )
   OOO0OOO00oo = json . loads ( re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( i1I11i ) [ 0 ] )
   try :
    Iii111II = re . compile ( "22\|(.+?)," ) . findall ( OOO0OOO00oo [ 1 ] ) [ 0 ]
   except :
    Iii111II = re . compile ( "18\|(.+?)," ) . findall ( OOO0OOO00oo [ 1 ] ) [ 0 ]
   OoOo . setPath ( Iii111II )
  else :
   OoOo . setPath ( "http://www.xom68.com/xem/" + i1IiIiiI [ 0 ] )
 else :
  OoOo . setPath ( i1IiIiiI [ 0 ] )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OoOo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OoOo )
 if 9 - 9: iiI1i1
def o00O ( url ) :
 iI = ""
 i11O0oo0OO0oOOOo = urllib2 . Request ( url )
 i11O0oo0OO0oOOOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 i11O0oo0OO0oOOOo . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 i1i1i11IIi = urllib2 . urlopen ( i11O0oo0OO0oOOOo )
 url = i1i1i11IIi . geturl ( )
 try :
  iI = re . compile ( "/host/(.+?)$" ) . findall ( url ) [ 0 ]
 except :
  pass
 i1i1i11IIi . close ( )
 return iI
 if 33 - 33: II1i + Oo0oO0ooo * iiI1i1 - Ii11111i / o00 % iI1OoOooOOOO
def i1111 ( url ) :
 i11O0oo0OO0oOOOo = urllib2 . Request ( url )
 i11O0oo0OO0oOOOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 i11O0oo0OO0oOOOo . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 i1i1i11IIi = urllib2 . urlopen ( i11O0oo0OO0oOOOo )
 i1oOOoo00O0O = i1i1i11IIi . read ( )
 i1i1i11IIi . close ( )
 i1oOOoo00O0O = '' . join ( i1oOOoo00O0O . splitlines ( ) ) . replace ( '\'' , '"' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\n' , '' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\t' , '' )
 i1oOOoo00O0O = re . sub ( '  +' , ' ' , i1oOOoo00O0O )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '> <' , '><' )
 return i1oOOoo00O0O
 if 21 - 21: iiI1i1 * ii1I % o00 * i1
def Oo0o0 ( name , url , mode , iconimage , mirrorname ) :
 Ii11Ii1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 O00oO = True
 I11i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 I11i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I11i1I1I . setProperty ( "IsPlayable" , "true" )
 O00oO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii11Ii1I , listitem = I11i1I1I )
 return O00oO
 if 83 - 83: o00ooo0 / i1iIIIiI1I
def OoOoOO00 ( name , url , mode , iconimage ) :
 Ii11Ii1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O00oO = True
 I11i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I11i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O00oO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii11Ii1I , listitem = I11i1I1I , isFolder = True )
 return O00oO
 if 49 - 49: II1i
def IIii1Ii1 ( k , e ) :
 I1II11IiII = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for OooO0 in range ( len ( e ) ) :
  OOO0OOo = k [ OooO0 % len ( k ) ]
  I1I111 = chr ( ( 256 + ord ( e [ OooO0 ] ) - ord ( OOO0OOo ) ) % 256 )
  I1II11IiII . append ( I1I111 )
 return "" . join ( I1II11IiII )
 if 39 - 39: iI1OoOooOOOO % o0O0
def i111IiI1I ( parameters ) :
 O0 = { }
 if 30 - 30: II1i . iI1OoOooOOOO - OOooo000oo0
 if parameters :
  Ii1iIiii1 = parameters [ 1 : ] . split ( "&" )
  for OOO in Ii1iIiii1 :
   Oo0oOOo = OOO . split ( '=' )
   if ( len ( Oo0oOOo ) ) == 2 :
    O0 [ Oo0oOOo [ 0 ] ] = Oo0oOOo [ 1 ]
 return O0
 if 58 - 58: ii1IiI1i * Oo0oO0ooo * o00ooo0 / Oo0oO0ooo
oO0o0OOOO = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 68 - 68: i11iiII - O00O0O0O0 - IIIiiIIii - o00ooo0 + o00oo
if os . path . exists ( oO0o0OOOO ) == False :
 os . mkdir ( oO0o0OOOO )
iiiI1I11i1 = os . path . join ( oO0o0OOOO , 'visitor' )
if 49 - 49: IIIiiIIii % i1iIIIiI1I . i1iIIIiI1I . o00oo * i1iIIIiI1I
if os . path . exists ( iiiI1I11i1 ) == False :
 from random import randint
 O0oOO0 = open ( iiiI1I11i1 , "w" )
 O0oOO0 . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 O0oOO0 . close ( )
 if 68 - 68: O00O0O0O0 % i1 . o0O0 . o00ooo0
def o0 ( utm_url ) :
 oo0oOo = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  i11O0oo0OO0oOOOo = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : oo0oOo }
 )
  i1i1i11IIi = urllib2 . urlopen ( i11O0oo0OO0oOOOo ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return i1i1i11IIi
 if 89 - 89: oO0o
def OO0oOoOO0oOO0 ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  oO0OOoo0OO = "1.0"
  O0ii1ii1ii = open ( iiiI1I11i1 ) . read ( )
  oooooOoo0ooo = "XomGiaiTri"
  I1I1IiI1 = "UA-52209804-2"
  III1iII1I1ii = "www.viettv24.com"
  oOOo0 = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   oo00O00oO = oOOo0 + "?" + "utmwv=" + oO0OOoo0OO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oooooOoo0ooo ) + "&utmac=" + I1I1IiI1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O0ii1ii1ii , "1" , "1" , "2" ] )
   if 23 - 23: iiI1i1 + iiI1i1 . Oo0oO0ooo
   if 38 - 38: O00O0O0O0
   if 7 - 7: iiI . i11iiII % o00ooo0 - IIIiiIIii - ii1I
   if 36 - 36: o0O0 % i1iIIIiI1I % Ii11111i - o00ooo0
   if 22 - 22: ii1I / Ii11111i * o00ooo0 % i11iiII
  else :
   if group == "None" :
    oo00O00oO = oOOo0 + "?" + "utmwv=" + oO0OOoo0OO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oooooOoo0ooo + "/" + name ) + "&utmac=" + I1I1IiI1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O0ii1ii1ii , "1" , "1" , "2" ] )
    if 85 - 85: o00 % i11iIiiIii - i11iiII * OOooo000oo0 / IIIiiIIii % IIIiiIIii
    if 1 - 1: iiI1i1 - o00 . o00oo . iiI1i1 / Ii11111i + o00oo
    if 78 - 78: iiI . o00 . ii1IiI1i % Oo0oO0ooo
    if 49 - 49: iI1OoOooOOOO / iiI1i1 . ii1IiI1i
    if 68 - 68: i11iIiiIii % o00ooo0 + i11iIiiIii
   else :
    oo00O00oO = oOOo0 + "?" + "utmwv=" + oO0OOoo0OO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( oooooOoo0ooo + "/" + group + "/" + name ) + "&utmac=" + I1I1IiI1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , O0ii1ii1ii , "1" , "1" , "2" ] )
    if 31 - 31: ii1IiI1i . IIIiiIIii
    if 1 - 1: Ii11111i / II1i % i11iiII * o0O0 . i11iIiiIii
    if 2 - 2: o00ooo0 * o00oo - ii1I + IIIiiIIii . o00 % i11iiII
    if 92 - 92: i11iiII
    if 25 - 25: Ii11111i - IIIiiIIii / OOooo000oo0 / II1i
    if 12 - 12: IIIiiIIii * i11iiII % i1 % ii1I
  print "============================ POSTING ANALYTICS ============================"
  o0 ( oo00O00oO )
  if 20 - 20: Oo0oO0ooo % iI1OoOooOOOO / iI1OoOooOOOO + iI1OoOooOOOO
  if not group == "None" :
   III1IiiI = oOOo0 + "?" + "utmwv=" + oO0OOoo0OO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( III1iII1I1ii ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + oooooOoo0ooo + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( oooooOoo0ooo ) + "&utmac=" + I1I1IiI1 + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , O0ii1ii1ii , "1" , "2" ] )
   if 31 - 31: II1i . IIIiiIIii
   if 46 - 46: i11iiII
   if 8 - 8: o00 * oO0o - iI1OoOooOOOO - iiI1i1 * Oo0oO0ooo % IIIiiIIii
   if 48 - 48: iiI
   if 11 - 11: o00oo + OOooo000oo0 - iiI1i1 / II1i + Ii11111i . ii1IiI1i
   if 41 - 41: iI1OoOooOOOO - iiI - iiI
   if 68 - 68: Oo0oO0ooo % O00O0O0O0
   if 88 - 88: ii1I - i1iIIIiI1I + Oo0oO0ooo
   try :
    print "============================ POSTING TRACK EVENT ============================"
    o0 ( III1IiiI )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 40 - 40: IIIiiIIii * iI1OoOooOOOO + Oo0oO0ooo % i11iiII
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 74 - 74: o00 - Ii11111i + OOooo000oo0 + O00O0O0O0 / oO0o
i1I1iI1iIi111i = i111IiI1I ( sys . argv [ 2 ] )
iiIi1IIi1I = i1I1iI1iIi111i . get ( 'mode' )
oo = i1I1iI1iIi111i . get ( 'url' )
o0OoOO000ooO0 = i1I1iI1iIi111i . get ( 'name' )
if type ( oo ) == type ( str ( ) ) :
 oo = urllib . unquote_plus ( oo )
if type ( o0OoOO000ooO0 ) == type ( str ( ) ) :
 o0OoOO000ooO0 = urllib . unquote_plus ( o0OoOO000ooO0 )
 if 56 - 56: i11iiII
oo0oO0oOOoo = str ( sys . argv [ 1 ] )
if iiIi1IIi1I == 'index' :
 OO0oOoOO0oOO0 ( "Browse" , o0OoOO000ooO0 )
 o0oOoO00o ( oo )
elif iiIi1IIi1I == 'search' :
 OO0oOoOO0oOO0 ( "None" , "Search" )
 I1iiiiI1iII ( )
elif iiIi1IIi1I == 'videosbyregion' :
 OO0oOoOO0oOO0 ( "Browse" , o0OoOO000ooO0 )
 i1I1ii1II1iII ( )
elif iiIi1IIi1I == 'videosbycategory' :
 OO0oOoOO0oOO0 ( "Browse" , o0OoOO000ooO0 )
 IIII ( )
elif iiIi1IIi1I == 'mirrors' :
 OO0oOoOO0oOO0 ( "Browse" , o0OoOO000ooO0 )
 OoO000 ( oo )
elif iiIi1IIi1I == 'episodes' :
 OO0oOoOO0oOO0 ( "Browse" , o0OoOO000ooO0 )
 O0o0Oo ( oo , o0OoOO000ooO0 )
elif iiIi1IIi1I == 'loadvideo' :
 OO0oOoOO0oOO0 ( "Play" , o0OoOO000ooO0 + "/" + oo )
 oOo00O0oo00o0 = xbmcgui . DialogProgress ( )
 oOo00O0oo00o0 . create ( 'xomgiaitri.com' , 'Loading video. Please wait...' )
 I1i1I1II ( oo , o0OoOO000ooO0 )
 oOo00O0oo00o0 . close ( )
 del oOo00O0oo00o0
else :
 OO0oOoOO0oOO0 ( "None" , "None" )
 ooO0OO000o ( )
xbmcplugin . endOfDirectory ( int ( oo0oO0oOOoo ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
