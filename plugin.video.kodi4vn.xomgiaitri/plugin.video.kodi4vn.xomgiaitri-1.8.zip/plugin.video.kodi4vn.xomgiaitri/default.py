#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , json , logging , requests , urlresolver
from common import ShowMessage, infoDialog, Paths, write_file

if 64 - 64: i11iIiiIii
addon_id = 'plugin.video.kodi4vn.xomgiaitri'
my_addon = xbmcaddon . Addon ( addon_id )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
if 5 - 5: iiI / ii1I

def main_index ( ) :
 addFolder ( 'Search' , 'http://www.xomphimbo.com/xem/search/%s/1.html' , 'search' , 'http://www.viettv24.com/addonicons/Search.jpg' )
 addFolder ( 'Phim Lẻ' , 'http://www.xomphimbo.com/xem/the-loai/phim-dien-anh' , 'index' , 'http://www.viettv24.com/addonicons/Movies.jpg' )
 addFolder ( 'Phim Bộ' , 'http://www.xomphimbo.com/xem/the-loai/phim-bo' , 'index' , 'http://www.viettv24.com/addonicons/Series.jpg' )
 addFolder ( 'Phim Bộ theo Quốc Gia' , 'http://www.xomphimbo.com/' , 'videosbyregion' , 'http://www.viettv24.com/addonicons/Regions.jpg' )
 addFolder ( 'Phim Lẻ theo Thể Loại' , 'http://www.xomphimbo.com/' , 'videosbycategory' , 'http://www.viettv24.com/addonicons/Categories.jpg' )
 if 66 - 66: iIiI * iIiiiI1IiI1I1 * o0OoOoOO00
 I11i = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 I11i = xbmc . translatePath ( os . path . join ( I11i , "temp.jpg" ) )
 urllib . urlretrieve ( 'http://drive.google.com/uc?export=jpg&id=0B-ygKtjD8Sc-OUxwbVR5ZzZsbFJFT3A5aS04YlJkdDJtQ3BF' , I11i )
 O0O = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , I11i )
 Oo = xbmcgui . WindowDialog ( )
 Oo . addControl ( O0O )
 #Oo . doModal ( )
 if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11iIi1I / IiiIII111iI
def countries ( ) :
 addFolder ( "Hồng Kong" , "http://www.xomphimbo.com/xem/category/1/phim-bo-hong-kong.html" , "index" , "" )
 addFolder ( "Hồng Kong (VNLT)" , "http://www.xomphimbo.com/xem/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 addFolder ( "Hàn Quốc" , "http://www.xomphimbo.com/xem/category/4/phim-bo-han-quoc.html" , "index" , "" )
 addFolder ( "Hàn Quốc (vietsub)" , "http://www.xomphimbo.com/xem/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 addFolder ( "Trung Quốc" , "http://www.xomphimbo.com/xem/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 addFolder ( "Đài Loan" , "http://www.xomphimbo.com/xem/category/3/phim-bo-dai-loan.html" , "index" , "" )
 addFolder ( "Việt Nam" , "http://www.xomphimbo.com/xem/category/5/phim-bo-viet-nam.html" , "index" , "" )
 addFolder ( "Thái Lan" , "http://www.xomphimbo.com/xem/category/22/phim-bo-thai-lan.html" , "index" , "" )
 addFolder ( "Các Loại Khác" , "http://www.xomphimbo.com/xem/category/7/cac-loai-khac.html" , "index" , "" )
 if 28 - 28: Ii11111i * iiI1i1
def categories ( ) :
 addFolder ( "Hành Động" , "http://www.xomphimbo.com/xem/category/8/hanh-dong.html" , "index" , "" )
 addFolder ( "Tình Cảm" , "http://www.xomphimbo.com/xem/category/9/tinh-cam.html" , "index" , "" )
 addFolder ( "Phim Hài" , "http://www.xomphimbo.com/xem/category/10/phim-hai.html" , "index" , "" )
 addFolder ( "Kinh Dị" , "http://www.xomphimbo.com/xem/category/11/kinh-di.html" , "index" , "" )
 addFolder ( "Kiếm Hiệp" , "http://www.xomphimbo.com/xem/category/12/kiem-hiep.html" , "index" , "" )
 addFolder ( "Việt Nam" , "http://www.xomphimbo.com/xem/category/15/viet-nam.html" , "index" , "" )
 addFolder ( "Hài Kịch" , "http://www.xomphimbo.com/xem/category/16/hai-kich.html" , "index" , "" )
 addFolder ( "Ca Nhạc" , "http://www.xomphimbo.com/xem/category/17/ca-nhac.html" , "index" , "" )
 addFolder ( "Cải Lương" , "http://www.xomphimbo.com/xem/category/18/cai-luong.html" , "index" , "" )
 addFolder ( "Phóng Sự" , "http://www.xomphimbo.com/xem/category/19/phong-su.html" , "index" , "" )
 addFolder ( "Các Loại Khác" , "http://www.xomphimbo.com/xem/category/20/cac-loai-khac.html" , "index" , "" )
 if 86 - 86: oO0o
def add_mirrors ( url ) :
 response = request_url ( url )
 II1Ii1iI1i = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( response )
 for iiI1iIiI , OOo , Ii1IIii11 in II1Ii1iI1i :
  Ii1IIii11 = Ii1IIii11 . replace ( "xomgiaitri.com" , "mythugian.net" )
  Ii1IIii11 = Ii1IIii11 . replace ( "www." , "" )
  Ii1IIii11 = "/" . join ( Ii1IIii11 . split ( "/" ) [ : - 1 ] ) + "/" + urllib . quote ( Ii1IIii11 . split ( "/" ) [ - 1 ] )
  addFolder ( "[B]" + OOo + "[/B]" , "http://www.xomphimbo.com/xem" + iiI1iIiI , 'mirrors' , Ii1IIii11 )
 Oooo0000 = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( response . replace ( "'" , '"' ) )
 for iiI1iIiI , i11 in Oooo0000 :
  addFolder ( i11 , iiI1iIiI . replace ( "./" , "http://www.xomphimbo.com/xem/" ) , 'index' , "" )
  if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
def search ( ) :
 try :
  O0OoOoo00o = xbmc . Keyboard ( '' , 'Enter search text' )
  O0OoOoo00o . doModal ( )
  if 31 - 31: i111IiI + o0OoOoOO00 . ii1IiI1i
  if ( O0OoOoo00o . isConfirmed ( ) ) :
   OOoO00o = urllib . quote_plus ( O0OoOoo00o . getText ( ) )
  add_mirrors ( url % OOoO00o )
 except : pass
 if 48 - 48: ii1IiI1i . iIiI - OOooOOo % iiI1i1 / O00o0o0000o0o . O00o0o0000o0o
def add_episodes ( url ) :
 I111I11 = xemtructuyen ( url )
 response = request_url ( I111I11 )
 OOoooooO = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( response )
 if 14 - 14: oO0o % iiI
 if "VIP A : " in OOoooooO :
  OOoooooO . insert ( 0 , OOoooooO . pop ( OOoooooO . index ( "VIP A : " ) ) )
 if "VIP D : " in OOoooooO :
  OOoooooO . insert ( 0 , OOoooooO . pop ( OOoooooO . index ( "VIP D : " ) ) )
 if "VIP B : " in OOoooooO :
  OOoooooO . insert ( 0 , OOoooooO . pop ( OOoooooO . index ( "VIP B : " ) ) )
 for IiI1I1 in range ( len ( OOoooooO ) ) :
  OoO000 = [ "Flv :" , "OK :" ]
  if not any ( x in OOoooooO [ IiI1I1 ] for x in OoO000 ) :
   addFolder ( "[%d] - %s" % ( IiI1I1 + 1 , OOoooooO [ IiI1I1 ] ) , I111I11 . encode ( "utf-8" ) , 'episodes' , "" )
   if 42 - 42: Ii11111i - iIiiiI1IiI1I1 / i11iIiiIii + iiI1i1 + ii1IiI1i
def loadvideo ( url , name ) :
 response = request_url ( url )
 if 40 - 40: Ii11111i . OOooOOo . i1 . iIiiiI1IiI1I1
 name = name . split ( "] - " ) [ 1 ]
 I11iii = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % name ) . findall ( response )
 OO0O00 = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( I11iii [ 0 ] )
 if ( "episode_bg_2" in I11iii [ 0 ] ) :
  ii1 = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( I11iii [ 0 ] )
  addLink ( "Part - " + ii1 [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf8" ) , url , 'loadvideo' , '' , name )
 for II1i1Ii11Ii11 , iII11i in OO0O00 :
  addLink ( "Part - " + iII11i . replace ( "&nbsp;" , "" ) . strip ( ) , "http://www.xomphimbo.com/xem/" + II1i1Ii11Ii11 , 'loadvideo' , '' , name )
  if 97 - 97: oO0o % oO0o + o0OoOoOO00 * oOo0oooo00o
def xemtructuyen ( url ) :
 islink = request_url ( url )
 return re . compile ( '<p class="w_now"><a href="(.+?)" title="Xem phim trực tuyến">' ) . findall ( islink ) [ 0 ]
 if 25 - 25: i1 - I1i1i1ii . iIiI
def playStream ( url , name ) :
 req = xbmcgui . ListItem ( name )
 response = request_url ( url )
 if "proxy.link" in response :
  url_link = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( response )
  response = request_url ( url_link [ 0 ] )
 url_link = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( response )
 if ( len ( url_link ) == 0 ) :
  video_link = None
  rep_matches = re . compile ( 'file\: "(.+?)"' ) . findall ( response )
  if 'iframe src="http://play.mythugian.net/' in response :
   url_link = re . compile ( 'iframe src="(http://play.mythugian.net/.+?)"' ) . findall ( response )
   response = request_url ( url_link [ 0 ] )
   url_link = re . compile ( '(\[\{"label".+?\}\])' ) . findall ( response )
   try :
    video_link = json . loads ( url_link [ 0 ] ) [ - 1 ] [ "file" ]
   except :
    video_link = json . loads ( url_link [ 0 ] ) [ - 1 ] [ "src" ]
  elif 'iframe src="http://img.mythugian.net/' in response :
   try :
    url_link = re . search ( 'iframe[^>]*src="(http://img.mythugian.net/.+?)"' , response ) . group ( 1 )
    try :
     video_link = re . search ( 'link=(.+?)$' , url_link ) . group ( 1 ) . decode ( "base64" )
     video_link = get_gdlink ( video_link )
    except :
     response = request_url ( url_link )
     try :
      rep_match = [ ]
      rep_match += [ re . search ( 'start\|primary\|(.+?)\|' . decode ( "base64" ) , response ) . group ( 1 ) ]
      try :
       rep_match += [ re . search ( 'XHxnb29nbGVcfChcdyspXHxjb2xvclx8' . decode ( "base64" ) , response ) . group ( 1 ) ]
      except : pass
      video_link = get_gdlink ( "aHR0cHM6Ly9kcml2ZS5nb29nbGUuY29tL2ZpbGUvZC8lcy92aWV3" . decode ( "base64" ) % ( "-" . join ( rep_match ) ) )
     except :
      try :
       rep_match = [ ]
       rep_match += [ re . search ( 'c3RhcnRcfChcdyspXHxzZXR1cA==' . decode ( "base64" ) , response ) . group ( 1 ) ]
       rep_match += [ re . search ( 'XHxnb29nbGVcfChcdyspXHxjb2xvclx8' . decode ( "base64" ) , response ) . group ( 1 ) ]
       rep_match += [ re . search ( 'cHJpbWFyeVx8KFx3KylcfHN0YXJ0cGFyYW0=' . decode ( "base64" ) , response ) . group ( 1 ) ]
       video_link = get_gdlink ( "aHR0cHM6Ly9kcml2ZS5nb29nbGUuY29tL2ZpbGUvZC8lcy92aWV3" . decode ( "base64" ) % ( "-" . join ( rep_match ) ) )
      except :
       try :
        url_link = re . search ( 'sources = (\[.+?\]);' , response )
        video_link = json . loads ( url_link . group ( 1 ) ) [ - 1 ] [ "file" ]
       except :
        try :
         url_link = re . search ( '"(https://drive.google.com/file/.+?)"' , response ) . group ( 1 )
         video_link = get_gdlink ( url_link . replace ( "preview" , "view" ) )
        except :
         video_link = re . search ( '"(http\://.+?\.mediafire\.com/.+?)"' , response ) . group ( 1 )
   except : pass
  elif rep_matches is not None and not rep_matches == []:
   if "http://" not in rep_matches [ 0 ] :
    rep_matches [ 0 ] = "http://www.xomphimbo.com/xem/" + rep_matches [ 0 ]
   video_link = rep_matches [ 0 ]
  elif "app.box.com" in response :
   OOO00 = re . compile ( 'https://app.box.com/embed_widget/s/(.+?)\?' ) . findall ( response ) [ 0 ]
   iiiiiIIii = request_url ( "https://app.box.com/index.php?rm=preview_embed&sharedName=%s" % OOO00 )
   O000OO0 = json . loads ( iiiiiIIii ) [ "file" ] [ "versionId" ]
   video_link = "https://app.box.com/representation/file_version_%s/video_480.mp4?shared_name=%s" % ( O000OO0 , OOO00 )
  elif "drive.google.com/file" in response :
   url_link = re . search ( '"(https://drive.google.com/file/.+?)"' , response ) . group ( 1 )
   video_link = get_gdlink ( url_link . replace ( "preview" , "view" ) )
   video_link = video_link.replace ( "preview" , "view" )
   infoDialog(str(video_link), "Get Glink", time=3000)
  elif "openload" in response :
   try :
    video_link = re . compile ( '"(https://openload.+?)"' ) . findall ( response ) [ 0 ]
    video_link = urlresolver . resolve ( video_link )
   except :
    pass
  else :
   url_link = re . compile ( "file: '.+?'" ) . findall ( response )
   if "http://" not in url_link [ 0 ] :
    video_link = "http://www.xomphimbo.com/xem/" + url_link [ 0 ]
   else :
    video_link = url_link [ 0 ]
  req . setPath ( video_link )
 else :
  if "http://" not in url_link [ 0 ] :
   url_link [ 0 ] = "http://www.xomphimbo.com/xem/" + url_link [ 0 ]
  req . setPath ( url_link [ 0 ] )
 req . setProperty ( "IsPlayable" , "true" )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , req )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , req )
 if 43 - 43: IIIII - iiI % o0 . oO0o
def get_gdlink ( url , hq = True ) :
 o00 = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)"
 OooOooo = {
 'User-Agent' : o00 ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 iiiiiIIii = requests . get ( url , headers = OooOooo )
 O000oo0O = iiiiiIIii . text
 try :
  url_link = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( O000oo0O ) [ 0 ]
  OOOOi11i1 = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
  if not hq : OOOOi11i1 . reverse ( )
  IIIii1II1II = json . loads ( url_link ) [ 1 ] . split ( "," )
  for i1I1iI in OOOOi11i1 :
   for oo0OooOOo0 in IIIii1II1II :
    if oo0OooOOo0 . startswith ( i1I1iI + "|" ) :
     url = oo0OooOOo0 . split ( "|" ) [ 1 ]
     o0O = "|User-Agent=%s&Cookie=%s" % ( urllib . quote_plus ( o00 ) , urllib . quote_plus ( iiiiiIIii . headers [ 'set-cookie' ] ) )
     return url + o0O
 except :
  try :
   return re . search ( "fmt_stream_map\=18\|(.+?)(\||$)" , O000oo0O ) . group ( 1 )
  except : pass
  if 72 - 72: oOo0oooo00o / iIiiiI1IiI1I1 * i1 - IIIII
def request_glink ( url ) :
 IIIIii = ""
 O0o0 = urllib2 . Request ( url )
 O0o0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 O0o0 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 OO00Oo = urllib2 . urlopen ( O0o0 )
 url = OO00Oo . geturl ( )
 try :
  IIIIii = re . compile ( '"https://drive.google.com/file/d/(.+?)/.+?"' ) . findall ( url ) [ 0 ]
 except :
  pass
 OO00Oo . close ( )
 return IIIIii
 if 51 - 51: I1i1i1ii * I11iIi1I + oO0o + ii1IiI1i
def request_url ( url ) :
 O0o0 = urllib2 . Request ( url )
 O0o0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 O0o0 . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 OO00Oo = urllib2 . urlopen ( O0o0 )
 response = OO00Oo . read ( )
 OO00Oo . close ( )
 response = '' . join ( response . splitlines ( ) ) . replace ( '\'' , '"' )
 response = response . replace ( '\n' , '' )
 response = response . replace ( '\t' , '' )
 response = re . sub ( '  +' , ' ' , response )
 response = response . replace ( '> <' , '><' )
 return response
 if 66 - 66: OOooOOo
def addLink ( name , url , mode , iconimage , mirrorname ) :
 oO000Oo000 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 i111IiI1I = True
 O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0 . setProperty ( "IsPlayable" , "true" )
 i111IiI1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO000Oo000 , listitem = O0 )
 return i111IiI1I
 if 30 - 30: I11iIi1I . O00o0o0000o0o - iIiI
def addFolder ( name , url , mode , iconimage ) :
 oO000Oo000 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 i111IiI1I = True
 O0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i111IiI1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO000Oo000 , listitem = O0 , isFolder = True )
 return i111IiI1I
 if 8 - 8: iIiiiI1IiI1I1 - ii1I * o0OoOoOO00 + i11iIiiIii / IIIII % iiI1i1
def url_b64decode ( k , e ) :
 iiII1i1 = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for IiI1I1 in range ( len ( e ) ) :
  o00oOO0o = k [ IiI1I1 % len ( k ) ]
  OOO00O = chr ( ( 256 + ord ( e [ IiI1I1 ] ) - ord ( o00oOO0o ) ) % 256 )
  iiII1i1 . append ( OOO00O )
 return "" . join ( iiII1i1 )
 if 84 - 84: Ii11111i * ii1IiI1i / oO0o - iiI
def get_params ( parameters ) :
 Oo0O00Oo0o0 = { }
 if 87 - 87: i111IiI * i1 % i11iIiiIii % OOooOOo - iiI1i1
 if parameters :
  O0ooo0O0oo0 = parameters [ 1 : ] . split ( "&" )
  for oo0oOo in O0ooo0O0oo0 :
   o000O0o = oo0oOo . split ( '=' )
   if ( len ( o000O0o ) ) == 2 :
    Oo0O00Oo0o0 [ o000O0o [ 0 ] ] = o000O0o [ 1 ]
 return Oo0O00Oo0o0
 if 42 - 42: OOooOOo
II = xbmc . translatePath ( my_addon . getAddonInfo ( 'profile' ) )
if 45 - 45: iiI * I11iIi1I % i1 * iIiI + oOo0oooo00o . OOooOOo
if os . path . exists ( II ) == False :
 os . mkdir ( II )
Oo0ooOo0o = os . path . join ( II , 'visitor' )
if 22 - 22: ii1I / i11iIiiIii * ii1I * o0OoOoOO00 . iiI1i1 / i11iIiiIii
if os . path . exists ( Oo0ooOo0o ) == False :
 from random import randint
 Iiii = open ( Oo0ooOo0o , "w" )
 Iiii . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 Iiii . close ( )
 if 75 - 75: OOooOOo % I11iIi1I % I11iIi1I . IIIII

params = get_params ( sys . argv [ 2 ] )
mode = params . get ( 'mode' )
url = params . get ( 'url' )
name = params . get ( 'name' )
if type ( url ) == type ( str ( ) ) :
 url = urllib . unquote_plus ( url )
if type ( name ) == type ( str ( ) ) :
 name = urllib . unquote_plus ( name )
 if 26 - 26: O00o0o0000o0o
I11iiI1i1 = str ( sys . argv [ 1 ] )
if mode == 'index' :
 add_mirrors ( url )
elif mode == 'search' :
 search ( )
elif mode == 'videosbyregion' :
 countries ( )
elif mode == 'videosbycategory' :
 categories ( )
elif mode == 'mirrors' :
 add_episodes ( url )
elif mode == 'episodes' :
 loadvideo ( url , name )
elif mode == 'loadvideo' :
 I1i1Iiiii = xbmcgui . DialogProgress ( )
 I1i1Iiiii . create ( 'xomgiaitri.com' , 'Loading video. Please wait...' )
 playStream ( url , name )
 I1i1Iiiii . close ( )
 del I1i1Iiiii
else :
 main_index ( )
xbmcplugin . endOfDirectory ( int ( I11iiI1i1 ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
