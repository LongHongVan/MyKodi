# -*- coding: utf-8 -*-
from resources.lib import api
import xbmc
import source
from resources.lib.api.common import *

if __name__ == '__main__':
	if DMES_ON == "true": infoDialog('Start ' +  ADDON_ID  + ' \n' +  'Cache : ' + CACHE_EN + '; ' + 'ClipBoard : ' + CLIPBOARD,  '[COLOR lime]Main Add-on[/COLOR]')
	cache_path = xbmc.translatePath('special://temp')
	src = source.Source(cache_path)
	api.AddonMain(int(sys.argv[1]), src)
