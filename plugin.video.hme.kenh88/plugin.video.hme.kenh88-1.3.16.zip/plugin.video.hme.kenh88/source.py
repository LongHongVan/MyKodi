#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib
import re
import json
#import api
from  resources.lib import api
import urlparse, xbmc, time
from resources import pyperclip
from resources.lib.api.common import *
import urlresolver

addonID = 'plugin.video.hme.kenh88'
addon = xbmcaddon . Addon ( addonID )
pluginhandle = int ( sys . argv [ 1 ] )
defaultIcon  = xbmc.translatePath('special://home/addons/'+addonID+'/icon.png')

# ++++++++++++++++ Direct Links revised +++++++++++++++++++
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') )
selfAddon = xbmcaddon.Addon(id=addonID)

MyCacheFile = "MyDownloadLink.txt"
MyPageIndex = "MyPageIndex.txt"
MyResponse = 'MyResponse.txt'
ContentMenu = 'ContentMenu.txt'


def GetNowLocalTime():
    import datetime
    now = datetime.datetime.now()
    return now.strftime("%Y-%m-%d %H:%M")
	
MyEpisodes = '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n'
MyEpisodes += '++++ Auto Captured Links - Date: ' + GetNowLocalTime() + " Author: Long Hong (HME) Home Media Entertainments.\n"
MyEpisodes += '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n'



def intial_cache():
	global downloadfile, dmsg, cacheon, isclip, MyPageContentFile, MyResponseFile, ContentMenuFile
	if DOWNLOAD_PATH != "": 
		downloadfile = DOWNLOAD_PATH + '/' + MyCacheFile
		MyPageContentFile = DOWNLOAD_PATH + '/' + MyPageIndex
		MyResponseFile = DOWNLOAD_PATH + '/' + MyResponse
		ContentMenuFile = DOWNLOAD_PATH + '/' + ContentMenu
	else:
		downloadfile = addondir + MyCacheFile
		MyPageContentFile = addondir + MyPageIndex
		MyResponseFile = addondir + MyResponse
		ContentMenuFile = addondir + ContentMenu
	dmsg = DMES_ON
	cacheon = CACHE_EN
	isclip = CLIPBOARD
	if CLR_CACHE == 'true':
		try:
			#if isFile(downloadfile): deleteContent(downloadfile)
			write_file(downloadfile, str(MyEpisodes)) # Write new Header Info
		except:
			infoDialog('Check downloadfile', 'Unable to locate :\n'  + str(downloadfile))
		if dmsg == "true": infoDialog('clear cache..', 'intial_cache')

# ++++++++++++++++ Direct Links revised +++++++++++++++++++
cap_done = False
class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://www.kenh88.com/'
		global downloadfile, dmsg, cacheon, isclip, cap_done, MyPageContentFile, MyResponseFile
		intial_cache()

	def __get_page__(self, url, cacheTime=3600000):
		global downloadfile, dmsg, cacheon, isclip, cap_done, MyPageContentFile, MyResponseFile
		MyResponse = api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)
		write_file(MyResponseFile, str(MyResponse))
		if dmsg == "true": write_file(MyResponseFile, str(MyResponse))
		return MyResponse

	def base_url(self):
		return self.base_url

	def menu(self):
		page = self.__get_page__(self.base_url)
		menu = {}
		content = page.find('div', {'class': 'menu'})
		ul = content.find('ul')
		for l in ul.children:
			a = l.find('a')
			if type(a) is int and a < 0: continue
			if a['href'] == '/': continue
			if 'javascript' in a['href']:
				submenu = []
				sub_ul = l.find('ul', {'class': 'sub-menu'})
				for s in sub_ul.find_all('a'):
					submenu.append({'label': s.text, 'href': self.base_url + s['href']})
				menu[unicode(a.text)] = submenu
			else:
				menu[unicode(a.text)] = self.base_url + a['href']
		SaveList(addondir + 'MyMenu.txt', menu)# Test
		if dmsg == "true": infoDialog("Done get menu","Main Menu")
		return menu

	def contents(self, url):
		global downloadfile, dmsg, cacheon, isclip, cap_done, MyPageContentFile
		intial_cache()
		page = self.__get_page__(url)
		contents = []
		duplicates = []
		cap_done = False
		for c in page.find_all('div', {'class': 'row'}):
			for d in c.find_all('div'):
				duration = d.find('span', {'class': 'process_r'})
				if duration <> None:
					duration = duration.text
				info = d.find('span', {'class': 'status'})
				if info <> None:
					info = info.text
				a = d.find('a')
				href = a['href']
				if href.startswith('/'):
					href = href[1:]
				href = self.base_url + href
				poster = self.base_url + a.find('img')['src']
				poster = poster.replace(' ', '%20')# normalize_str -> s = re.sub(r'\s+', ' ', string).strip()
				title1 = self.normalize_str(d.find('h2').find('a').text)
				title2 = self.normalize_str(d.find('h2').text)
				# Thumbnails cache-> ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				if THUMB_CACHE == "true": 
					try:
						import urllib
						MyWebThumb = poster
						MyWrThumb = MyWebThumb.split("/")[5]
						MyWrThumb = addondir + MyWrThumb
						if not isFile(MyWrThumb):
							urllib.urlretrieve(MyWebThumb, MyWrThumb)
							#infoDialog("Done writing: " + str(MyWrThumb), "contents")
						else: pass
							#infoDialog("**File existed.." + str(MyWrThumb), "contents")
					except: pass
						#infoDialog("**FAILED*** writing img: " + str(MyWrThumb), "contents")
					if isFile(MyWrThumb): poster = MyWrThumb
				# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				if href not in duplicates:
					duplicates.append(href)
					contents.append({'title1': unicode(title1), 'title2': unicode(title2), 'href': href, 'duration': unicode(duration), 'info': unicode(info), 'poster': poster})
		SaveList(MyPageContentFile, contents)
		
		if cacheon == "true":
			try:
				SaveList(MyPageContentFile, contents)
				infoDialog("Done save MyPageContentFile", 'contents')
				cap_done = True
			except: infoDialog("[COLOR red]Unable to save MyPageContentFile[/COLOR]", 'contents')
		next_page = self.__next_page__(page)
		if dmsg == "true": infoDialog("Get contents", 'contents')
		return {'items': contents, 'next_page': next_page}

	def media_items(self, url):
		global downloadfile, dmsg, cacheon, isclip, cap_done, MyPageContentFile, index, title1, ep_title, serverName, title2 #, content_index
		intial_cache()
		cap_done = False
		page = self.__get_page__(url)
		#info
		poster = page.find('div', {'class': 'mCSB_container mCS_no_scrollbar'}).find('img')
		if poster <> None:
			poster = poster['src']
		else:
			poster = page.find('img', {'class': 'poster'})['src']
		if poster <> None:
			poster = self.base_url + poster
			poster = poster.replace(' ', '%20').replace("//upload_data", "/upload_data")
			#poster = poster.replace(' ', '%20')
		write_file(addondir + 'MyTestPage.txt', str(page))# Test
		title1 = page.find('div', {'class': 'movie'}).find('h1').text.strip()
		title2 = page.find('title').text.strip().replace(' Xem Phim Online', "")
		infoDialog(str(title1.encode('utf-8')),"Media Selected")
		url = url.replace('phim', 'xem-phim-online')
		page = self.__get_page__(url)
		media_items = {}
		index = 0
		serverList = page.find('div', {'class': 'serverlist'})
		for server in serverList.find_all('div', {'class': 'server'}):
			serverName = server.find('div', {'class': 'label'}).text
			serverName = serverName.replace(':', '').strip()
			for e in server.find_all('a'):
				ep_title = e.text.replace('full', '')
				ep_title = u''.join([u'Episode ', ep_title])
				href = e['href']
				if href.startswith('/'):
					href = href[1:]
				href = self.base_url + href
				index += 1
				s = []
				if ep_title in media_items:
					s = media_items[unicode(ep_title)]
				if cacheon == "true" :
					try:
						s.append({'title1': unicode(title1), 'title2': title2, 'ep_title': ep_title, 'poster': poster, 'banner': '', 'server_name': unicode(serverName), 'href': href, 'Direct Link': self.resolve_stream(href)})
					except: pass
				else:
					s.append({'title1': unicode(title1), 'title2': title2, 'ep_title': ep_title, 'poster': poster, 'banner': '', 'server_name': unicode(serverName), 'href': href})
				media_items[unicode(ep_title)] = s
		if media_items == {}:
			media_items['DEFAULT'] = [{'title1': unicode(title1), 'title2': '', 'ep_title': '', 'poster': poster, 'banner': '', 'server_name': unicode('Server 1'), 'href': url}]
		if cacheon == "true":
			try:
				infoDialog("Done Savelist", 'media_items')
				cap_done = True
			except: infoDialog("[COLOR red]Unable to save downloadfile[/COLOR]", 'media_items')
		if dmsg == "true": infoDialog("Get media_items", 'media_items')
		return media_items


	def search(self, query):
		search_url = self.base_url + 'film/search?' + urllib.urlencode({'keyword': urllib.quote_plus(query)})
		if dmsg == "true": infoDialog("Get search page", 'search')
		return self.contents(search_url)

	def __next_page__(self, page):
		pages = page.find('ul', {'class': 'pagination'})
		if pages is None:
			return None
		n = pages.find('a', {'class': 'next'})
		if n is None:
			return None
		if dmsg == "true": infoDialog("Get nextpage", 'next_page')
		return self.base_url + n['href']

	def normalize_str(self, string):
		s = re.sub(r'\s+', ' ', string)
		return s.strip()

	def resolve_stream(self, url):
		content = self._get_stream_content_link(url)
		if 'phimhub.com' in content:
			tags = content
			return tags
		elif 'picasaweb.google.com' in content:
			import urlresolver
			stream_url = urlresolver.HostedMediaFile(content).resolve()
			return stream_url
		else:
			values = urlparse.parse_qs(content)
			tags = values['fmt_stream_map'][0].split('|')
			return tags[1]

	def _get_stream_content_link(self, url):
		global index, title1, ep_title, serverName, title2
		page = self.__get_page__(url)
		glink = 'https://drive.google.com/uc?export=download&id='
		idx = index
		try:
			import base64
			match = re.findall('{link: "(.+?)"', str(page))
			if match:
				res= base64.b64decode(str(match)).replace("/view*original", "/edit?usp=sharing")
				write_file(addondir + 'gdrive_playOnline.txt', str(res))
				if 'drive.google.com' in res:
					MyDocid = glink + res.split('/')[5]
					d = res.split('/')[5]
					r = 'https://docs.google.com/get_video_info?' + urllib.urlencode({'docid': d, 'eurl': url, 'authuser': ''})
					resn = api.HTTPKit(cache_path=self.cache_path).Request(r).content
					kdlink = urlparse.parse_qs(resn)['fmt_stream_map'][0].split('|')[1]
					write_file(addondir + 'gdrive_directLink.txt', 'A1: ' + str(MyDocid))
					infoDialog('docidstr: ' + str(MyDocid), 'Get link [' + str(idx) + " ] shortly. Please wait..")
					links_contruct =  'Title name: ' + str(title2.encode('utf-8')) + '\n' + 'A-index: '   + str(idx) + '\n' + 'Download link: ' + str(MyDocid) + '\n' +  'Web-Online link: ' + str(res) + '\n'  + 'Kodi stream: ' + str(kdlink) + '\n' +    str(ep_title) + '\n' +  str(serverName) + '\n\n'
					writeappend_file(downloadfile, str(links_contruct))
					return resn				
				elif 'picasaweb.google.com' in res:
					#pyperclip.copy(res)
					#ShowMessage('stream_content picasaweb: ', str(res))
					import urlresolver
					res_picas = urlresolver.HostedMediaFile(res).resolve()
					links_contruct =  'Title name: ' + str(title2.encode('utf-8')) + '\n' + 'A2A-index: '   + str(idx) + '\n' + 'Stream link: ' + str(res_picas) + '\n'   +   str(ep_title) + '\n' +  str(serverName) + '\n\n'
					write_file(addondir + 'picasaweb_phimhub.txt', 'A2: ' + str(res_picas))
					writeappend_file(downloadfile, str(links_contruct))
					return res# New
				else: #phimhub.com - HongKong Series
					try:
						infoDialog('Server phimhub: ' + str(serverName), 'Get link [' + str(idx) + " .] Please wait..")
						links_contruct =  'Title name: ' + str(title2.encode('utf-8')) + '\n' + 'A2B-index: '   + str(idx) + '\n' + 'Download link: ' + str(res) + '\n'   +   str(ep_title) + '\n' +  str(serverName) + '\n\n'
						infoDialog('Unavailable links - ' + str(serverName), 'Capture Links')
						
						write_file(addondir + 'picasaweb_phimhub.txt', 'A3: ' + str(res))
						writeappend_file(downloadfile, str(links_contruct))
					except: pass
				return res
		except: pass
		for s in page.find_all('script'):
			m = re.search("(?i)proxy.link=(.*?)&", s.text)
			if m:
				data = {'url': m.group(1)}
				res = api.HTTPKit(cache_path=self.cache_path).Request('http://www.kenh88.com/media/plugins/plugins_player.php', values=data).content
				#ShowMessage('_get_stream_content_link', 'proxy.link res: ', str(res))
				return res
		embed = page.find('embed', {'type': 'application/x-shockwave-flash'})
		if embed <> None and 'src' in embed.attrs:
			s = embed['src']
			s = s[s.index('?') + 1 : ]
			qs = urlparse.parse_qs(s)
			d = qs['docid'][0]
			r = 'https://docs.google.com/get_video_info?' + urllib.urlencode({'docid': d, 'eurl': url, 'authuser': ''})
			res = api.HTTPKit(cache_path=self.cache_path).Request(r).content
			kdlink = urlparse.parse_qs(res)['fmt_stream_map'][0].split('|')[1]
			try:
				MyDocid = glink + str(d)
				infoDialog('docidstr: ' + str(d), 'Get link [' + str(idx) + " ] shortly. Please wait..")
				links_contruct =  'Title name: ' + str(title2.encode('utf-8')) + '\n' + 'B-index: '   + str(idx) + '\n' + 'Download link: ' + str(MyDocid) + '\n' + 'Stream: ' + str(kdlink) + '\n' +    str(ep_title) + '\n' +  str(serverName) + '\n\n'
				writeappend_file(downloadfile, links_contruct)
			except: infoDialog('unable to get Docid - Expect: \n' + str(MyDocid), 'Docid Info')
			return res
		return None
